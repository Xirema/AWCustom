package org.scratch.test;

import static org.lwjgl.opencl.CL12.*;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.scratch.main.util.BigRational;

public class OCLTest {
	private static final String kernel_code = 
		"kernel void multiply_floats(global float * a, global float * b, global float * c, ulong size) {\n"
			+ "size_t id = get_global_id(0);\n"
			+ "if(id >= 1) return;\n"
			+ "float4 vec = (float4)(0.2, 0.4, 0.6, 0.8);\n"
			+ "float4 vec2 = (float4)(0.8, 0.6, 0.4, 0.2);\n"
			+ "float4 vec3 = select(vec, vec2, (uint4)(vec.x <= vec2.x, vec.x <= vec2.x, vec.x <= vec2.x, vec.x <= vec2.x));\n"
			+ "vstore4(vec3, 0, c);\n"
		+ "}";
	public static void main(String[] args) throws UnsupportedEncodingException {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			int[] platformNum = {0};
			if(clGetPlatformIDs(null, platformNum) != CL_SUCCESS)
				throw new RuntimeException("Unable to query for platforms");
			PointerBuffer buffer = stack.callocPointer(platformNum[0]);
			clGetPlatformIDs(buffer, platformNum);
			long device = 0;
			for(int i = 0; i < platformNum[0]; i++) {
				long platformId = buffer.get(i);
				ByteBuffer nameBuffer = stack.calloc(100);
				PointerBuffer nameLength = stack.callocPointer(1);
				clGetPlatformInfo(platformId, CL_PLATFORM_NAME, nameBuffer, nameLength);
				byte[] nameArray = new byte[100];
				nameBuffer.get(nameArray, 0, (int)nameLength.get(0));
				System.out.println("Platform " + (i+1) + ": \"" + new String(nameArray, 0, (int)nameLength.get(0)) + "\"");
				int[] deviceNum = {0};
				if(clGetDeviceIDs(platformId, CL_DEVICE_TYPE_ALL, null, deviceNum) != CL_SUCCESS)
					throw new RuntimeException("Unable to query for Devices");
				PointerBuffer deviceBuffer = stack.callocPointer(deviceNum[0]);
				clGetDeviceIDs(platformId, CL_DEVICE_TYPE_ALL, deviceBuffer, deviceNum);
				for(int j = 0; j < deviceNum[0]; j++) {
					long deviceId = deviceBuffer.get(j);
					nameBuffer = stack.calloc(100);
					nameLength = stack.callocPointer(1);
					clGetDeviceInfo(deviceId, CL_DEVICE_NAME, nameBuffer, nameLength);
					nameBuffer.get(nameArray, 0, (int)nameLength.get(0));
					System.out.print("    Device " + (char)('a' + j) + ": \"" + new String(nameArray, 0, (int)nameLength.get(0)) + "\"");
					nameBuffer = stack.calloc(100);
					nameLength = stack.callocPointer(1);
					clGetDeviceInfo(deviceId, CL_DEVICE_VERSION, nameBuffer, nameLength);
					nameBuffer.get(nameArray, 0, (int)nameLength.get(0));
					System.out.println(" Version: \"" + new String(nameArray, 0, (int)nameLength.get(0)) + "\"");
				}
				device = deviceBuffer.get(0);
			}
			
			IntBuffer ret = stack.callocInt(1);
			PointerBuffer properties = stack.pointers(CL_CONTEXT_PLATFORM, buffer.get(0), 0);
			long context = clCreateContext(properties, device, null, 0, ret);
			if(ret.get(0) != CL_SUCCESS)
				throw new RuntimeException("Could not create Context.");
			ret = stack.callocInt(1);
			long queue = clCreateCommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, ret);
			if(ret.get(0) != CL_SUCCESS)
				throw new RuntimeException("Could not create Queue.");
			
			FloatBuffer a_buffer = stack.floats(1,2,3,4);
			FloatBuffer b_buffer = stack.floats(8,7,6,5);
			
			long a_mem = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_WRITE_ONLY, a_buffer, null);
			long b_mem = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR | CL_MEM_HOST_WRITE_ONLY, b_buffer, null);
			long c_mem = clCreateBuffer(context, CL_MEM_WRITE_ONLY | CL_MEM_HOST_READ_ONLY, 16, null);
			ret = stack.callocInt(1);
			long program = clCreateProgramWithSource(context, kernel_code, ret);
			if(ret.get(0) != CL_SUCCESS) {
				throw new RuntimeException("Problem creating Program");
			}
			if(clBuildProgram(program, device, "", null, 0) != CL_SUCCESS) {
				PointerBuffer logSize = stack.callocPointer(1);
				int success = clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, (ByteBuffer)null, logSize);
				if(success != CL_SUCCESS) {
					throw new RuntimeException("There was a problem retrieving the Build Log: " + success);
				}
				int length = (int)logSize.get(0);
				ByteBuffer errorLog = stack.calloc(length);
				clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, errorLog, logSize);
				byte[] bytes = new byte[length];
				errorLog.get(bytes, 0, length);
				String errorMessage = new String(bytes);
				throw new RuntimeException("Unable to Compile Program:\n" + errorMessage);
			}
			ret = stack.callocInt(1);
			long kernel = clCreateKernel(program, "multiply_floats", ret);
			clSetKernelArg(kernel, 0, stack.pointers(a_mem));
			clSetKernelArg(kernel, 1, stack.pointers(b_mem));
			clSetKernelArg(kernel, 2, stack.pointers(c_mem));
			clSetKernelArg(kernel, 3, stack.longs(4));
			
			PointerBuffer event_ptr = stack.callocPointer(1);
			clEnqueueNDRangeKernel(queue, kernel, 1, null, stack.pointers(4), null, null, event_ptr);
			
			long event = event_ptr.get(0);
			
			clWaitForEvents(event);
			ret = stack.callocInt(1);
			ByteBuffer c_buffer = clEnqueueMapBuffer(queue, c_mem, true, CL_MAP_READ, 0, 16, null, null, ret, null);
			FloatBuffer c_as_floats = c_buffer.asFloatBuffer();
			for(int i = 0; i < 4; i++) {
				System.out.print(c_as_floats.get(i) + " ");
			}
			clEnqueueUnmapMemObject(queue, c_mem, c_buffer, null, null);
		}
	}
}
