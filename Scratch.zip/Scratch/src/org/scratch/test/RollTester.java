package org.scratch.test;

import java.awt.BorderLayout;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;

import org.scratch.main.dice.format.RollPrinter;
import org.scratch.main.dice.format.RollPrinter.PrinterOptions;
import org.scratch.main.dice.format.RollPrinter.TableOptions;
import org.scratch.main.dice.model.AttackRoll;
import org.scratch.main.dice.model.RollBuilder;
import org.scratch.main.dice.model.RollBuilder.FilterType;
import org.scratch.main.dice.model.RollFactory;
import org.scratch.main.dice.model.Rollable;
import org.scratch.main.dice.model.StandardDice;
import org.scratch.main.util.ListAlgorithms;
import org.scratch.main.util.Pair;

public class RollTester {
	public static void main(String[] args) throws InterruptedException, ExecutionException, IOException {
		try {
			RollFactory factory = new RollFactory();
			List<Rollable> rolls = new ArrayList<>();

			PrinterOptions options = new PrinterOptions();
			options.terseStats = true;
			options.showPassOdds = true;
			// options.percentiles = Arrays.asList(0.75, 0.9, 0.95);

			long start = System.nanoTime();
			TableOptions toptions = MyRolls.getBarbarianComparison(factory, rolls);
//			TableOptions toptions = new TableOptions();
			
			long end = System.nanoTime();
			System.out.println("Calculation took " + String.format("%.9fs", (end - start) / 1_000_000_000.0));
			presentResults(rolls, options, toptions);
		} catch (OutOfMemoryError e) {
			System.err.println("Amount of memory used: " + Runtime.getRuntime().maxMemory());
			throw e;
		}
	}
	
	private static void presentResults(List<Rollable> rolls, PrinterOptions options, TableOptions toptions) throws UnsupportedEncodingException, IOException, InterruptedException, ExecutionException {
		StringBuilder readout = new StringBuilder();

		readout.append(RollPrinter.printLaTEXTable(rolls, toptions));
		readout.append(RollPrinter.printCSVTable(rolls, toptions));
		readout.append(RollPrinter.printFormattedTable(rolls, toptions));

		readout.append("==============================\n");
		readout.append("=========TERSE STATS==========\n");
		readout.append("==============================\n");
		for (Rollable roll : rolls) {
			readout.append(RollPrinter.formatRoll(roll, options)).append('\n');
		}
		readout.append("==============================\n");
		readout.append("==========RAW STATS===========\n");
		readout.append("==============================\n");
		options.terseStats = false;
		options.showPassOdds = true;
		options.wholeOutcome = true;
		for (Rollable roll : rolls) {
			readout.append(RollPrinter.formatRoll(roll, options)).append('\n');
		}
		readout.append("==============================\n");
		readout.append("===========ARRAYS=============\n");
		readout.append("==============================\n");
		options.removeOdds = true;
		for (Rollable roll : rolls) {
			readout.append(roll.getName()).append('\n');
			readout.append(RollPrinter.printLaTEXArray(roll, options)).append('\n');
		}
//		readout.append("==============================\n");
//		readout.append("============OTHER=============\n");
//		readout.append("==============================\n");
//		readout.append(RollPrinter.printDecomposedRolls(rolls.get(rolls.size() - 1)));

		Files.write(new File("Results.txt").toPath(), readout.toString().getBytes("UTF-8"));

		boolean MONTE_CARLO = false;

		ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		List<Future<Pair<Rollable, Double>>> testingResults = new ArrayList<>();
		if (MONTE_CARLO) {
			for (final Rollable roll : rolls) {
				testingResults.add(executor.submit(() -> {
					long sum = 0;
					Random engine = new Random();
					final int SIZE = 10_000_000;
					for (int i = 0; i < SIZE; i++) {
						sum += roll.roll(engine).value;
					}
					return Pair.of(roll, sum / (double) SIZE);
				}));
			}
		}
		executor.shutdown();

		JFrame frame = new JFrame("Display");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		JTextArea textArea = new JTextArea(30, 60);
		textArea.setEditable(false);
		textArea.setFont(new Font("Courier New", Font.PLAIN, 12));
		// textArea.getDocument().
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JLabel statusBar = new JLabel();
		statusBar.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		frame.getContentPane().add(statusBar, BorderLayout.SOUTH);
		frame.setVisible(true);
		// frame.setResizable(false);
		frame.pack();
		frame.setLocationRelativeTo(null);
		textArea.setText(readout.toString());

		if (MONTE_CARLO) {
			for (int index = 0; index < testingResults.size(); index++) {
				Future<Pair<Rollable, Double>> future = testingResults.get(index);
				Pair<Rollable, Double> result = future.get();
				readout.append("Monte Carlo'd average for \"" + result.first.getName() + "\": " + result.second)
						.append('\n');
				statusBar.setText(String.format("Monte-Carlo Progress: %d/%d (%5.2f%%)", index,
						testingResults.size(), (float) index / testingResults.size() * 100));
				statusBar.repaint();
			}
			statusBar.setText(String.format("Monte-Carlo Progress: %d/%d (%5.2f%%)", testingResults.size(),
					testingResults.size(), (float) testingResults.size() / testingResults.size() * 100));
			statusBar.repaint();
			textArea.setText(readout.toString());
			frame.repaint();
		}
	}
}
