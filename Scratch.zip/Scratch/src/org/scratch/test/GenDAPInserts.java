package org.scratch.test;

import java.util.List;

import java.util.Arrays;

public class GenDAPInserts {
	public static void main(String[] args) {
		List<String> tableNames = Arrays.asList(
			"TACCESS_DATA",
			"TEVENT_ATTEMPT",
			"TORDER_DOC",
			"TORDER_PATTERN",
			"TPRINT_PACK",
			"TPRINT_PACK_PAGES",
			"TRTP_BATCH",
			"TRTP_BATCH_HISTORY",
			"TRTP_BATCH_ORDER",
			"TRX_VIAL_LABEL",
			"TORDER",
			"TVIAL_LABEL",
			"TAPP_MSG",
			"TRECOVERY_DETAIL",
			"TRECOVERY_SUMMARY"
		);
		
		List<String> purgeOnly = Arrays.asList(
			"TAPP_MSG",
			"TRECOVERY_DETAIL",
			"TRECOVERY_SUMMARY"
		);
		int[] i = new int[1];
		i[0] = 1;
		tableNames.stream().forEach(table -> {
			for(int j = 1; j <= 5; j++) {
				if(purgeOnly.contains(table) && (j == 1 || j == 3)) {
					continue;
				}
				System.out.println("insert into");
				System.out.println("    TRI.TPROCESS_PARM");
				System.out.println("    (PROCESS_CD, GROUP_NB, PROCESS_SEQ_NB, PARM_TX, PARM_NB, HSC_TRN_CD, HSC_USR_ID, HSC_TS, HSU_TRN_CD, HSU_USR_ID, HSU_TS)");
				System.out.println("values (");
				switch(j) {
				case 1:
					System.out.print("    6, " + i[0] + ", 1, '" + table + "', null, ");
					break;
				case 2:
					if(purgeOnly.contains(table)) {
						System.out.print("    6, " + i[0] + ", 2, '" + table + "', null, ");
					} else {
						System.out.print("    6, " + i[0] + ", 2, '" + table + "_ARCH', null, ");
					}
					break;
				case 3:
					System.out.print("    6, " + i[0] + ", 3, null, 60, ");
					break;
				case 4:
					System.out.print("    6, " + i[0] + ", 4, null, 1278, ");
					break;
				case 5:
					System.out.print("    6, " + i[0] + ", 5, '[GID]', null, ");
					break;
				}
				System.out.println("-1, user, systimestamp, -1, user, systimestamp");
				System.out.println(")");
				System.out.println(";");
			}
			i[0]++;
		});
	}
}
