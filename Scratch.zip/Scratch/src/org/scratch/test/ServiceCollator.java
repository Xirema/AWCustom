package org.scratch.test;

import java.nio.file.Files;
import java.util.List;

import javax.swing.JFileChooser;

public class ServiceCollator {
	public static void main(String[] args) throws Exception {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("File with Service Properties");
		int ret = chooser.showOpenDialog(null);
		if(ret != JFileChooser.APPROVE_OPTION)
			return;
		List<String> lines = Files.readAllLines(chooser.getSelectedFile().toPath());
		for(int i = 0; i < lines.size() - 1; i+= 2) {
			String name = lines.get(i).trim();
			String status = lines.get(i+1).trim();
			System.out.println("initialList.push(new ServiceHealth(info." + name + ", info." + status + "));");
		}
	}
}
