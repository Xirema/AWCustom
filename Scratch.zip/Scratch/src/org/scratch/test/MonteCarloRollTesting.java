package org.scratch.test;

import static org.scratch.main.dice.model.StandardDice.D10;
import static org.scratch.main.dice.model.StandardDice.D12;
import static org.scratch.main.dice.model.StandardDice.D20;
import static org.scratch.main.dice.model.StandardDice.D4;
import static org.scratch.main.dice.model.StandardDice.D6;
import static org.scratch.main.dice.model.StandardDice.D8;

import java.awt.BorderLayout;
import java.awt.Font;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.ExecutionException;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;

import org.scratch.main.dice.model.Outcome;
import org.scratch.main.dice.model.SequentialRoll;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.MapUtil;
import org.scratch.main.util.StringUtil;

public class MonteCarloRollTesting {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		SequentialRoll roll = new SequentialRoll(Arrays.asList(D20, D20, D12, D10, D8, D6, D4));

		TreeMap<Outcome, Integer> results = new TreeMap<>();

		JFrame frame = new JFrame("Display");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		JTextArea textArea = new JTextArea(30, 60);
		textArea.setEditable(false);
		textArea.setFont(new Font("Courier New", Font.PLAIN, 12));
		// textArea.getDocument().
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JLabel statusBar = new JLabel();
		statusBar.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		frame.getContentPane().setLayout(new BorderLayout());
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		frame.getContentPane().add(statusBar, BorderLayout.SOUTH);
		frame.setVisible(true);
		// frame.setResizable(false);
		frame.pack();
		frame.setLocationRelativeTo(null);

		Random engine = new Random();
		long iterations = 0;
		// long lastTime = System.nanoTime();
		// final long interval = 250_000_000;
		while (frame.isVisible()) {
			iterations++;
			// long currentTime = System.nanoTime();
			if ((iterations % 1000) == 1) {
				statusBar.setText("Iterations: " + iterations);
				textArea.setText("Mean: " + String.format("%5.2f", mean(results)) + "\n" + "Mode: " + mode(results)
						+ "\n" + StringUtil.toString(results));
				frame.repaint();
				// lastTime += interval;
			}
			Outcome outcome = roll.roll(engine);
			MapUtil.increment(results, outcome);
		}
	}

	private static double mean(TreeMap<Outcome, Integer> map) {
		BigInteger ret = BigInteger.ZERO;
		BigInteger odds = BigInteger.ZERO;
		for (Outcome outcome : map.keySet()) {
			ret = ret.add(BigInteger.valueOf(outcome.value).multiply(BigInteger.valueOf(map.get(outcome))));
			odds = odds.add(BigInteger.valueOf(map.get(outcome)));
		}
		if (odds.compareTo(BigInteger.ZERO) == 0) {
			odds = BigInteger.ONE;
		}
		return new BigRational(ret, odds).doubleValue();
	}

	private static Outcome mode(TreeMap<Outcome, Integer> map) {
		int highest = 0;
		Outcome ret = null;
		for (Outcome outcome : map.keySet()) {
			if (map.get(outcome) > highest) {
				ret = outcome;
				highest = map.get(outcome);
			}
		}
		return ret;
	}
}
