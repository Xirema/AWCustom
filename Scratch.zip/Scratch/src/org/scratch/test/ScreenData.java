package org.scratch.test;

import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;

public class ScreenData {
	public static void main(String[] args) {
	}
}
