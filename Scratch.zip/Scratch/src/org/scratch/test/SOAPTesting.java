package org.scratch.test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.Name;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

public class SOAPTesting {

	public static void main(String[] args) throws SOAPException, IOException {
		MessageFactory umf = MessageFactory.newInstance();

		SOAPMessage soapMessage = umf.createMessage();
		SOAPPart soapPart = soapMessage.getSOAPPart();
		SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
		SOAPBody soapBody = soapEnvelope.getBody();

		Name xsi = soapEnvelope.createName("xmlns:xsi");
		soapEnvelope.addAttribute(xsi, "http://www.w3.org/2001/XMLSchema-instance");

		Name xsd = soapEnvelope.createName("xmlns:xsd");
		soapEnvelope.addAttribute(xsd, "http://www.w3.org/2001/XMLSchema");
		// use the MarkOrdersUploaded functionality of the web service
		Name bodyName = soapEnvelope.createName("MarkOrdersUploaded", "", "");
		SOAPElement bodyElement = soapBody.addBodyElement(bodyName);
		// add <SessionID>seqNumber</SessionID> to <MarkOrdersUploaded>
		Name childName = soapEnvelope.createName("SessionID");
		bodyElement.addChildElement(childName).addTextNode(String.valueOf(8167));
		// add <MarkOrdersUploadedOrderList> to <MarkOrdersUploaded>
		SOAPElement markOrdersUploadedInner = bodyElement.addChildElement("MarkOrdersUploadedOrderList");
		// add <MARK_ORDERS_UPLOADED_PARAMS> to <MarkOrdersUploadedOrderList>
		Name XS = soapEnvelope.createName("MARK_ORDERS_UPLOADED_PARAMS");
		//Name XS = soapEnvelope.createName("MARK_ORDERS_UPLOADED_PARAMS", "ns2", "http://ScanData.com/Caremark/Pharmacy");
		SOAPElement markOrdersUploadedOuter = markOrdersUploadedInner.addChildElement(XS);

		// add the MSN=1 attribute to <MARK_ORDERS_UPLOADED_PARAMS>
		Name msn = soapEnvelope.createName("MSN");
		markOrdersUploadedOuter.addAttribute(msn, "1");
		Name baseNS = soapEnvelope.createName("xmlns");
		markOrdersUploadedOuter.addAttribute(baseNS, "");
		Name extendedNS = soapEnvelope.createName("xmlns:ns2");
		markOrdersUploadedOuter.addAttribute(extendedNS, "http://ScanData.com/Pharmacy");
		// add <UploadID>id</UploadID> to <MARK_ORDERS_UPLOADED_PARAMS>
		markOrdersUploadedOuter.addChildElement("UploadID").addTextNode("1234");
		// add <OrderKey>Orderkey</Orderkey> to <MARK_ORDERS_UPLOADED_PARAMS>
		markOrdersUploadedOuter.addChildElement("OrderKey").addTextNode("6118");

		// add the message's header
		soapMessage.getMimeHeaders().addHeader("SOAPAction", "http://ScanData.com/Pharmacy/MarkOrdersUploaded");
			
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		soapMessage.writeTo(out);
		String ret = out.toString();
		System.out.println(ret);
	}

}
