package org.scratch.test;

import java.io.File;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ScannerSearcher {
	private ExecutorService searchThreads = Executors.newCachedThreadPool();
	private ExecutorService responseThread = Executors.newSingleThreadExecutor();

	public Future<List<File>> searchForFiles(String path, String formattedBrtId) {
		return responseThread.submit(() -> {
			FileList retList = null;
			while(retList == null) {
				synchronized(lock) {
					if(publicFileList == null) {
						Thread.yield();
					} else {
						retList = publicFileList.get(path);
						if(retList == null) {
							pathsToScan.add(path);
						}
					}
				}
			}
			//We only get here if we've successfully acquired the FileList.
			Set<File> fileSet = retList.files.get(formattedBrtId);
			if(fileSet == null) {
				//We found 0 files matching the brtId.
				return new ArrayList<>();
			} else {
				return new ArrayList<>(fileSet);
			}
		});
	}
	
	public ScannerSearcher() {
		searchThreads.submit(() -> {
			try {
				setupScans();
			} catch (Exception e) {
				e.printStackTrace(System.err);
			}
		});
	}
	
	public void shutdown() {
		synchronized(lock) {
			running = false;
		}
	}
	
	private void setupScans() throws InterruptedException, ExecutionException {
		List<Future<Map.Entry<String, FileList>>> futures = new ArrayList<>();
		synchronized(lock) {
			beginSearch = Instant.now();
			for(String path : pathsToScan) {
				futures.add(searchThreads.submit(() -> {
					FileList list = new FileList();
					try(DirectoryStream<Path> stream = Files.newDirectoryStream(new File(path).toPath())) {
						for(Path filePath : stream) {
							list.put(filePath.toFile());
						}
					}
					return new MapEntry(path, list);
				}));
			}
		}
		waitForFutures(futures);
	}
	
	private void waitForFutures(List<Future<Entry<String, FileList>>> futures) throws InterruptedException, ExecutionException {
		Map<String, FileList> privateFileList = new HashMap<>();
		for(Future<Entry<String, FileList>> future : futures) {
			Entry<String, FileList> entry = future.get();
			privateFileList.put(entry.getKey(), entry.getValue());
		}
		synchronized(lock) {
			publicFileList = privateFileList;
			endSearch = Instant.now();
			if(futures.size() > 0)
				System.out.println("The most recent Search took " + Duration.between(beginSearch, endSearch));
			if(running) {
				searchThreads.submit(() -> {
					try {
						setupScans();
					} catch (Exception e) {
						e.printStackTrace(System.err);
					}
				});
			}
		}
	}

	private Instant beginSearch;
	private Instant endSearch;
	private Set<String> pathsToScan = new HashSet<>();
	private Map<String, FileList> publicFileList = null;
	private boolean running = true;
	private Object lock = new Object();
	
	private static class FileList {
		Map<String, Set<File>> files = new HashMap<>();
		
		void put(File file) {
			String fileName = file.getName();
			String brtId;
			try {
				brtId = fileName.substring(0, 5);
			} catch (Exception e) {
				e.printStackTrace(System.err);
				return;
			}
			
			Set<File> currentList = files.get(brtId);
			if(currentList == null) {
				currentList = new TreeSet<>();
				files.put(brtId, currentList);
			}
			currentList.add(file);
		}
	}
	
	private static final class MapEntry implements Map.Entry<String, FileList> {
		public MapEntry(String key, FileList value) {
			this.key = key;
			this.value = value;
		}
		private String key;
		private FileList value;
		@Override
		public String getKey() {
			return key;
		}

		@Override
		public FileList getValue() {
			return value;
		}

		@Override
		public FileList setValue(FileList value) {
			FileList temp = this.value;
			this.value = value;
			return temp;
		}
		
	}

}
