package org.scratch.test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFileChooser;

public class PutPrintpacksInMessage {
	public static void main(String[] args) throws IOException {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select Messages file");
		if(chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) 
			return;
		File messagesFile = chooser.getSelectedFile();
		chooser.setDialogTitle("Select Printpacks file");
		if(chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) 
			return;
		File printpacksFile = chooser.getSelectedFile();
		chooser.setDialogTitle("Select Output File");
		if(chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File outputFile = chooser.getSelectedFile();
		Map<String, String> printpacks = new HashMap<>();
		for(String line : Files.readAllLines(printpacksFile.toPath())) {
			String[] tokens = line.split(":");
			printpacks.put(tokens[0], tokens[1]);
		}
		
		StringBuilder ss = new StringBuilder();
		for(String line : Files.readAllLines(messagesFile.toPath())) {
			int brtIdIndex = line.indexOf("brtId:");
			String brtId = line.substring(brtIdIndex + 7, brtIdIndex + 7 + 15);
			ss.append(line.replace("printpack:\"\"", "printpack:\"" + printpacks.get(brtId) + "\""));
			ss.append('\n');
		}
		Files.write(outputFile.toPath(), ss.toString().getBytes(StandardCharsets.US_ASCII));
	}
}
