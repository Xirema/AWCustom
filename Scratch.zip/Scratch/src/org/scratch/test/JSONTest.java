package org.scratch.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFileChooser;

import org.json.JSONArray;
import org.json.JSONObject;

public class JSONTest {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		JFileChooser chooser = new JFileChooser(".");
		if(chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File file = chooser.getSelectedFile();
		String data = "";
		try(FileInputStream in = new FileInputStream(file)) {
			byte[] buffer = new byte[1 << 20];
			int read;
			while((read = in.read(buffer)) > 0) {
				data += new String(buffer, 0, read, "UTF-8");
			}
		}
		JSONArray object = new JSONArray(data);
		print(object, 0);
		System.out.println(object.toString(2));
//		for(String key : object.keySet()) {
//			
//		}
	}
	
	public static void print(Object object, int level) {
		for(int i = 0; i < level; i++)
			System.out.print("  ");
		if(object instanceof JSONArray) {
			JSONArray array = (JSONArray)object;
			for(Object o : array) {
				print(o, level + 1);
			}
		}
		if(object instanceof JSONObject) {
			JSONObject o = (JSONObject)object;
			for(String key : o.keySet()) {
				print(o.get(key), level + 1);
			}
		}
	}
}
