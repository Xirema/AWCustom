package org.scratch.test;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.scratch.main.dice.model.RollFactory;
import org.scratch.main.dice.model.Rollable;
import org.scratch.main.util.ListAlgorithms;

public class RingRolling {
	public static void main(String[] args) {
		RollFactory factory = new RollFactory();
		Rollable dice = factory.getXdYRoll(3, 6).getRoll();
		
		JFrame frame = new JFrame("Ring Rolling");
		frame.setMinimumSize(new Dimension(270, 320));
		JTextArea textArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(textArea);
		textArea.setMinimumSize(new Dimension(600, 600));
		scrollPane.setMinimumSize(new Dimension(600, 600));
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.setLayout(new BorderLayout());
		frame.add(scrollPane, BorderLayout.CENTER);
		JButton rerollButton = new JButton("Reroll");
		frame.add(rerollButton, BorderLayout.SOUTH);
		Random random = new Random();
		rerollButton.addActionListener(event -> {
			List<Integer> results = Stream.generate(() -> dice.roll(random).value).sequential().limit(12).collect(Collectors.toList());
			StringBuilder builder = new StringBuilder();
			builder.append(ListAlgorithms.toString(results));
			builder.append("\n\n");
			for(int i = 0; i < results.size(); i++) {
				Integer[] stats = new Integer[6];
				for(int j = 0; j < 6; j++) {
					stats[j] = results.get((i + j) % results.size());
				}
				Arrays.sort(stats);
				builder.append(ListAlgorithms.toString(Arrays.asList(stats)));
				builder.append("\n");
			}
			textArea.setText(builder.toString());
			textArea.repaint();
		});
		rerollButton.doClick();
		frame.setVisible(true);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
