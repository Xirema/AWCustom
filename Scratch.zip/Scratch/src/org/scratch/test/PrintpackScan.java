package org.scratch.test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFileChooser;

public class PrintpackScan {
	public static final String MEDGUIDE_IDENTIFIER = "**DFDFDF**";
	public static final String DEMO_LETTER_IDENTIFIER = "**MGMGMG**";
	
	public static void main(String[] args) throws IOException {
		JFileChooser chooser = new JFileChooser();
		int ret = chooser.showOpenDialog(null);
		if(ret != JFileChooser.APPROVE_OPTION)
			return;
		File file = chooser.getSelectedFile();
		String printpack = new String(Files.readAllBytes(file.toPath()), StandardCharsets.US_ASCII);
		List<String> identifiers = getMedguidesAndDemoLetters(printpack);
		for(String string : identifiers) {
			System.out.println(string);
		}
	}
	private static List<String> getMedguidesAndDemoLetters(String printpack) {
		List<String> identifiers = new ArrayList<>();
		int currentIndex = 0;
		if(printpack.length() == 0) {
			return identifiers;
		}
		while(currentIndex != -1) {
			int nextMedguide = printpack.indexOf(MEDGUIDE_IDENTIFIER, currentIndex);
			int nextDemoLetter = printpack.indexOf(DEMO_LETTER_IDENTIFIER, currentIndex);
			int next;
			if(nextMedguide != -1 && nextDemoLetter != -1) {
				next = Math.min(nextMedguide, nextDemoLetter);
			} else {
				next = Math.max(nextMedguide, nextDemoLetter);
			}
			if(nextMedguide != -1 && nextMedguide == next) {
				String medguideIdentifier = printpack.substring(nextMedguide + MEDGUIDE_IDENTIFIER.length(), nextMedguide + MEDGUIDE_IDENTIFIER.length() + 10);
				identifiers.add(medguideIdentifier);
			}
			else if(nextDemoLetter != -1 && nextDemoLetter == next) {
				String demoLetterIdentifier = printpack.substring(nextDemoLetter + DEMO_LETTER_IDENTIFIER.length(), nextDemoLetter + DEMO_LETTER_IDENTIFIER.length() + 6);
				identifiers.add(demoLetterIdentifier);
			}
			if(nextMedguide != -1 && nextDemoLetter != -1) {
				currentIndex = Math.min(nextMedguide, nextDemoLetter);
			} else {
				currentIndex = Math.max(nextMedguide, nextDemoLetter);
			}
			if(currentIndex != -1) {
				currentIndex++;
			}
		}
		return identifiers;
	}
}
