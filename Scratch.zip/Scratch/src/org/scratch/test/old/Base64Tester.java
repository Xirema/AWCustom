package org.scratch.test.old;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.scratch.main.base64.Base64Converter;

public class Base64Tester {
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
		}
		JFileChooser chooser = new JFileChooser();
		int ret = chooser.showOpenDialog(null);
		if (ret != JFileChooser.APPROVE_OPTION)
			return;
		File inFile = chooser.getSelectedFile();
		ret = chooser.showSaveDialog(null);
		if (ret != JFileChooser.APPROVE_OPTION)
			return;
		File outFile = chooser.getSelectedFile();
		String[] options = { "Encode", "Decode" };
		Object choice = JOptionPane.showInputDialog(null, "What operation are you performing?", "BASE64",
				JOptionPane.QUESTION_MESSAGE, null, options, null);
		if (choice == null)
			return;
		try (InputStream inRaw = new FileInputStream(inFile);
				ByteArrayOutputStream outRaw = new ByteArrayOutputStream()) {
			byte[] bytes = new byte[inRaw.available()];
			int read;
			while ((read = inRaw.read(bytes)) != -1) {
				outRaw.write(bytes, 0, read);
			}
			try (InputStream in = new ByteArrayInputStream(outRaw.toByteArray());
					OutputStream out = new FileOutputStream(outFile)) {
				if (choice.equals("Encode")) {
					Base64Converter.encode(in, out);
				} else if (choice.equals("Decode")) {
					Base64Converter.decode(in, out);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
