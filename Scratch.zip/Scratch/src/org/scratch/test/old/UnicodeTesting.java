package org.scratch.test.old;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class UnicodeTesting {
	public static void main(String[] args) throws UnsupportedEncodingException, IOException {
		File file = new File("Results.txt");
		try (PrintStream out = new PrintStream(file)) {
			String chars2 = "\u2554\u2550\u2564\u2557\u2551\u2502\u255f\u2500\u253c\u2562\u255a\u2567\u255d";
			for (int i = 0; i < chars2.length(); i++) {
				char first = chars2.charAt(i);
				int codepoint = chars2.codePointAt(i);
				System.out.printf("\'" + first + "\' = \\u%04x\n", codepoint);
				out.print('\'');
				out.write(("" + first).getBytes("UTF-8"));
				out.printf("\' = \\u%04x\n", codepoint);
			}
			System.out.println("Results saved to " + file.getAbsolutePath());
		}
	}
}
