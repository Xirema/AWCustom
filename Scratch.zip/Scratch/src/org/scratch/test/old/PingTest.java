package org.scratch.test.old;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.swing.JFileChooser;

import org.scratch.main.util.IOUtil;
import org.scratch.test.old.PingTest.PingTestResults.Reachable;

public class PingTest {
	public static class PingTestResults {
		public enum Reachable {
			YES, ONLY_WITH_PING, NO
		}

		Reachable reachable;
		String canonicalName;
		String pingResults;
	}

	public static void main(String[] args)
			throws FileNotFoundException, IOException, InterruptedException, ExecutionException {
		JFileChooser chooser = new JFileChooser();
		chooser.setMultiSelectionEnabled(false);
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setDialogTitle("Open List of Addresses");
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File inFile = chooser.getSelectedFile();
		chooser.setDialogTitle("Where to save Results");
		if (chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File outFile = chooser.getSelectedFile();
		ExecutorService executor = Executors.newFixedThreadPool(4);
		try (FileInputStream instream = new FileInputStream(inFile);
				Scanner scan = new Scanner(instream);
				FileOutputStream outstream = new FileOutputStream(outFile);
				PrintStream out = new PrintStream(outstream)) {
			List<Future<PingTestResults>> futures = new ArrayList<>();
			final List<String> ips = new ArrayList<>();
			while (scan.hasNextLine()) {
				ips.add(scan.nextLine().trim());
			}
			int[] numTested = {0};
			for (int i = 0; i < ips.size(); i++) {
				final int index = i;
				System.out.print("Enqueuing " + ips.get(i) + "             \r");

				futures.add(executor.submit(() -> {
					System.out.print("Testing " + ips.get(index) + "               \r");
					InetAddress address;
					PingTestResults results = new PingTestResults();
					try {
						address = InetAddress.getByName(ips.get(index));
						results.reachable = address.isReachable(5000) ? Reachable.YES : Reachable.NO;
						results.canonicalName = address.getCanonicalHostName();
					} catch (UnknownHostException e) {
						results.reachable = Reachable.NO;
						results.canonicalName = "[UNKNOWN]";
					}

					if (results.reachable == Reachable.NO) {
						List<String> cmd = Arrays.asList("ping", ips.get(index));
						ProcessBuilder builder = new ProcessBuilder(cmd);
						Process process = builder.start();
						try (Scanner scan1 = new Scanner(new InputStreamReader(process.getInputStream()))) {
							while (scan1.hasNextLine()) {
								String line = scan1.nextLine();
								if (line.contains("Reply from")) {
									results.reachable = Reachable.ONLY_WITH_PING;
									break;
								}
								if (line.contains("Request timed out.")) {
									break;
								}
							}
						}
					}
					synchronized(numTested) {
						numTested[0]++;
						System.out.println(numTested[0] + "/" + ips.size() + " have been tested.");
					}
					return results;
				}));
			}
			for (int i = 0; i < futures.size(); i++) {
				Future<PingTestResults> future = futures.get(i);
				PingTestResults ret = future.get();
				IOUtil.println(ips.get(i) + " " + ret.reachable + " " + ret.canonicalName, out);
			}
		} finally {
			executor.shutdown();
		}
	}
}
