package org.scratch.test.old;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;

import org.scratch.main.util.ListAlgorithms;
import org.scratch.main.util.Matrix;
import org.scratch.main.util.SingletonFunctor;
import org.scratch.main.util.functional.MatrixFiller;
import org.scratch.main.util.functional.MatrixPredicate;

public class GenericTestSuite extends TestSuite {
	public static final List<Integer> FIBBONACCI = Collections
			.unmodifiableList(Arrays.asList(55, 2, 3, 21, 34, 5, 0, 1, 8, 13, 1));
	private static final SingletonFunctor<List<Double>> randomNumbersFunctor = new SingletonFunctor<>(() -> {
		Random rand = new Random();
		int size = rand.nextInt(10_000_000) + 2_000_000;
		Double[] nums = new Double[size];
		for (int i = 0; i < size; i++) {
			nums[i] = rand.nextDouble() * 100_000;
		}
		return Collections.unmodifiableList(Arrays.asList(nums));
	});

	public static void main(String[] args) {
		GenericTestSuite test = new GenericTestSuite();
		test.executeTests();
	}

	public void testFibbonacciLookup() {
		List<Integer> list = new ArrayList<>(FIBBONACCI);
		if (ListAlgorithms.selectIndex(list, 0) != 6)
			throw new RuntimeException();
		if (ListAlgorithms.selectIndex(list, 1) != 7 && ListAlgorithms.select(list, 1) != 10)
			throw new RuntimeException();
		if (ListAlgorithms.selectIndex(list, 3) != 1)
			throw new RuntimeException();
		if (ListAlgorithms.selectIndex(list, 4) != 2)
			throw new RuntimeException();
	}

	public void testRandomNumberUse() throws InterruptedException {
		List<Thread> threads = new ArrayList<>();
		for (int i = 0; i < 50; i++) {
			Thread thread;
			threads.add(thread = new Thread(() -> {
				try {
					randomNumbersFunctor.get();
				} catch (InterruptedException | ExecutionException e) {
					e.printStackTrace();
				}
			}));
			thread.start();
		}
		for (Thread thread : threads) {
			thread.join();
		}
	}

	public void testMatrixResizing() {
		MatrixFiller<Integer> filler = (row, column) -> row * column;
		Matrix<Integer> matrix = new Matrix<>(10, 10, filler);
		MatrixPredicate<Integer> tester = (row, column, object) -> (row * column) != object;
		if (matrix.any(tester))
			throw new RuntimeException("Elements were not assigned correctly!");
		matrix.resize(20, 15, filler);
		if (matrix.any(tester))
			throw new RuntimeException("Elements were not reassigned correctly!");
		matrix.resize(8, 7);
		if (matrix.any(tester))
			throw new RuntimeException("Elements were not reassigned correctly!");
		matrix.resize(8, 23, filler);
		if (matrix.any(tester))
			throw new RuntimeException("Elements were not reassigned correctly!");
		matrix.resize(20, 23, filler);
		if (matrix.any(tester))
			throw new RuntimeException("Elements were not reassigned correctly!");
	}

	private double regFunc(double value) {
		return Math.sin(value) + Math.cos(value);
	}

	private double simpleFunc(double value) {
		return Math.cos(value - Math.PI / 4) * Math.sqrt(2);
	}

	public void testMath() throws InterruptedException {
		Random rand = new Random();
		for (int i = 0; i < 1_000_000; i++) {
			double input = rand.nextDouble();
			double regular = regFunc(input);
			double simplified = simpleFunc(input);
			double ratio = (Math.abs(regular) > Math.abs(simplified)) ? simplified / regular : regular / simplified;
			ratio = 1 - Math.abs(ratio);
			if (ratio > 0.0000001) {
				System.out.println("Calculation was significantly off!");
				System.out.println("    Regular: " + regular + " Simplified: " + simplified);
				System.out.println("    Ratio: " + ratio * 100);
				Thread.sleep(2000);
			}
		}
	}
}
