package org.scratch.test.old;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.swing.JFileChooser;

public class FirewallApplicationMap {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setMultiSelectionEnabled(false);

		chooser.setDialogTitle("Open Hostnames");
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File hostnameFile = chooser.getSelectedFile();

		chooser.setDialogTitle("Open Hostname-Application Map");
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File hostnameApplicationFile = chooser.getSelectedFile();

		chooser.setDialogTitle("Open Relevant Applications");
		if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File applicationFile = chooser.getSelectedFile();

		chooser.setDialogTitle("Save Results");
		if (chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File resultsFile = chooser.getSelectedFile();

		try (FileInputStream hostnameStream = new FileInputStream(hostnameFile);
				FileInputStream hostnameApplicationStream = new FileInputStream(hostnameApplicationFile);
				FileInputStream applicationStream = new FileInputStream(applicationFile);
				FileOutputStream resultsStream = new FileOutputStream(resultsFile);
				Scanner hostnameScanner = new Scanner(hostnameStream);
				Scanner hostnameApplicationScanner = new Scanner(hostnameApplicationStream);
				Scanner applicationScanner = new Scanner(applicationStream);
				PrintStream out = new PrintStream(resultsStream)) {
			TreeSet<String> hostnames = new TreeSet<>(), applications = new TreeSet<>();
			TreeMap<String, TreeSet<String>> hostnameApplicationMap = new TreeMap<>();
			while (hostnameScanner.hasNextLine()) {
				String hostname = hostnameScanner.nextLine().trim();
				hostnames.add(hostname);
				hostnameApplicationMap.put(hostname, new TreeSet<String>());
			}
			while (applicationScanner.hasNextLine()) {
				String application = applicationScanner.nextLine().trim();
				applications.add(application);
			}

			while (hostnameApplicationScanner.hasNextLine()) {
				String[] tokens = hostnameApplicationScanner.nextLine().trim().split("\t");
				String hostname = tokens[0].trim();
				String applicationName = tokens[2].trim();
				if (hostnames.contains(hostname) && applications.contains(applicationName)) {
					hostnameApplicationMap.get(hostname).add(applicationName);
				}
			}
			for (String hostname : hostnameApplicationMap.keySet()) {
				out.println(hostname + "\t" + toString(hostnameApplicationMap.get(hostname)));
			}
		}

	}

	private static String toString(TreeSet<String> set) {
		if (set.size() == 0)
			return "[]";
		Iterator<String> iterator = set.iterator();
		String ret = "[" + iterator.next();
		while (iterator.hasNext()) {
			ret += "," + iterator.next();
		}
		return ret + "]";
	}
}
