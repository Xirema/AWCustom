package org.scratch.test.old;

public class ByteTester {
	public static void main(String[] args) {
		for (byte b = Byte.MIN_VALUE; b < Byte.MAX_VALUE; b++) {
			System.out.println("[" + b + ">" + (b & 0xff) + "]");
		}
	}
}
