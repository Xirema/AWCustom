package org.scratch.test.old;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;

public class GridLayoutTest {
	public static void main(String[] args) throws InterruptedException {
		final JFrame frame = new JFrame("GridLayout Testing");
		// JPanel rootPanel = new JPanel();
		// rootPanel.setLayout(new FlowLayout());
		final JPanel panel = new JPanel();
		final GridBagLayout layout = new GridBagLayout();
		// GridLayout layout = new GridLayout(20, 20);
		panel.setLayout(layout);
		// frame.setContentPane(rootPanel);
		// rootPanel.add(panel);
		frame.setContentPane(panel);
		frame.setVisible(true);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		for (int i = 1; i <= 400; i++) {
			final int sqrt = 20;// (int)Math.ceil(Math.sqrt(i));
			final int curr = i;
			SwingUtilities.invokeLater(() -> {
				layout.columnWidths = getSizes(20);
				layout.rowHeights = getSizes(20);
				JToggleButton newButton = new JToggleButton("" + curr);
				newButton.setPreferredSize(new Dimension(20, 20));
				GridBagConstraints constraints = new GridBagConstraints();
				constraints.gridx = (curr - 1) % sqrt;
				constraints.gridy = ((curr - 1) / sqrt) % sqrt;
				constraints.gridwidth = constraints.gridheight = 1;
				constraints.fill = GridBagConstraints.BOTH;
				constraints.anchor = GridBagConstraints.CENTER;
				panel.add(newButton, constraints);
				// panel.add(newButton);
				frame.pack();
			});
			Thread.sleep(200);
		}
	}

	private static int[] getSizes(int num) {
		int[] sizes = new int[num];
		for (int i = 0; i < num; i++) {
			sizes[i] = 20;
		}
		return sizes;
	}

	private static double[] getWeights(int num) {
		double[] weights = new double[num];
		for (int i = 0; i < num; i++) {
			weights[i] = 0.05;
		}
		return weights;
	}
}
