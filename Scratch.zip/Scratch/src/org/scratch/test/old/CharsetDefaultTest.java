package org.scratch.test.old;

import java.nio.charset.Charset;
import java.util.Random;

public class CharsetDefaultTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Charset charset = Charset.defaultCharset();
		System.out.println("Default Charset is " + charset.displayName());

		Charset utf8 = Charset.forName("utf-8");

		System.out.println("Current Charset is " + utf8.displayName());

		Random rand = new Random();
		for (int i = 0; i < 10000; i++) {
			int size = rand.nextInt(20) + 5;
			byte[] randBytes = new byte[size];
			rand.nextBytes(randBytes);
			String converted = new String(randBytes, utf8);
			if (randBytes.length != converted.length()) {
				System.err.println("Byte array got shrunk in conversion!");
				System.err.print("Bytes:");
				for (byte b : randBytes) {
					System.err.print("\'" + (char) b + "\'(" + (int) b + ") ");
				}
				System.err.println();
				System.err.print("String:");
				for (char c : converted.toCharArray()) {
					System.err.print("\'" + c + "\'(" + (int) c + ") ");
				}
				System.err.println();
				throw new RuntimeException();
			}
		}
	}

}
