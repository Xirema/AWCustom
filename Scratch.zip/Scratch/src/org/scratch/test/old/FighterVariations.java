package org.scratch.test.old;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import java.util.Optional;

public class FighterVariations {
	private static class ID implements Comparable<ID> {
		public final int id;
		private static int gid = 0;
		private static HashMap<String, Integer> idMap = new HashMap<>();
		private static HashMap<Integer, String> backMap = new HashMap<>();

		public ID(String name) {
			id = getId(name);
		}

		private static synchronized int getId(String name) {
			Optional<Integer> canonId = Optional.ofNullable(idMap.get(name));
			if (canonId.isPresent())
				return canonId.get();
			else {
				int id = gid++;
				idMap.put(name, id);
				backMap.put(id, name);
				return id;
			}
		}

		@Override
		public String toString() {
			return "[\"" + backMap.get(id) + "\"-" + id + "]";
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			else if (getClass().equals(o.getClass()))
				return ((ID) o).id == id;
			else
				return false;
		}

		@Override
		public int compareTo(ID o) {
			return id - o.id;
		}

		@Override
		public int hashCode() {
			return Objects.hash(id);
		}
	}

	private static class Option implements Comparable<Option> {
		public final ID id;
		public final ID value;

		public Option(ID id, ID value) {
			this.id = id;
			this.value = value;
		}

		public Option(String name, String value) {
			this(new ID(name), new ID(value));
		}

		public static Option of(String name, String value) {
			return new Option(name, value);
		}

		@Override
		public int compareTo(Option o) {
			return id.compareTo(o.id);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			else if (getClass().equals(o.getClass())) {
				Option op = (Option) o;
				return op.id.equals(id) && op.value.equals(value);
			} else
				return false;
		}
	}

	private static List<Option> fightingStyleOptions() {
		String name = "Fighting Style";
		return Arrays.asList(Option.of(name, "Archery"), Option.of(name, "Defense"), Option.of(name, "Dueling"),
				Option.of(name, "Great Weapon Fighting"), Option.of(name, "Protection"),
				Option.of(name, "Two-Weapon-Fighting"));
	}

	private static List<List<Option>> abilityScoreIncreases() {
		String name = "ASI";
		List<List<Option>> options = new ArrayList<>();
		List<Option> subOptions = Arrays.asList(Option.of(name, "+1STR"), Option.of(name, "+1DEX"),
				Option.of(name, "+1CON"), Option.of(name, "+1INT"), Option.of(name, "+1WIS"), Option.of(name, "+1CHA"));

		for (int i = 0; i < subOptions.size(); i++) {
			for (int j = 0; j < subOptions.size(); j++) {
				List<Option> sub = Arrays.asList(subOptions.get(i), subOptions.get(j));
				Collections.sort(sub);
				options.add(sub);
			}
		}
		return options;
	}

	private static List<List<Option>> feats() {
		String name = "Feat";
		List<List<Option>> options = Arrays.asList(Arrays.asList(Option.of(name, "actor_phb")),
				Arrays.asList(Option.of(name, "alert_phb")),
				Arrays.asList(Option.of(name, "athlete_phb"), Option.of("ASI", "+1STR")),
				Arrays.asList(Option.of(name, "athlete_phb"), Option.of("ASI", "+1DEX")),
				Arrays.asList(Option.of(name, "charger_phb")), Arrays.asList(Option.of(name, "crossbow%20expert_phb")),
				Arrays.asList(Option.of(name, "defensive%20duelist_phb")),
				Arrays.asList(Option.of(name, "dual%20wielder_phb")),
				Arrays.asList(Option.of(name, "dungeon%20delver_phb")), Arrays.asList(Option.of(name, "durable_phb")),
				Arrays.asList(Option.of(name, "elemental%20adept_phb")), Arrays.asList(Option.of(name, "grappler_phb")),
				Arrays.asList(Option.of(name, "great%20weapon%20master_phb")),
				Arrays.asList(Option.of(name, "healer_phb")), Arrays.asList(Option.of(name, "heavily%20armored_phb")),
				Arrays.asList(Option.of(name, "heavy%20armor%20master_phb")),
				Arrays.asList(Option.of(name, "inspiring%20leader_phb")),
				Arrays.asList(Option.of(name, "keen%20mind_phb")),
				// Arrays.asList(Option.of(name, "lightly%20armored_phb")),
				// Arrays.asList(Option.of(name, "linguist_phb")),
				Arrays.asList(Option.of(name, "lucky_phb")), Arrays.asList(Option.of(name, "mage%20slayer_phb")),
				// Arrays.asList(Option.of(name, "magic%20initiate_phb")),
				Arrays.asList(Option.of(name, "martial%20adept_phb")),
				Arrays.asList(Option.of(name, "medium%20armor%20master_phb")),
				Arrays.asList(Option.of(name, "mobile_phb")),
				// Arrays.asList(Option.of(name, "moderately%20armored_phb")),
				Arrays.asList(Option.of(name, "mounted%20combatant_phb")),
				Arrays.asList(Option.of(name, "observant_phb")), Arrays.asList(Option.of(name, "polearm%20master_phb")),
				Arrays.asList(Option.of(name, "resilient_phb")), Arrays.asList(Option.of(name, "ritual%20caster_phb")),
				Arrays.asList(Option.of(name, "savage%20attacker_phb")), Arrays.asList(Option.of(name, "sentinel_phb")),
				Arrays.asList(Option.of(name, "sharpshooter_phb")),
				Arrays.asList(Option.of(name, "shield%20master_phb")), Arrays.asList(Option.of(name, "skilled_phb")),
				Arrays.asList(Option.of(name, "skulker_phb")), Arrays.asList(Option.of(name, "spell%20sniper_phb")),
				Arrays.asList(Option.of(name, "tavern%20brawler_phb")), Arrays.asList(Option.of(name, "tough_phb")),
				Arrays.asList(Option.of(name, "war%20caster_phb")),
				Arrays.asList(Option.of(name, "weapon%20master_phb")));
		return options;
	}

}
