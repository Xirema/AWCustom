package org.scratch.test.old;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;

import org.scratch.main.util.ListAlgorithms;

public class HandCombinations {
	public static void main(String[] args) {
		List<Integer> possibleCards = ListAlgorithms.getRun(0, 4);
		Comparator<List<Integer>> comparator = (o1, o2) -> {
			if (o1.size() != o2.size())
				return o1.size() - o2.size();
			for (int i = 0; i < o1.size(); i++) {
				if (o1.get(i) != o2.get(i))
					return o1.get(i) - o2.get(i);
			}
			return 0;
		};
		TreeSet<List<Integer>> replacements = new TreeSet<>(comparator);
		replacements.add(new ArrayList<Integer>());
		replacements.add(new ArrayList<>(possibleCards));
		for (int card : possibleCards) {
			replacements.add(Arrays.asList(card));
			List<Integer> minusOne = new ArrayList<>(possibleCards);
			minusOne.remove((Object) card);
			Collections.sort(minusOne);
			replacements.add(minusOne);
			for (int card2 : minusOne) {
				List<Integer> pair = Arrays.asList(card, card2);
				Collections.sort(pair);
				replacements.add(pair);
				List<Integer> minusTwo = new ArrayList<>(possibleCards);
				minusTwo.removeAll(pair);
				Collections.sort(minusTwo);
				replacements.add(minusTwo);
			}
		}
		System.out.println("Number of combinations: " + replacements.size());
		for (List<Integer> runs : replacements) {
			System.out.println("    " + ListAlgorithms.toString(runs));
		}
	}
}
