package org.scratch.test.old;

import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;
import java.util.concurrent.atomic.AtomicBoolean;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;
import javax.swing.WindowConstants;

import org.scratch.main.dice.model.Outcome;
import org.scratch.main.dice.model.RollFactory;
import org.scratch.main.dice.model.Rollable;
import org.scratch.main.dice.model.StandardDice;
import java.util.Optional;

public class ChaosBoltTester {
	public static void main(String[] args) {
		Rollable attackRoll = factory.getAttackRoll(0).getRoll();
		// Rollable attackRoll = factory.getAttackRoll(0,
		// RollFactory.Advantage.DOUBLE_ADVANTAGE);
		Map<Integer, Integer> normalResults = new TreeMap<>();
		Map<Integer, Integer> specialResults = new TreeMap<>();

		JFrame frame = new JFrame("Display");
		frame.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		JTextArea textArea = new JTextArea(30, 60);
		textArea.setEditable(false);
		textArea.setFont(new Font("Courier New", Font.PLAIN, 16));
		JScrollPane scrollPane = new JScrollPane(textArea);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		frame.getContentPane().add(scrollPane);
		frame.setVisible(true);
		frame.setResizable(false);
		frame.pack();
		final AtomicBoolean running = new AtomicBoolean(true);
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent arg0) {
				running.set(false);
			}
		});
		final AtomicBoolean shouldPrintResults = new AtomicBoolean(true);
		Timer updateTimer = new Timer(500, arg0 -> shouldPrintResults.set(true));
		updateTimer.start();
		Random engine = new Random();
		while (running.get()) {
			int normal = getChaosBoltDamage(engine, 1, attackRoll, 7, false, false);
			int special = getChaosBoltDamage(engine, 1, attackRoll, 7, true, false);
			normalResults.put(normal, Optional.ofNullable(normalResults.get(normal)).orElse(0) + 1);
			specialResults.put(special, Optional.ofNullable(specialResults.get(special)).orElse(0) + 1);
			if (shouldPrintResults.get()) {
				shouldPrintResults.set(false);
				setTextArea(textArea, Arrays.asList(normalResults, specialResults));
			}
		}
		updateTimer.stop();
	}

	static void setTextArea(JTextArea textArea, List<Map<Integer, Integer>> results) {
		StringBuilder builder = new StringBuilder();
		for (Map<Integer, Integer> map : results) {
			long total = 0;
			long all = 0;
			for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
				builder.append(entry.getKey() + ": " + entry.getValue() + "\n");
				total += entry.getKey() * entry.getValue();
				all += entry.getValue();
			}
			double mean = total / (double) all;
			builder.append("\n");
			builder.append("Mean: " + mean + "\n");
			builder.append("\n\n\n");
		}
		textArea.setText(builder.toString());
	}

	static RollFactory factory = new RollFactory();
	static Map<Integer, Rollable> normalDamage = new HashMap<>();
	static Map<Integer, Rollable> critDamage = new HashMap<>();

	public static int getChaosBoltDamage(Random engine, int level, Rollable attackRoll, int ac, boolean specialRules,
			boolean autoCrit) {
		int damage = 0;
		Outcome to_hit = attackRoll.roll(engine);
		if (autoCrit) {
			to_hit = new Outcome(to_hit.value, 1);
		}
		if (to_hit.special < 0 || to_hit.value < ac)
			return 0;
		Rollable d8 = StandardDice.D8;
		Rollable normal = normalDamage.get(level);
		if (normal == null) {
			normal = factory.getXdYRoll(level, 6).getRoll();
			normalDamage.put(level, normal);
		}
		Rollable crit = critDamage.get(level);
		if (crit == null) {
			crit = factory.getXdYRoll(level * 2, 6).getRoll();
			critDamage.put(level, crit);
		}
		Outcome norm = normal.roll(engine);
		Outcome cri = crit.roll(engine);
		Map<Integer, Integer> matching = new HashMap<>();
		if (to_hit.special > 0) {
			for (int i = 0; i < 4; i++) {
				Outcome face = d8.roll(engine);
				if (i < 2 || specialRules) {
					matching.put(face.value, Optional.ofNullable(matching.get(face.value)).orElse(0) + 1);
				}
				damage += face.value;
			}
			damage += cri.value;
		} else {
			for (int i = 0; i < 2; i++) {
				Outcome face = d8.roll(engine);
				damage += face.value;
			}
			damage += norm.value;
		}

		for (Map.Entry<Integer, Integer> entry : matching.entrySet()) {
			if (entry.getValue() == 2) {
				damage += getChaosBoltDamage(engine, level, attackRoll, ac, specialRules, false);
			} else if (entry.getValue() == 3) {
				damage += getChaosBoltDamage(engine, level, attackRoll, ac, specialRules, true);
			} else if (entry.getValue() == 4) {
				damage += getChaosBoltDamage(engine, level, attackRoll, ac, specialRules, true);
				damage += getChaosBoltDamage(engine, level, attackRoll, ac, specialRules, true);
			}
		}

		return damage;
	}
}
