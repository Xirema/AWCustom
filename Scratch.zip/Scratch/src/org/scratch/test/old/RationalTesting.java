package org.scratch.test.old;

import java.util.ArrayList;
import java.util.List;

import org.scratch.main.util.BigRational;

public class RationalTesting {
	private static boolean equivalent(double a, double b) {
		return a == b || Math.nextAfter(a, b) == b;
	}
	public static void main(String[] args) {
		List<Runnable> tests = new ArrayList<>();
		tests.add(() -> {
			double value = 0.5;
			BigRational converted = BigRational.from(value);
			double value2 = converted.doubleValue();
			if(value != value2)
				throw new RuntimeException("Value did not convert correctly!");
		});
		tests.add(() -> {
			double value = 0.567891234567891234;
			BigRational converted = BigRational.from(value);
			double value2 = converted.doubleValue();
			if(value != value2)
				throw new RuntimeException("Value did not convert correctly!");
		});
		tests.add(() -> {
			double value = Double.MIN_VALUE * 50;
			BigRational converted = BigRational.from(value);
			double value2 = converted.doubleValue();
			if(!equivalent(value, value2))
				throw new RuntimeException("Value did not convert correctly!\n"
					+ String.format("%g vs %g\n", value, value2)
					+ String.format("0x%016X vs 0x%016X\n", Double.doubleToRawLongBits(value), Double.doubleToRawLongBits(value2))
					+ converted.toString() + "\n");
		});
		
		
		int index = 0;
		for(Runnable test : tests) {
			try {
				test.run();
				System.out.println("Test " + (index + 1) + " Succeeded.");
			} catch(Throwable e) {
				System.err.println("Test " + (index + 1) + " failed.");
				e.printStackTrace(System.err);
			}
			index++;
		}
	}
}
