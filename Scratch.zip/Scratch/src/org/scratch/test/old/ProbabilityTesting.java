package org.scratch.test.old;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.scratch.main.util.Pair;

public class ProbabilityTesting {
	private static class Calculator implements Callable<Pair<Integer, Integer>> {
		private boolean use_passive;
		private int attacker_bonus;
		private int defender_bonus;
		private int num_of_trials;

		public Calculator(boolean use_passive, int attacker_bonus, int defender_bonus, int num_of_trials) {
			this.use_passive = use_passive;
			this.attacker_bonus = attacker_bonus;
			this.defender_bonus = defender_bonus;
			this.num_of_trials = num_of_trials;
		}

		@Override
		public Pair<Integer, Integer> call() throws Exception {
			int successes = 0;
			Random rand = new Random();
			for (int i = 0; i < num_of_trials; i++) {
				int attacker_score = rand.nextInt(20) + 1 + attacker_bonus;
				int defender_score;
				if (use_passive) {
					defender_score = 10 + defender_bonus;
				} else {
					defender_score = rand.nextInt(20) + 1 + defender_bonus;
				}
				// Attacker wins ties
				if (attacker_score >= defender_score) {
					successes++;
				}
			}
			return Pair.of(successes, num_of_trials);
		}
	}

	private static class ResultSet {
		public final Future<Pair<Integer, Integer>> active, passive;
		public final int attacker_bonus, defender_bonus;

		public ResultSet(Future<Pair<Integer, Integer>> active, Future<Pair<Integer, Integer>> passive,
				int attacker_bonus, int defender_bonus) {
			this.active = active;
			this.passive = passive;
			this.attacker_bonus = attacker_bonus;
			this.defender_bonus = defender_bonus;
		}
	}

	public static void main(String[] args) throws Exception {
		ExecutorService executor = Executors.newFixedThreadPool(4);
		List<ResultSet> results = new ArrayList<>();
		for (int i = 0; i < 60; i++) {
			int attacker_bonus, defender_bonus;
			if (i < 21) {
				attacker_bonus = i;
				defender_bonus = 0;
			} else if (i < 41) {
				attacker_bonus = 0;
				defender_bonus = i - 20;
			} else {
				attacker_bonus = i - 39;
				defender_bonus = attacker_bonus - 1;
			}
			results.add(
					new ResultSet(executor.submit(new Calculator(false, attacker_bonus, defender_bonus, 10_000_000)),
							executor.submit(new Calculator(true, attacker_bonus, defender_bonus, 10_000_000)),
							attacker_bonus, defender_bonus));
		}
		for (ResultSet result : results) {
			Pair<Integer, Integer> active_results = result.active.get(), passive_results = result.passive.get();
			System.out.println("Attacker: " + result.attacker_bonus + ", Defender: " + result.defender_bonus);
			System.out.println("Active Results:  " + active_results.first + " out of " + active_results.second + " ("
					+ (active_results.first / (double) active_results.second * 100) + "%)");
			System.out.println("Passive Results: " + passive_results.first + " out of " + passive_results.second + " ("
					+ (passive_results.first / (double) passive_results.second * 100) + "%)");
			System.out.println();
		}
		executor.shutdown();
		executor.awaitTermination(0, TimeUnit.SECONDS);
	}
}
