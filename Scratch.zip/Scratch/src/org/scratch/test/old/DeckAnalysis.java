package org.scratch.test.old;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.scratch.main.util.BigRational;
import java.util.Optional;
import org.scratch.main.util.Pair;

public class DeckAnalysis {
	public static enum CardType {
		FATES, VIZIER, COMET, GEM, JESTER, KEY, KNIGHT, MOON, STAR, SUN, BALANCE, THRONE, RUIN, FOOL, FLAMES, ROGUE, DONJON, EURYALE, IDIOT, TALONS, SKULL, VOID
	}

	public static enum Value {
		GOOD, BAD, NEUTRAL
	}

	public static class Card {
		public final CardType type;

		public Card(CardType type) {
			this.type = type;
		}

		public String getName() {
			return type.toString();
		}

		public Value getValue() {
			switch (type) {
			case FATES:
			case VIZIER:
			case COMET:
			case GEM:
			case JESTER:
			case KEY:
			case KNIGHT:
			case MOON:
			case STAR:
			case SUN:
				return Value.GOOD;
			case BALANCE:
			case THRONE:
			case RUIN:
			case FLAMES:
			case FOOL:
				return Value.NEUTRAL;
			case ROGUE:
			case DONJON:
			case EURYALE:
			case IDIOT:
			case TALONS:
			case SKULL:
			case VOID:
				return Value.BAD;
			default:
				throw new RuntimeException("We didn't cover " + getName() + "!");
			}
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (this.getClass().equals(o.getClass()))
				return ((Card) o).type.equals(type);
			else
				return false;
		}

		@Override
		public int hashCode() {
			return type.hashCode();
		}
	}

	public static boolean contains(Set<CardType> cards, CardType type) {
		for (CardType card : cards) {
			if (card.equals(type))
				return true;
		}
		return false;
	}

	public static boolean containsAny(Set<CardType> cards, Collection<CardType> types) {
		for (CardType card : cards) {
			if (types.contains(card))
				return true;
		}
		return false;
	}

	public static Set<CardType> with(Set<CardType> cards, CardType next) {
		Set<CardType> newCards = new HashSet<>(cards);
		newCards.add(next);
		return newCards;
	}

	public static int count(Set<CardType> cards, Value value) {
		int total = 0;
		for (CardType type : cards) {
			if (new Card(type).getValue().equals(value)) {
				total++;
			}
		}
		return total;
	}

	public static void main(String[] args) {
		Set<CardType> types = new HashSet<>(Arrays.asList(CardType.values()));
		Map<Set<CardType>, BigRational> results = new HashMap<>();
		Map<Pair<Integer, Integer>, BigRational> finalResults = new TreeMap<>();
		for (CardType type : types) {
			results.put(new HashSet<>(Arrays.asList(type)), new BigRational(1, types.size()));
		}

		Set<CardType> stoppers = new HashSet<>(Arrays.asList(CardType.TALONS, CardType.SKULL, CardType.VOID));

		final long period = 1_000_000_000L / 2;
		long lastUpdate = System.nanoTime() - period;

		boolean done = false;
		while (!done) {
			long now = System.nanoTime();
			if (now - lastUpdate > period) {
				lastUpdate += period;
				System.err.println("Num of Results: " + results.size());
				System.err.println("Num of Final Results: " + finalResults.size());
			}
			Map<Set<CardType>, BigRational> newResults = new HashMap<>();
			done = true;
			for (Set<CardType> set : results.keySet()) {
				if (!containsAny(set, stoppers)) {
					done = false;
					Set<CardType> availableCards = new HashSet<>(types);
					availableCards.removeAll(set);

					for (CardType type : availableCards) {
						Set<CardType> newSet = with(set, type);
						BigRational num = Optional.ofNullable(newResults.get(newSet)).orElse(BigRational.ZERO);
						num = num.plus(results.get(set).divides(new BigRational(availableCards.size())));
						newResults.put(newSet, num);
					}
				} else {
					int goodCount = count(set, Value.GOOD);
					Pair<Integer, Integer> run = Pair.of(goodCount, set.size());
					BigRational num = Optional.ofNullable(finalResults.get(run)).orElse(BigRational.ZERO);
					num = num.plus(results.get(set));
					finalResults.put(run, num);
				}
			}
			results = newResults;
		}

		System.out.println("Results:");
		BigRational total = BigRational.ZERO;
		BigRational relevantTotal = BigRational.ZERO;
		for (Pair<Integer, Integer> run : finalResults.keySet()) {
			BigRational result = finalResults.get(run);
			if (run.first > 0 && run.first - run.second == -1) {
				relevantTotal = relevantTotal.plus(result);
			}
			System.out.println(run + ": " + result + " (" + result.doubleValue() + ")");
			total = total.plus(result);
		}

		System.out.println("Total was " + total);
		System.out.println("Relevant Total was " + relevantTotal);
	}
}
