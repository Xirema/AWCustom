package org.scratch.test.old;

import java.awt.Container;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

public class MemoryLeakTesting {
	public static void main(String[] args) {
		try {
			testAbandonedFileHandles();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	static volatile int value = 0;

	public static void testAbandonedFileHandles() throws FileNotFoundException, InterruptedException {
		File file = new File("Testing.txt");
		for (int i = 0; i < 1_000_000; i++) {
			PrintWriter out = new PrintWriter(file);
			out.println(value++);
			out.flush();
			if (i % 1_000 == 0) {
				System.out.println(i);
			}
		}
	}

	public static void testAbandonedThreads() throws InterruptedException {
		final ArrayList<String> strings = new ArrayList<>();
		for (int i = 0; i < 1_000_000; i++) {
			new Thread() {
				@Override
				public void run() {
					String id = String.format("%08x", Thread.currentThread().getId());

					strings.add(id);
					if (strings.size() > 5) {
						strings.remove(0);
					}
				}
			}.start();
			Thread.sleep(50);
		}
	}

	public static void testFrame() {
		final JFrame frame = new JFrame("Memory Leak?");

		GridLayout layout = new GridLayout(2, 1);
		final Container panel = frame.getContentPane();
		panel.setLayout(layout);
		final JButton button = new JButton("Sup.");
		final JTextArea textBox = new JTextArea(5, 40);
		textBox.setEditable(false);
		final ArrayList<String> strings = new ArrayList<>();
		button.addActionListener(arg0 -> {
			Thread thread = new Thread() {
				@Override
				public void run() {
					String id = String.format("%08x", Thread.currentThread().getId());

					strings.add(id);
					if (strings.size() > 5) {
						strings.remove(0);
					}
					StringBuilder ss = new StringBuilder();
					for (String string : strings) {
						ss.append(string);
						ss.append('\n');
					}
					final String out = ss.toString();
					SwingUtilities.invokeLater(() -> textBox.setText(out));
				}
			};
			thread.setDaemon(true);
			thread.start();
		});
		panel.add(button);
		panel.add(textBox);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
	}
}
