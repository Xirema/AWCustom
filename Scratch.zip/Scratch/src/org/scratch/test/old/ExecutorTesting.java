package org.scratch.test.old;

import java.util.Random;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ExecutorTesting {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		final ScheduledExecutorService executor = Executors.newScheduledThreadPool(4);

		while (true) {
			Runnable task = new Runnable() {
				int val = 0;

				@Override
				public void run() {
					val++;
					if (val > 10)
						// Simulates something going wrong
						throw new RuntimeException();
					System.out.println(val);
				}
			};
			final Future<?> future = executor.scheduleAtFixedRate(task, 0, 1000, TimeUnit.MILLISECONDS);

			Runnable task2 = () -> future.cancel(false);
			int task2Delay = new Random().nextInt(8) + 3;
			System.out.println("Delay is " + task2Delay + "s.");
			final Future<?> future2 = executor.schedule(task2, task2Delay, TimeUnit.SECONDS);
			try {
				future.get();
			} catch (CancellationException e) {
				System.out.println("Normal Cancellation.");
			} catch (ExecutionException e) {
				System.err.println("Something went wrong during the execution, and it was not stopped normally!");
				break;
			}
			try {
				future2.get();
			} catch (CancellationException e) {
				// Shouldn't happen?
				e.printStackTrace();
			}
		}
		System.err.println("The task did not complete successfully!");
		executor.shutdown();
	}
}
