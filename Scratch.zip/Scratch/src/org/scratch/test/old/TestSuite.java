package org.scratch.test.old;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public abstract class TestSuite {
	public void executeTests() {
		Method[] methods = getClass().getMethods();
		for (Method method : methods) {
			String name = method.getName();

			if (name.length() >= 4 && name.substring(0, 4).equals("test")) {
				System.out.print("Testing \"" + method.getName() + "\": ");
				try {
					method.invoke(this);
					System.out.println("Passed.");
				} catch (InvocationTargetException e) {
					System.out.println("Failed!");
					e.getCause().printStackTrace(System.out);
				} catch (Throwable e) {
					System.out.println("Failed!");
					e.printStackTrace(System.out);
				}
			}
		}
	}
}
