package org.scratch.test.old;

import java.util.Random;

import org.scratch.main.util.AutoSortedList;
import org.scratch.main.util.ListAlgorithms;

public class AutoSortedListTest {
	public static void main(String[] args) {
		Random rand = new Random();
		AutoSortedList<Integer> list = new AutoSortedList<>();
		for (int i = 0; i < 21; i++) {
			int newNumber = rand.nextInt(21) - 10;
			System.out.println("New Number: " + newNumber);
			list.add(newNumber);
			System.out.println("Current List: " + list.toString());
			System.out.println("Is Sorted: " + ListAlgorithms.isSorted(list));
		}
	}
}
