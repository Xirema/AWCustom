package org.scratch.test;

import java.awt.AWTException;
import java.awt.MouseInfo;
import java.awt.Point;
import java.awt.Robot;
import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Scanner;

public class CursorMover {
	public static void main(String[] args) throws InterruptedException {
		Thread robotThread = new Thread(() -> {
			try {
				Robot robot = new Robot();
				Point lastPosition = new Point(0,0);
				Instant lastUpdate = Instant.now();
				Duration interval = Duration.ofMinutes(5);
				int step = 1;
				while(true) {
					Point curr = MouseInfo.getPointerInfo().getLocation();
					Instant thisUpdate = Instant.now();
					if(curr.equals(lastPosition) || curr.distance(lastPosition) < 5) {
						if(Duration.between(lastUpdate, thisUpdate).compareTo(interval) > 0) {
							if(step > 0 && step <= 100) {
								step++;
								robot.mouseMove(curr.x + 1, curr.y);
							} else if(step > 100) {
								step = -1;
							} else if(step < 0 && step >= -100) {
								step--;
								robot.mouseMove(curr.x - 1, curr.y);
							} else if(step < -100) {
								step = 1;
							}
							curr = MouseInfo.getPointerInfo().getLocation();
						}
					} else {
						lastUpdate = thisUpdate;
					}
					lastPosition = curr;
					Thread.sleep(20);
				}
			} catch (InterruptedException | AWTException e) {}
		});
		robotThread.start();
		
		try(Scanner scan = new Scanner(System.in)) {
			scan.nextLine();
		}
		robotThread.interrupt();
		robotThread.join();
	}
	
	public static String getFormattedString(String original, int length, char fill, boolean fillFromStart) {
		if(original.length() == length)
			return original;
		char[] newChars = new char[length];
		char[] originalChars = original.toCharArray();
		Arrays.fill(newChars, fill);
		if(fillFromStart) {
			System.arraycopy(originalChars, 0, newChars, Math.max(0, length - original.length()), Math.min(length, original.length()));
		} else {
			System.arraycopy(originalChars, 0, newChars, 0, Math.min(length, original.length()));
		}
		return new String(newChars);
	}
}
