package org.scratch.test;

import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.DirectoryStream.Filter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class FileSearchTesting {

	private static void createFiles(Path directory, int numOfFiles) throws IOException {
		Random random = new Random();
		File[] oldFiles = directory.toFile().listFiles();
		for(File file : oldFiles) 
			file.delete();
		
		int[] data = new int[]{0,0};
		
		Runnable progressChecker = new Runnable() {
			Instant lastUpdate = Instant.now();
			int[] progressData = data;
			public void run() {
				Instant now = Instant.now();
				if(Duration.between(lastUpdate, now).compareTo(Duration.ofSeconds(1)) > 0) {
					System.out.println("Currently creating File " + progressData[0] + "/" + progressData[1]);
					lastUpdate = lastUpdate.plusSeconds(1);
				}
			}
		};
		for(int i = 0; i < numOfFiles; i++) {
			long name = random.nextLong();
			File file = new File(directory.toFile(), "" + Math.abs(name));
			if(file.exists()) {
				i--;
				continue;
			}
			data[0] = i + 1;
			data[1] = numOfFiles;
			progressChecker.run();
			file.createNewFile();
		}
	}
	
	private static Duration listFiles(Path directory) {
		Instant begin = Instant.now();
		File[] files = directory.toFile().listFiles();
		System.out.println("Num of Files found: " + files.length);
		Instant end = Instant.now();
		return Duration.between(begin, end);
	}
	
	private static Duration listFilesWithFilter(Path directory, FilenameFilter filter) {
		Instant begin = Instant.now();
		File[] files = directory.toFile().listFiles(filter);
		System.out.println("Num of Files found: " + files.length);
		Instant end = Instant.now();
		return Duration.between(begin, end);
	}
	
	private static Duration directoryStream(Path directory) throws IOException {
		Instant begin = Instant.now();
		int count = 0;
		try(DirectoryStream<Path> stream = Files.newDirectoryStream(directory)) {
			for(Path path : stream) {
				count++;
			}
		}

		System.out.println("Num of Files found: " + count);
		Instant end = Instant.now();
		return Duration.between(begin, end);
	}
	
	private static Duration directoryStreamWithFilter(Path directory, Filter<Path> filter) throws IOException {
		Instant begin = Instant.now();
		int count = 0;
		try(DirectoryStream<Path> stream = Files.newDirectoryStream(directory, filter)) {
			for(Path path : stream) {
				count++;
			}
		}
		System.out.println("Num of Files found: " + count);
		Instant end = Instant.now();
		return Duration.between(begin, end);
	}
	
	private static Duration nativeListing(Path directory, String startName) {
		Instant begin = Instant.now();
		
		Instant end = Instant.now();
		return Duration.between(begin, end);
	}
	
	public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
		JFileChooser chooser = new JFileChooser();
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		if(JFileChooser.APPROVE_OPTION != chooser.showSaveDialog(null)) {
			return;
		}
		File directory = chooser.getSelectedFile();
		ScannerSearcher scanner = new ScannerSearcher();
		String brtId;
		try {
			do {
				brtId = JOptionPane.showInputDialog("Enter the 5-digit beginning of the file(s)");
				brtId = brtId.substring(0, 5);
				Instant begin = Instant.now();
				Future<List<File>> future = scanner.searchForFiles(directory.getAbsolutePath(), brtId);
				List<File> fileList = future.get();
				Instant end = Instant.now();
				System.out.println("Took " + Duration.between(begin, end) + " to find " + fileList.size() + " files.");
				for(File file : fileList) {
					System.out.println("    \"" + file.getName() + "\"");
				}
			} while(true);
		} finally {
			scanner.shutdown();
		}
//		String numOfFilesString = JOptionPane.showInputDialog(null, "Input number of files to create");
//		Path directoryPath = directory.toPath();
//		int numOfFiles = Integer.parseInt(numOfFilesString);
//		createFiles(directoryPath, numOfFiles);
//		System.out.println("Time to listFiles: " + listFiles(directoryPath));
//		System.out.println("Time to listFiles with Filter: " + listFilesWithFilter(directoryPath, (dir, file) -> file.startsWith("1")));
//		System.out.println("Time to DirectoryStream: " + directoryStream(directoryPath));
//		System.out.println("Time to DirectoryStream with Filter: " + directoryStreamWithFilter(directoryPath, (name) -> name.toFile().getName().startsWith("1")));
		
	}
}
