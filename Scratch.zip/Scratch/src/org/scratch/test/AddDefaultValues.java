package org.scratch.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.swing.JFileChooser;

public class AddDefaultValues {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		JFileChooser chooser = new JFileChooser();
		if(chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File openFile = chooser.getSelectedFile();
		if(chooser.showSaveDialog(null) != JFileChooser.APPROVE_OPTION)
			return;
		File saveFile = chooser.getSelectedFile();
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(openFile)));
			PrintWriter out = new PrintWriter(new FileOutputStream(saveFile))) {
			String line;
			while((line = reader.readLine()) != null)
				out.println(convertString(line));
		}
	}
	
	private static String convertString(String line) {
		return "query.append(\"" + line + "\");";
	}
}
