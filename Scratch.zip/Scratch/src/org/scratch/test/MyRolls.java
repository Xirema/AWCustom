package org.scratch.test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.scratch.main.dice.format.RollPrinter.TableOptions;
import org.scratch.main.dice.model.AttackRoll;
import org.scratch.main.dice.model.Modifier;
import org.scratch.main.dice.model.Outcome;
import org.scratch.main.dice.model.RollBuilder;
import org.scratch.main.dice.model.RollBuilder.FilterType;
import org.scratch.main.dice.model.RollFactory;
import org.scratch.main.dice.model.RollFactory.Advantage;
import org.scratch.main.dice.model.RollFactory.AttackOptions;
import org.scratch.main.dice.model.RollTemplate;
import org.scratch.main.dice.model.Rollable;
import org.scratch.main.dice.model.SavingThrow;
import org.scratch.main.dice.model.StandardDice;
import org.scratch.main.dice.model.compositor.Accumulator;
import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.compositor.CriticalCompositor;
import org.scratch.main.dice.model.ternary.TernaryOperator;
import org.scratch.main.dice.model.transformer.Counter;
import org.scratch.main.dice.model.transformer.Threshold;
import org.scratch.main.util.ListAlgorithms;
import org.scratch.main.util.Pair;

public class MyRolls {
	public static TableOptions getBarbarianComparison(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		
		List<Integer> acs = new ArrayList<>(getStandardACArray());
		acs.add(16);
		acs.add(18);
		acs.add(19);
		Collections.sort(acs);
		options.columnHeaders.addAll(acs.stream().map(ac -> "AC " + ac).collect(Collectors.toList()));
		
		AttackOptions aoptions = new AttackOptions();
		aoptions.critRangeExpansion = 0;
		AttackRoll normalAttack = factory.getSimpleAttackRoll(6, 1, 12, 6, Advantage.ADVANTAGE, aoptions);
		AttackRoll gwmAttack = factory.getSimpleAttackRoll(1, 1, 12, 16, Advantage.ADVANTAGE, aoptions);
		AttackRoll normalAttackL5 = factory.getSimpleAttackRoll(7, 1, 12, 6, Advantage.ADVANTAGE, aoptions);
		AttackRoll gwmAttackL5 = factory.getSimpleAttackRoll(2, 1, 12, 16, Advantage.ADVANTAGE, aoptions);
		
		AttackRoll divineFury = new AttackRoll(factory.getXdYRoll(1, 6).add(3).getRoll(), factory.getXdYRoll(2, 6).add(3).getRoll());
		options.rowHeaders.addAll(Arrays.asList(
			"Zar'Ryth Normal Attack L04",
			"Zar'Ryth Great Weapon Master L04",
			"Zar'Ryth Normal Attack L05",
			"Zar'Ryth Great Weapon Master L05"
		));
		options.groupSize = options.rowHeaders.size() - 1;
		for(int ac : acs) {
			RollBuilder normalDamage = factory.getDamageRollVsAC("Normal vs AC" + ac, normalAttack, ac);
			AttackRoll bonusAttack = new AttackRoll(StandardDice.mod0, normalDamage.getRoll());
			rolls.add(factory.getSneakAttackVsAC("Normal vs AC" + ac, normalAttack.repeatList(1), divineFury, bonusAttack, ac).getRoll());
			RollBuilder gwmDamage = factory.getDamageRollVsAC("GWM vs AC" + ac, gwmAttack, ac);
			bonusAttack = new AttackRoll(StandardDice.mod0, gwmDamage.getRoll());
			rolls.add(factory.getSneakAttackVsAC("GWM vs AC" + ac, gwmAttack.repeatList(1), divineFury, bonusAttack, ac).getRoll());
			normalDamage = factory.getDamageRollVsAC("Normal vs AC" + ac, normalAttackL5, ac);
			bonusAttack = new AttackRoll(StandardDice.mod0, normalDamage.getRoll());
			rolls.add(factory.getSneakAttackVsAC("Normal vs AC" + ac, normalAttackL5.repeatList(2), divineFury, bonusAttack, ac).getRoll());
			gwmDamage = factory.getDamageRollVsAC("GWM vs AC" + ac, gwmAttackL5, ac);
			bonusAttack = new AttackRoll(StandardDice.mod0, gwmDamage.getRoll());
			rolls.add(factory.getSneakAttackVsAC("GWM vs AC" + ac, gwmAttackL5.repeatList(2), divineFury, bonusAttack, ac).getRoll());
		}
		
		return options;
	}
	public static TableOptions getRangerComparison(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		
		List<Integer> acs = getStandardACArray();
		
		AttackRoll horizonWalkerHeavyCrossbow = factory.getSimpleAttackRoll(9, 1, 10, 4);
		AttackRoll horizonWalkerHeavyCrossbowSharpshooter = factory.getSimpleAttackRoll(3, 1, 10, 13);
		AttackRoll horizonWalkerPlanarWarrior = factory.getSimpleSneakAttack(1, 8);
		
		AttackRoll monsterSlayerHandCrossbow = factory.getSimpleAttackRoll(9, 1, 6, 4);
		AttackRoll monsterSlayerHandCrossbowSharpshooter = factory.getSimpleAttackRoll(3, 1, 6, 13);
		AttackRoll monsterSlayerPrey = factory.getSimpleSneakAttack(1, 6);
		
		AttackRoll monsterSlayerGreatsword = factory.getSimpleAttackRoll(8, 2, 6, 5);
		AttackRoll monsterSlayerGreatswordGWM = factory.getSimpleAttackRoll(2, 2, 6, 14);
		
		AttackRoll monsterSlayerPAM = factory.getSimpleAttackRoll(7, 1, 10, 4);
		AttackRoll monsterSlayerPAMGWM = factory.getSimpleAttackRoll(1, 1, 10, 13);
		AttackRoll monsterSlayerPAMOff = factory.getSimpleAttackRoll(7, 1, 4, 4);
		AttackRoll monsterSlayerPAMGWMOff = factory.getSimpleAttackRoll(1, 1, 4, 13);
		
		options.columnHeaders.addAll(acs.stream().map(ac -> "AC " + ac).collect(Collectors.toList()));
		options.rowHeaders.addAll(Arrays.asList(
			"Horizon Walker Heavy Crossbow",
			"Horizon Walker Sharpshooter",
			"Monster Slayer Hand Crossbow",
			"Monster Slayer Sharpshooter",
			"Monster Slayer Greatsword",
			"Monster Slayer GWM",
			"Monster Slayer Glaive PAM",
			"Monster Slayer PAM GWM"
		));
		options.groupSize = options.rowHeaders.size()-1;
		for(int ac : acs) {
			rolls.add(factory.getSneakAttackVsAC("HW vs AC " + ac, horizonWalkerHeavyCrossbow.repeatList(2), horizonWalkerPlanarWarrior, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("HW Shp vs AC " + ac, horizonWalkerHeavyCrossbowSharpshooter.repeatList(2), horizonWalkerPlanarWarrior, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS HC vs AC " + ac, monsterSlayerHandCrossbow.repeatList(3), monsterSlayerPrey, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS HC Shp vs AC " + ac, monsterSlayerHandCrossbowSharpshooter.repeatList(3), monsterSlayerPrey, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS GS vs AC " + ac, monsterSlayerGreatsword.repeatList(2), monsterSlayerPrey, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS GS GWM vs AC " + ac, monsterSlayerGreatswordGWM.repeatList(2), monsterSlayerPrey, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS PAM vs AC " + ac, Arrays.asList(monsterSlayerPAM, monsterSlayerPAM, monsterSlayerPAMOff), monsterSlayerPrey, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("MS PAM GWM vs AC " + ac, Arrays.asList(monsterSlayerPAMGWM, monsterSlayerPAMGWM, monsterSlayerPAMGWMOff), monsterSlayerPrey, ac).getRoll());
		}
		return options;
	}
	public static TableOptions getMedixRoll(RollFactory factory, List<Rollable> rolls) {
		RollBuilder initialRoll = factory.getXdYRoll(1, 6);
		rolls.add(initialRoll.getRoll());
		RollBuilder _4d6D2 = initialRoll;
		for(int i = 1; i <= 3; i++) {
			_4d6D2 = _4d6D2.compose(initialRoll, (outcome1, outcome2) -> {
				if(outcome2.value >= outcome1.value) {
					return new Outcome(outcome2.value, outcome1.value);
				} else if(outcome2.value > outcome1.special)
					return new Outcome(outcome1.value, outcome2.value);
				else
					return outcome1;
			});
			rolls.add(_4d6D2.getRoll());
		}
		RollBuilder noOnes = factory.truncateRoll(factory.getXdYRoll(1, 6).getRoll(), outcome -> outcome.value != 1);
		_4d6D2 = _4d6D2.compose(noOnes, (outcome1, outcome2) -> {
			if(outcome1.value == 1)
				return new Outcome(outcome2.value, outcome1.special);
			else
				return outcome1;
		});
		_4d6D2 = _4d6D2.compose(noOnes, (outcome1, outcome2) -> {
			if(outcome1.special == 1)
				return new Outcome(outcome1.value, outcome2.value);
			else
				return outcome1;
		});
		_4d6D2 = _4d6D2.transform(outcome -> new Outcome(outcome.value + outcome.special));
		rolls.add(_4d6D2.getRoll());
		
		return new TableOptions();
	}
	public static TableOptions compareScimitarvsDualWielding(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = getStandardACArray();
		options.columnHeaders.addAll(acs.stream().map(ac -> "AC " + ac).collect(Collectors.toList()));
		options.rowHeaders.addAll(Arrays.asList(
			"Double-Bladed Scimitar x1+1",
			"Double-Bladed Scimitar w/GWF x1+1",
			"Shortswords x1+1",
			"Dual-Wielding Longswords x1+1",

			"Double-Bladed Scimitar x2+1",
			"Double-Bladed Scimitar w/GWF x2+1",
			"Shortswords x2+1",
			"Dual-Wielding Longswords x2+1",

			"Double-Bladed Scimitar x3+1",
			"Double-Bladed Scimitar w/GWF x3+1",
			"Shortswords x3+1",
			"Dual-Wielding Longswords x3+1",

			"Double-Bladed Scimitar x4+1",
			"Double-Bladed Scimitar w/GWF x4+1",
			"Shortswords x4+1",
			"Dual-Wielding Longswords x4+1"
		));
		
		options.groupSize = 4;
		AttackOptions aoptions = new AttackOptions();
		aoptions.greatWeaponFighting = true;
		
		for(int numOfAttacks : Arrays.asList(1,2,3,4)) {
			int atk = 3 + (2*numOfAttacks), dmg = 3 + numOfAttacks / 2;
			AttackRoll scimitarNormal = factory.getSimpleAttackRoll(atk, 2, 4, dmg);
			AttackRoll scimitarBonus = factory.getSimpleAttackRoll(atk, 1, 4, dmg);
			AttackRoll scimitarWithGWF = factory.getSimpleAttackRoll(atk, 2, 4, dmg, Advantage.NONE, aoptions);
			AttackRoll scimitarBonusWithGWF = factory.getSimpleAttackRoll(atk, 1, 4, dmg, Advantage.NONE, aoptions);
			AttackRoll shortswordNormal = factory.getSimpleAttackRoll(atk, 1, 6, dmg);
			AttackRoll longswordNormal = factory.getSimpleAttackRoll(atk, 1, 8, dmg);
			for(int ac : acs) {
				rolls.add(
					factory.getMultiAttackVsAC(
						"Scimitar x" + numOfAttacks + "+1", 
						Stream.concat(
							scimitarNormal.repeatList(numOfAttacks).stream(), 
							Stream.of(scimitarBonus)
						).collect(Collectors.toList()),
						ac
					).getRoll()
				);
				rolls.add(
					factory.getMultiAttackVsAC(
						"Scimitar w/GWF x" + numOfAttacks + "+1", 
						Stream.concat(
							scimitarWithGWF.repeatList(numOfAttacks).stream(), 
							Stream.of(scimitarBonusWithGWF)
						).collect(Collectors.toList()),
						ac
					).getRoll()
				);
				rolls.add(
					factory.getMultiAttackVsAC(
						"Shortsword x" + numOfAttacks + "+1", 
						shortswordNormal.repeatList(numOfAttacks + 1),
						ac
					).getRoll()
				);
				rolls.add(
					factory.getMultiAttackVsAC(
						"Longsword x" + numOfAttacks + "+1", 
						longswordNormal.repeatList(numOfAttacks + 1),
						ac
					).getRoll()
				);
			}
		}
		
		return options;
	}
	
	public static TableOptions compareSpellDCVariant2(RollFactory factory, List<Rollable> rolls) {
		List<Integer> modifiers = Arrays.asList(-2, 0, 2, 5, 9, 11, 15);
		TableOptions options = new TableOptions();
		options.columnHeaders.addAll(modifiers.stream().map(mod -> "WIS " + MyRolls.signed(mod)).collect(Collectors.toList()));

		List<Integer> levels = ListAlgorithms.getRun(3, 9);
		options.rowHeaders.add("Base DC 19");
		options.rowHeaders.addAll(
			levels.stream().map(level -> "DC " + (level + 19 - 2)).collect(Collectors.toList()));
		
		options.groupSize = options.rowHeaders.size() - 1;
		Function<Integer, SavingThrow> savingThrowFunction = dc -> new SavingThrow(dc, new Modifier(100), new Modifier(0));
		for(int modifier : modifiers) {
			SavingThrow basicSavingThrow = savingThrowFunction.apply(19);
			rolls.add(factory.getSavingThrowDamageRoll("Hold Person DC19 vs " + signed(modifier), modifier, basicSavingThrow).getRoll());
			for(int level : levels) {
				rolls.add(factory.getSavingThrowDamageRoll("Hold Person DC" + (17 + level) + " vs " + signed(modifier), modifier, savingThrowFunction.apply(17 + level)).getRoll());
			}
		}
		return options;
	}
	
	public static TableOptions compareSpellDCVariant(RollFactory factory, List<Rollable> rolls) {
		List<Integer> modifiers = Arrays.asList(-2, 0, 2, 5, 9, 11, 15);
		TableOptions options = new TableOptions();
		options.columnHeaders.addAll(modifiers.stream().map(mod -> "DEX " + MyRolls.signed(mod)).collect(Collectors.toList()));

		List<Integer> levels = ListAlgorithms.getRun(4, 9);
		options.rowHeaders.add("Base 8d6 DC 19");
		options.rowHeaders.addAll(
			levels.stream().flatMap(level -> Stream.of("8d6 DC " + (level + 19 - 3), (level + 8 - 3) + "d6 DC 19")).collect(Collectors.toList()));
		
		options.groupSize = options.rowHeaders.size() - 1;
		BiFunction<Integer, Integer, SavingThrow> savingThrowFunction = (dc, numOfDice) -> factory.getBasicSavingThrow(dc, numOfDice, 6);
		for(int modifier : modifiers) {
			SavingThrow basicSavingThrow = savingThrowFunction.apply(19, 8);
			rolls.add(factory.getSavingThrowDamageRoll("Fireball DC19 8d6 vs " + signed(modifier), modifier, basicSavingThrow).getRoll());
			for(int level : levels) {
				rolls.add(factory.getSavingThrowDamageRoll("Fireball DC" + (16 + level) + " 8d6 vs " + signed(modifier), modifier, savingThrowFunction.apply(16 + level, 8)).getRoll());
				rolls.add(factory.getSavingThrowDamageRoll("Fireball DC19 " + (5 + level) + "d6 vs " + signed(modifier), modifier, savingThrowFunction.apply(19, 5 + level)).getRoll());
			}
		}
		return options;
	}
	
	private static class ObjectStats {
		int hp, ac;
		double count;
		public ObjectStats(int hp, int ac, double count) {
			this.hp = hp;
			this.ac = ac;
			this.count = count;
		}
	}
	
	public static TableOptions animateObjectsComparison(RollFactory factory, List<Rollable> rolls) {
		List<Integer> acs = new ArrayList<>(getStandardACArray());
		TableOptions options = new TableOptions();
		options.columnHeaders.addAll(Arrays.asList("TTD (Single)", "TTD (Combined)"));
		options.columnHeaders.addAll(acs.stream().flatMap(ac -> Stream.of(ac, ~ac)).map(ac -> (ac >= 0 && ac <= 25) ? ("AC " + ac) : ("AC " + (~ac) + " (All)")).collect(Collectors.toList()));
		
		options.rowHeaders.addAll(Arrays.asList(
			"Tiny x10",
			"Small x10",
			"Medium x5",
			"Large x2.5",
			"Huge x1.25"
		));
		options.groupSize = 1;
		
		AttackRoll tinyAttackRoll = factory.getSimpleAttackRoll(8, 1, 4, 4);
		AttackRoll smallAttackRoll = factory.getSimpleAttackRoll(6, 1, 8, 2);
		AttackRoll mediumAttackRoll = factory.getSimpleAttackRoll(5, 2, 6, 1);
		AttackRoll largeAttackRoll = factory.getSimpleAttackRoll(6, 2, 10, 2);
		AttackRoll hugeAttackRoll = factory.getSimpleAttackRoll(8, 2, 12, 4);
		
		AttackOptions aoptions = new AttackOptions();
		aoptions.greatWeaponFighting = true;
		AttackRoll defenderRoll = factory.getSimpleAttackRoll(5, 2, 6, 3, Advantage.NONE, aoptions);
		
		List<ObjectStats> stats = Arrays.asList(
			new ObjectStats(20, 18, 10),
			new ObjectStats(25, 16, 10),
			new ObjectStats(40, 13, 5),
			new ObjectStats(50, 10, 2.5),
			new ObjectStats(80, 10, 1.25)
		);
		
		rolls.add(factory.getTimeToDownRoll(stats.get(0).hp, factory.getDamageRollVsAC("TTD Tiny", defenderRoll, stats.get(0).ac).getRoll()).getRoll());
		rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(0).count).getRoll());
		for(int ac : acs) {
			rolls.add(factory.getDamageRollVsAC("Tiny vs AC" + ac, tinyAttackRoll, ac).getRoll());
			rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(0).count).getRoll());
		}
		rolls.add(factory.getTimeToDownRoll(stats.get(1).hp, factory.getDamageRollVsAC("TTD Small", defenderRoll, stats.get(1).ac).getRoll()).getRoll());
		rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(1).count).getRoll());
		for(int ac : acs) {
			rolls.add(factory.getDamageRollVsAC("Small vs AC" + ac, smallAttackRoll, ac).getRoll());
			rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(1).count).getRoll());
		}
		rolls.add(factory.getTimeToDownRoll(stats.get(2).hp, factory.getDamageRollVsAC("TTD Medium", defenderRoll, stats.get(2).ac).getRoll()).getRoll());
		rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(2).count).getRoll());
		for(int ac : acs) {
			rolls.add(factory.getDamageRollVsAC("Medium vs AC" + ac, mediumAttackRoll, ac).getRoll());
			rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(2).count).getRoll());
		}
		rolls.add(factory.getTimeToDownRoll(stats.get(3).hp, factory.getDamageRollVsAC("TTD Large", defenderRoll, stats.get(3).ac).getRoll()).getRoll());
		rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(3).count).getRoll());
		for(int ac : acs) {
			rolls.add(factory.getDamageRollVsAC("Large vs AC" + ac, largeAttackRoll, ac).getRoll());
			rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(3).count).getRoll());
		}
		rolls.add(factory.getTimeToDownRoll(stats.get(4).hp, factory.getDamageRollVsAC("TTD Huge", defenderRoll, stats.get(4).ac).getRoll()).getRoll());
		rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(4).count).getRoll());
		for(int ac : acs) {
			rolls.add(factory.getDamageRollVsAC("Huge vs AC" + ac, hugeAttackRoll, ac).getRoll());
			rolls.add(factory.createAverageOutcomeRoll(rolls.get(rolls.size()-1).mean().doubleValue() * stats.get(4).count).getRoll());
		}
		
		return options;
	}
	
	public static TableOptions swiftQuiverVsInvisibility(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = new ArrayList<>(getStandardACArray());
		acs.addAll(Arrays.asList(26, 27, 28, 29, 30));
		
		int dex = 5;
		int prof = 4;
		
		Advantage advantage = Advantage.DOUBLE_ADVANTAGE;
		options.rowHeaders.addAll(Arrays.asList("Swift Quiver x4", "Greater Invisibility x2", "Longbow x1", "Longbox W/Elven Accuracy x1"));
		options.columnHeaders.addAll(acs.stream().map(ac -> "AC " + ac).collect(Collectors.toList()));
		options.groupSize = 4;
		
		AttackRoll longbow = factory.getSimpleAttackRoll(prof + dex, 1, 8, dex);
		AttackRoll longbowAdv = factory.getSimpleAttackRoll(prof + dex, 1, 8, dex, advantage);
		for(int ac : acs) {
			rolls.add(factory.getMultiAttackVsAC("Swift Quiver vs AC" + ac, Arrays.asList(longbowAdv, longbow, longbow, longbow), ac).getRoll());
			rolls.add(factory.getMultiAttackVsAC("Greater Invisibility vs AC" + ac, Arrays.asList(longbowAdv, longbowAdv), ac).getRoll());
			rolls.add(factory.getMultiAttackVsAC("Longbow vs AC" + ac, Arrays.asList(longbow), ac).getRoll());
			rolls.add(factory.getMultiAttackVsAC("Longbow w/Elven Accuracy vs AC" + ac, Arrays.asList(longbowAdv), ac).getRoll());
		}
		return options;
	}
	public static TableOptions colville(RollFactory factory, List<Rollable> rolls) {
		RollBuilder xdyd1 = factory.getXdYRollDrop1(4, 6);
		rolls.add(xdyd1.getRoll());
		xdyd1 = factory.truncateRoll(xdyd1.getRoll(), xdyd1.getRoll().outcomesGreaterEqualThan(new Outcome(8)));
		rolls.add(xdyd1.getRoll());

		RollBuilder xdyd1x6 = xdyd1;
		for (int i = 1; i < 6; i++) {
			xdyd1x6 = xdyd1x6.multiply(20).add(xdyd1);
			final int count = i;
			xdyd1x6 = xdyd1x6.transform((roll) -> {
				final int[] arr = new int[count + 1];
				int value = roll.value;
				for (int in = 0; in < count + 1; in++) {
					arr[in] = value % 20;
					value /= 20;
				}
				value = 0;
				Arrays.sort(arr);
				for (int in = count; in >= 0; in--) {
					value *= 20;
					value += arr[in];
				}
				return new Outcome(value);
			});
		}
		Predicate<Outcome> predicate = (outcome) -> {
			int[] scores = new int[6];
			int value = outcome.value;
			int valid = 0;
			for (int i = 0; i < 6; i++) {
				scores[i] = value % 20;
				if (scores[i] >= 15) {
					valid++;
				}
				value /= 20;
			}
			if (valid >= 2)
				return true;
			else
				return false;
		};
		xdyd1x6 = xdyd1x6.transform((roll) -> {
			final int[] arr = new int[6];
			int value = roll.value;
			for (int i = 0; i < 6; i++) {
				arr[i] = value % 20;
				value /= 20;
			}
			value = 0;
			Arrays.sort(arr);
			for (int i = 5; i >= 0; i--) {
				value *= 20;
				value += arr[i];
			}
			return new Outcome(value, roll.special) {
				@Override
				public String toString() {
					int lvalue = value;
					String ret = "[" + (lvalue % 20);
					for (int i = 4; i >= 0; i--) {
						lvalue /= 20;
						ret += ", " + (lvalue % 20);
					}
					return ret + "]";
				}
			};
		});
		xdyd1x6 = factory.truncateRoll(xdyd1x6.getRoll(), predicate);
		rolls.add(xdyd1x6.getRoll());

		xdyd1x6 = xdyd1x6.transform((roll) -> {
			final int[] arr = new int[6];
			int value = roll.value;
			for (int i = 0; i < 6; i++) {
				arr[i] = value % 20;
				value /= 20;
			}
			value = 0;
			for (int i = 5; i >= 0; i--) {
				value += arr[i];
			}
			return new Outcome(value, roll.special);
		});

		rolls.add(xdyd1x6.getRoll());

		rolls.add(factory.getXdYRollDrop1(4, 6).repeat(6).getRoll());

		return new TableOptions();
	}

	public static TableOptions attackDamageComparison(final RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = getStandardACArray();

		final AttackOptions aoptions = new AttackOptions();
		aoptions.greatWeaponFighting = true;

		BiFunction<Integer, Integer, AttackRoll> attackFunction = (hit, damage) -> factory.getSimpleAttackRoll(11 + hit,
				2, 6, 5 + damage, Advantage.NONE, aoptions);

		AttackRoll sneakAttack = factory.getSimpleSneakAttack(0);

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
		}
		for (int mod = 0; mod <= 5; mod++) {
			options.rowHeaders.add(signed(mod) + "/" + signed(mod));
			AttackRoll attackRoll = attackFunction.apply(mod, mod);
			for (int ac : acs) {
				rolls.add(factory.getSneakAttackVsAC("Greatsword " + signed(mod) + "/" + signed(mod) + " vs AC" + ac,
						attackRoll.repeatList(1), sneakAttack, ac).getRoll());
			}
		}
		for (int mod = -5; mod <= 5; mod++) {
			if (mod == 0) {
				continue;
			}
			options.rowHeaders.add(signed(mod) + "/" + signed(-mod * 2));
			AttackRoll attackRoll = attackFunction.apply(mod, -mod * 2);
			for (int ac : acs) {
				rolls.add(
						factory.getSneakAttackVsAC("Greatsword " + signed(mod) + "/" + signed(-mod * 2) + " vs AC" + ac,
								attackRoll.repeatList(1), sneakAttack, ac).getRoll());
			}
		}
		for (int mod = -5; mod <= 5; mod++) {
			if (mod == 0) {
				continue;
			}
			options.rowHeaders.add(signed(mod * 2) + "/" + signed(-mod));
			AttackRoll attackRoll = attackFunction.apply(mod * 2, -mod);
			for (int ac : acs) {
				rolls.add(
						factory.getSneakAttackVsAC("Greatsword " + signed(mod * 2) + "/" + signed(-mod) + " vs AC" + ac,
								attackRoll.repeatList(1), sneakAttack, ac).getRoll());
			}
		}
		for (int mod = -5; mod <= 5; mod++) {
			if (mod == 0) {
				continue;
			}
			options.rowHeaders.add(signed(mod) + "/" + signed(-mod));
			AttackRoll attackRoll = attackFunction.apply(mod, -mod);
			for (int ac : acs) {
				rolls.add(factory.getSneakAttackVsAC("Greatsword " + signed(mod) + "/" + signed(-mod) + " vs AC" + ac,
						attackRoll.repeatList(1), sneakAttack, ac).getRoll());
			}
		}

		return options;
	}

	private static String signed(int val) {
		if (val >= 0)
			return "+" + val;
		else
			return "" + val;
	}

	public static TableOptions propertyComparison(RollFactory factory, List<Rollable> rolls) {
		List<Integer> acs = getStandardACArray();
		TableOptions options = new TableOptions();

		AttackOptions aOptions = new AttackOptions();
		Advantage advantage = Advantage.ADVANTAGE;
		List<AttackRoll> aRolls = new ArrayList<>();
		int hit = 5, numOfDice = 1, sizeOfDice = 12, dmg = 3;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage));
		aOptions.extraCritDice = 1;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 2;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 4;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 0;
		aOptions.critRangeExpansion = 1;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 0;
		aOptions.critRangeExpansion = 2;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 1;
		aOptions.critRangeExpansion = 1;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 2;
		aOptions.critRangeExpansion = 1;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 4;
		aOptions.critRangeExpansion = 1;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 1;
		aOptions.critRangeExpansion = 2;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 2;
		aOptions.critRangeExpansion = 2;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aOptions.extraCritDice = 4;
		aOptions.critRangeExpansion = 2;
		aRolls.add(factory.getSimpleAttackRoll(hit, numOfDice, sizeOfDice, dmg, advantage, aOptions));
		aRolls.add(factory.getSimpleAttackRoll(hit + 1, numOfDice, sizeOfDice, dmg + 1, advantage));
		aRolls.add(factory.getSimpleAttackRoll(hit + 2, numOfDice, sizeOfDice, dmg + 2, advantage));
		aRolls.add(factory.getSimpleAttackRoll(hit + 3, numOfDice, sizeOfDice, dmg + 3, advantage));

		options.groupSize = 15;

		options.rowHeaders.addAll(Arrays.asList("Basic",

				"Brutal", "Brutal++", "Brutal++++",

				"Superior", "Superior++",

				"Superior Brutal", "Superior Brutal++", "Superior Brutal++++",

				"Superior++ Brutal", "Superior++ Brutal++", "Superior++ Brutal++++",

				"Basic +1", "Basic +2", "Basic +3"));

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
			for (AttackRoll roll : aRolls) {
				rolls.add(factory.getDamageRollVsAC("", roll, ac).getRoll());
			}
		}

		return options;
	}

	public static TableOptions maximumPossibleDamage2(RollFactory factory, List<Rollable> rolls) {
		int ac = 20;

		AttackRoll basicYakAttack = factory.getSimpleAttackRoll(6, 3, 6, 4);
		AttackRoll advantageYakAttack = factory.getSimpleAttackRoll(6, 3, 6, 4, Advantage.ADVANTAGE);

		RollBuilder basicYakRoll = factory.getDamageRollVsAC("Kow Attack", basicYakAttack, ac);
		RollBuilder advantageYakRoll = factory.getDamageRollVsAC("Kow Adv. Attack", advantageYakAttack, ac);
		RollBuilder trample = factory.getD20Roll(5).filterAndFlatten(13, FilterType.LESS_THAN);

		basicYakRoll = factory.getCompositeTernaryRoll("Kow Attack Trample", basicYakRoll.getRoll(), trample.getRoll(),
				StandardDice.mod0, condition -> condition.compareTo(new Outcome()) > 0,
				(roll1, roll2) -> new Outcome(roll1.value, roll2.value));

		advantageYakRoll = factory.getCompositeTernaryRoll("Kow Adv. Attack Trample", advantageYakRoll.getRoll(),
				trample.getRoll(), StandardDice.mod0, condition -> condition.compareTo(new Outcome()) > 0,
				(roll1, roll2) -> new Outcome(roll1.value, roll2.value));

		// RollBuilder yakAttack = basicYakRoll;
		RollBuilder yakAttack = advantageYakRoll;

		for (int i = 1; i < 32; i++) {
			yakAttack = factory.getCompositeTernaryRoll("Kow Attack x" + (i + 1), yakAttack.getRoll(),
					advantageYakRoll.getRoll(), basicYakRoll.getRoll(), condition -> true,
					(Outcome roll1, Outcome roll2) -> {
						int value = roll1.value + roll2.value;
						int special = roll1.special + roll2.special > 0 ? 1 : 0;
						return new Outcome(value, special);
					});
		}

		rolls.add(yakAttack.getRoll());

		yakAttack = yakAttack.filterAndFlatten(object -> object.special > 0);

		rolls.add(yakAttack.getRoll());

		return new TableOptions();
	}

	public static TableOptions maximumPossibleDamage(RollFactory factory, List<Rollable> rolls) {
		int ac = 20;

		AttackOptions options = new AttackOptions();
		options.extraCritDice = 1;
		AttackRoll attack = factory.getSimpleAttackRoll(11, 4, 8, 7, Advantage.ADVANTAGE, options);
		Rollable crit = factory.build(attack.crit).transform(roll -> new Outcome(roll.value, 1)).getRoll();

		attack = new AttackRoll(attack.attack, crit, crit);
		AttackRoll precisionStrike = new AttackRoll(factory.build(attack.attack).addDie(8).getRoll(),
				factory.build(attack.damage).addDie(8).addDie(8).getRoll(),
				factory.build(attack.crit).addDie(8).addDie(8).getRoll());
		AttackRoll precisionStrikeWithGloom = new AttackRoll(precisionStrike.attack,
				factory.build(precisionStrike.damage).addDie(8).addDie(8).getRoll(),
				factory.build(precisionStrike.crit).addDie(8).addDie(8).getRoll());

		List<AttackRoll> attacks = Arrays.asList(
				new AttackRoll(factory.build(attack.attack).add(10).getRoll(), attack.damage, attack.crit),
				precisionStrike, precisionStrikeWithGloom, precisionStrike, precisionStrikeWithGloom,
				new AttackRoll(factory.build(attack.attack).addDie(4).addDie(4).getRoll(), attack.damage, attack.crit),
				attack);

		RollBuilder sneak = factory.getXdYRoll(4, 6);

		RollBuilder builtRoll = factory.getMultiAttackVsAC("Oh God", attacks, ac);

		List<RollBuilder> smites = Arrays.asList(factory.getXdYRoll(5 * 2, 8), factory.getXdYRoll(5 * 2, 8),
				factory.getXdYRoll(5 * 2, 8), factory.getXdYRoll(5 * 2, 8), factory.getXdYRoll(4 * 2, 8),
				factory.getXdYRoll(4 * 2, 8), factory.getXdYRoll(4 * 2, 8));
		TernaryOperator operator = roll -> roll.special > 0;

		Compositor compositor = (roll1, roll2) -> {
			int special = roll1.special;
			if (special > 0) {
				special--;
			}
			return new Outcome(roll1.value + roll2.value, special + roll2.special);
		};

		for (int i = 0; i < smites.size(); i++) {
			RollBuilder smite = smites.get(i);
			builtRoll = factory.getCompositeTernaryRoll(builtRoll.getRoll().getName() + "+" + smite.getRoll().getName(),
					builtRoll.getRoll(), smite.getRoll(), StandardDice.mod0, operator, compositor);
		}

		TernaryOperator operator2 = condition -> condition.compareTo(new Outcome()) > 0;

		builtRoll = factory.getCompositeTernaryRoll(builtRoll.getRoll().getName() + "+" + sneak.getRoll().getName(),
				builtRoll.getRoll(), sneak.getRoll(), StandardDice.mod0, operator2, Accumulator.instance);

		builtRoll = builtRoll.rename("\"Arthur\"");
		rolls.add(builtRoll.getRoll());

		return new TableOptions();
	}

	public static TableOptions criticalSuccessesFailures(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> thresholds = ListAlgorithms.getRun(0, 21);
		options.columnHeaders.addAll(Arrays.asList("Critical Success %", "Critical Failure %"));
		Predicate<Outcome> predicate = object -> object.special != 0;
		for (int threshold : thresholds) {
			options.rowHeaders.add("DC " + threshold);
			rolls.add(factory
					.getCompositeRoll("Critical Success vs DC" + threshold, StandardDice.D20, StandardDice.D20,
							new CriticalCompositor(threshold, true))
					.filterAndFlatten(predicate).multiply(100).getRoll());
			rolls.add(factory
					.getCompositeRoll("Critical Failure vs DC" + threshold, StandardDice.D20, StandardDice.D20,
							new CriticalCompositor(threshold, false))
					.filterAndFlatten(predicate).multiply(100).getRoll());
		}
		return options;
	}

	public static TableOptions compareSorcererFighter(RollFactory factory, List<Rollable> rolls) {
		List<Integer> acs = getStandardACArray();
		TableOptions options = new TableOptions();
		List<Integer> levels = ListAlgorithms.getRun(20);

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
		}

		for (int level : levels) {
			int proficiency = getProf(level);
			int fighterMod = (level < 4) ? 3 : (level < 6) ? 4 : 5;
			int sorcererMod = (level < 4) ? 3 : (level < 8) ? 4 : 5;

			AttackOptions fighterOptions = new AttackOptions();
			fighterOptions.setCritRangeFromChampionLevel(level);
			fighterOptions.greatWeaponFighting = true;
			int numOfFighterAttacks = (level < 5) ? 1 : (level < 11) ? 2 : (level < 20) ? 3 : 4;
			AttackRoll fighterBasicAttack = factory.getSimpleAttackRoll(fighterMod + proficiency, 2, 6, fighterMod,
					Advantage.NONE, fighterOptions);
			AttackRoll fighterGWMAttack = factory.getSimpleAttackRoll(fighterMod + proficiency - 5, 2, 6,
					fighterMod + 10, Advantage.NONE, fighterOptions);

			Advantage sorcererAdvantage =
					// (level < 4) ?
					// Advantage.ADVANTAGE :
					// Advantage.DOUBLE_ADVANTAGE
					Advantage.ADVANTAGE;
			int boomingBladeLevel = (level < 5) ? 1 : (level < 11) ? 2 : (level < 17) ? 3 : 4;
			int shadowBladeLevel = (level < 3) ? 0 : (level < 5) ? 2 : (level < 9) ? 3 : (level < 13) ? 4 : 5;
			AttackRoll sorcererBasicAttack = factory.getSimpleAttackRoll(sorcererMod + proficiency, boomingBladeLevel,
					8, sorcererMod);
			AttackRoll sorcererShadowAttack = factory.getSimpleAttackRoll(sorcererMod + proficiency,
					boomingBladeLevel + shadowBladeLevel, 8, sorcererMod, sorcererAdvantage);
			AttackRoll sorcererBrightAttack = factory.getSimpleAttackRoll(sorcererMod + proficiency,
					boomingBladeLevel + shadowBladeLevel, 8, sorcererMod);

			int fighterShadowBlade = (level < 7) ? 0 : (level < 13) ? 2 : 3;

			AttackRoll fighterShadowAttack = factory.getSimpleAttackRoll(fighterMod + proficiency,
					fighterShadowBlade == 0 ? 2 : fighterShadowBlade, fighterShadowBlade > 0 ? 8 : 6, fighterMod,
					Advantage.ADVANTAGE);
			AttackRoll fighterBrightAttack = factory.getSimpleAttackRoll(fighterMod + proficiency,
					fighterShadowBlade == 0 ? 2 : fighterShadowBlade, fighterShadowBlade > 0 ? 8 : 6, fighterMod);

			options.rowHeaders.addAll(Arrays.asList("Level " + level + " Fighter Attack x" + numOfFighterAttacks,
					"Level " + level + " Fighter GWM Attack x" + numOfFighterAttacks,
					"Level " + level + " Fighter ShadowBlade x" + numOfFighterAttacks,
					"Level " + level + " Fighter BrightBlade x" + numOfFighterAttacks,
					"Level " + level + " Sorcerer Attack x1", "Level " + level + " Sorcerer Shadow Attack x1",
					"Level " + level + " Sorcerer Bright Attack x1", "Level " + level + " Sorcerer Attack x2",
					"Level " + level + " Sorcerer Shadow Attack x2", "Level " + level + " Sorcerer Bright Attack x2"));

			for (int ac : acs) {
				rolls.add(factory
						.getMultiAttackVsAC("Fighter L" + level + "vs AC" + ac, fighterBasicAttack.repeatList(1), ac)
						.repeat(numOfFighterAttacks).getRoll());
				rolls.add(factory
						.getMultiAttackVsAC("Fighter GWM L" + level + "vs AC" + ac, fighterGWMAttack.repeatList(1), ac)
						.repeat(numOfFighterAttacks).getRoll());
				rolls.add(factory.getMultiAttackVsAC("Fighter Shadow L" + level + "vs AC" + ac,
						fighterShadowAttack.repeatList(1), ac).repeat(numOfFighterAttacks).getRoll());
				rolls.add(factory.getMultiAttackVsAC("Fighter Bright L" + level + "vs AC" + ac,
						fighterBrightAttack.repeatList(1), ac).repeat(numOfFighterAttacks).getRoll());
				rolls.add(factory
						.getMultiAttackVsAC("Sorcerer L" + level + "vs AC" + ac, sorcererBasicAttack.repeatList(1), ac)
						.getRoll());
				rolls.add(factory.getMultiAttackVsAC("Sorcerer Shadow L" + level + "vs AC" + ac,
						sorcererShadowAttack.repeatList(1), ac).getRoll());
				rolls.add(factory.getMultiAttackVsAC("Sorcerer Bright L" + level + "vs AC" + ac,
						sorcererBrightAttack.repeatList(1), ac).getRoll());
				rolls.add(factory
						.getMultiAttackVsAC("Sorcerer L" + level + "vs AC" + ac, sorcererBasicAttack.repeatList(1), ac)
						.repeat(2).getRoll());
				rolls.add(factory.getMultiAttackVsAC("Sorcerer Shadow L" + level + "vs AC" + ac,
						sorcererShadowAttack.repeatList(1), ac).repeat(2).getRoll());
				rolls.add(factory.getMultiAttackVsAC("Sorcerer Bright L" + level + "vs AC" + ac,
						sorcererBrightAttack.repeatList(1), ac).repeat(2).getRoll());
			}
		}

		options.groupSize = 10;
		return options;
	}

	public static List<Integer> getStandardACArray() {
		return Arrays.asList(0, 11, 13, 15, 17, 20, 25);
	}

	public static TableOptions getMonkBarbComparison(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = getStandardACArray();
		AttackRoll barb5Attack = factory.getSimpleAttackRoll(7, 2, 6, 6, Advantage.ADVANTAGE);
		AttackRoll barb3Monk2MainAttack = factory.getSimpleAttackRoll(6, 1, 8, 5, Advantage.ADVANTAGE);
		AttackRoll barb3Monk2OffAttack = factory.getSimpleAttackRoll(6, 1, 4, 5, Advantage.ADVANTAGE);
		AttackRoll barb5AttackNoAdv = factory.getSimpleAttackRoll(7, 2, 6, 6);
		AttackRoll barb3Monk2MainAttackNoAdv = factory.getSimpleAttackRoll(6, 1, 8, 5);
		AttackRoll barb3Monk2OffAttackNoAdv = factory.getSimpleAttackRoll(6, 1, 4, 5);
		AttackRoll monk5Attack = factory.getSimpleAttackRoll(7, 1, 8, 4);
		AttackRoll monk5OffAttack = factory.getSimpleAttackRoll(7, 1, 6, 4);

		options.groupSize = 7;
		options.rowHeaders.addAll(Arrays.asList("Barbarian 5 x3", "Barbarian 5 NOADV x3", "Barb3/Monk2 x2 + Flurry x2",
				"Barb3/Monk2 NOADV x2 + Flurry x2", "Barb3/Monk2 x1 + Flurry x2", "Barb3/Monk2 NOADV x1 + Flurry x2",
				"Monk 5 x2 + Flurry x2"));

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
			rolls.add(factory.getMultiAttackVsAC("Barb5 vs AC" + ac, barb5Attack.repeatList(3), ac).getRoll());
			rolls.add(
					factory.getMultiAttackVsAC("Barb5 NOADV vs AC" + ac, barb5AttackNoAdv.repeatList(3), ac).getRoll());

			rolls.add(factory
					.getMultiAttackVsAC("Barb3/Monk2 HOUSERULE vs AC" + ac, barb3Monk2MainAttack.repeatList(2), ac)
					.add(factory.getMultiAttackVsAC("Barb3/Monk2 Flurry vs AC" + ac, barb3Monk2OffAttack.repeatList(2),
							ac))
					.getRoll());
			rolls.add(factory
					.getMultiAttackVsAC("Barb3/Monk2 NOADV HOUSERULE vs AC" + ac,
							barb3Monk2MainAttackNoAdv.repeatList(2), ac)
					.add(factory.getMultiAttackVsAC("Barb3/Monk2 NOADV Flurry vs AC" + ac,
							barb3Monk2OffAttackNoAdv.repeatList(2), ac))
					.getRoll());

			rolls.add(factory
					.getMultiAttackVsAC("Barb3/Monk2 vs AC" + ac, barb3Monk2MainAttack.repeatList(1), ac).add(factory
							.getMultiAttackVsAC("Barb3/Monk2 Flurry vs AC" + ac, barb3Monk2OffAttack.repeatList(2), ac))
					.getRoll());
			rolls.add(factory
					.getMultiAttackVsAC("Barb3/Monk2 NOADV vs AC" + ac, barb3Monk2MainAttackNoAdv.repeatList(1), ac)
					.add(factory.getMultiAttackVsAC("Barb3/Monk2 NOADV Flurry vs AC" + ac,
							barb3Monk2OffAttackNoAdv.repeatList(2), ac))
					.getRoll());

			rolls.add(factory.getMultiAttackVsAC("Monk5 vs AC" + ac, monk5Attack.repeatList(2), ac)
					.add(factory.getMultiAttackVsAC("Monk5 Flurry vs AC" + ac, monk5OffAttack.repeatList(2), ac))
					.getRoll());
		}
		return options;
	}

	public static TableOptions getCrossbowComparison(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = Arrays.asList(0, 11, 13, 15, 17, 20, 25);
		int dexMod = 4;
		int profMod = 4;
		int archeryMod = 2;
		RollBuilder baseAttack = factory.getAttackRoll(dexMod + profMod + archeryMod);
		RollBuilder baseDamage = factory.getDiePlusMod(6, dexMod);
		RollBuilder baseCrit = factory.getXdYRoll(2, 6).add(dexMod);

		AttackRoll asiAttack = new AttackRoll(baseAttack.add(1), baseDamage.add(1), baseCrit.add(1));

		AttackRoll sharpUnusedAttack = new AttackRoll(baseAttack, baseDamage, baseCrit);
		AttackRoll sharpAttack = new AttackRoll(baseAttack.subtract(5), baseDamage.add(10), baseCrit.add(10));

		options.rowHeaders.addAll(Arrays.asList("Dex 20 x 3", "Sharpshooter Unused x 3", "Sharpshooter x 3"));
		options.groupSize = 3;

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);

			rolls.add(factory.getMultiAttackVsAC("Dex20 vs AC" + ac, Arrays.asList(asiAttack.repeat(3)), ac).getRoll());
			rolls.add(factory.getMultiAttackVsAC("Dex18 vs AC" + ac, Arrays.asList(sharpUnusedAttack.repeat(3)), ac)
					.getRoll());
			rolls.add(factory
					.getMultiAttackVsAC("Dex18 Sharpshooter vs AC" + ac, Arrays.asList(sharpAttack.repeat(3)), ac)
					.getRoll());
		}
		return options;
	}

	public static double getEffectiveHealth(int health, int ac, RollFactory factory, List<AttackRoll> attacks,
			AttackRoll sneakAttack) {
		Rollable roll = factory.getSneakAttackVsAC("", attacks, sneakAttack, ac).getRoll();
		// Rollable roll0 = factory.getSneakAttackVsAC("", attacks, sneakAttack,
		// -100_000_000).getRoll();
		double average = roll.mean().doubleValue();
		// double average0 = roll0.mean().doubleValue();
		double minimumEffectiveHealth = health;
		return minimumEffectiveHealth / average;
	}

	public static double getEffectiveHealth(int health, int ac, RollFactory factory, List<AttackRoll> attacks) {
		return getEffectiveHealth(health, ac, factory, attacks, new AttackRoll(new Modifier(0), new Modifier(0)));
	}

	public static TableOptions testEffectiveHealth(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		int health = 10;

		RollBuilder attackRoll = factory.getAttackRoll(0);
		RollBuilder damageRoll = factory.getXdYRoll(2, 6);
		RollBuilder critRoll = factory.getXdYRoll(4, 6);
		AttackRoll basicAttack = new AttackRoll(attackRoll, damageRoll, critRoll);

		RollBuilder proficientAttackRoll = factory.getAttackRoll(5);
		RollBuilder proficientDamageRoll = factory.getXdYRoll(2, 6).add(3);
		RollBuilder proficientCritRoll = factory.getXdYRoll(4, 6).add(3);
		AttackRoll proficientAttack = new AttackRoll(proficientAttackRoll, proficientDamageRoll, proficientCritRoll);

		// options.columnHeaders.add("Greatsword (STR 10)");
		// options.columnHeaders.add("Greatsword (STR 16 + Prof)");
		options.columnHeaders.add("Greatsword (STR 10)");
		options.columnHeaders.add("Greatsword (STR 16 + Prof)");
		for (int ac : ListAlgorithms.getRun(2, 25)) {
			options.rowHeaders.add("Avg. Rounds Alive @ AC " + ac);
			// double average = getEffectiveHealth(health, ac, factory,
			// Arrays.asList(basicAttack));
			// rolls.add(factory.createAverageOutcomeRoll(average).getRoll());
			// average = getEffectiveHealth(health, ac, factory,
			// Arrays.asList(proficientAttack));
			// rolls.add(factory.createAverageOutcomeRoll(average).getRoll());
			rolls.add(factory.getTimeToDownRoll(health, factory
					.getMultiAttackVsAC("Greatsword (10STR) vs AC" + ac, Arrays.asList(basicAttack), ac).getRoll())
					.getRoll());
			rolls.add(factory.getTimeToDownRoll(health, factory
					.getMultiAttackVsAC("Greatsword (16STR + Prof) vs AC" + ac, Arrays.asList(proficientAttack), ac)
					.getRoll()).getRoll());
		}
		return options;
	}

	public static TableOptions maulGreatswordGreataxe(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();

		List<Integer> levels = ListAlgorithms.getRun(20);
		List<Integer> acs = Arrays.asList(0, 10, 13, 16, 18, 20, 25);
		List<Advantage> advantages = Arrays.asList(Advantage.NONE, Advantage.ADVANTAGE);
		List<Pair<String, Pair<Integer, Integer>>> weapons = Arrays.asList(Pair.of("Maul (3d4)", Pair.of(3, 4)),
				Pair.of("Greatsword (2d6)", Pair.of(2, 6)), Pair.of("Greataxe (1d12)", Pair.of(1, 12)));

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
		}
		for (int level : levels) {
			for (Pair<String, Pair<Integer, Integer>> weapon : weapons) {
				for (Advantage advantage : advantages) {
					options.rowHeaders.add(weapon.first + " " + advantage + " L" + level);
				}
			}
		}
		options.groupSize = advantages.size() * weapons.size();
		for (int level : levels) {
			for (int ac : acs) {
				for (Pair<String, Pair<Integer, Integer>> weapon : weapons) {
					for (Advantage advantage : advantages) {
						int strength = level < 4 ? 16 : level < 8 ? 18 : level < 20 ? 20 : 24;
						int mod = asMod(strength);
						int prof = getProf(level);
						int rage = level < 9 ? 2 : level < 16 ? 3 : 4;
						RollBuilder attackRoll = factory.getAttackRoll(mod + prof, advantage);
						RollBuilder damageRoll = factory.getXdYRoll(weapon.second.first, weapon.second.second)
								.add(mod + rage);
						int brutal = level < 9 ? 0 : level < 13 ? 1 : level < 17 ? 2 : 3;
						RollBuilder critRoll = factory
								.getXdYRoll(weapon.second.first * 2 + brutal, weapon.second.second).add(mod + rage);

						AttackRoll attack = new AttackRoll(attackRoll, damageRoll, critRoll);

						rolls.add(factory
								.getMultiAttackVsAC(weapon.first + " " + advantage + " L" + level + " vs AC" + ac,
										Arrays.asList(attack.repeat(level >= 5 ? 2 : 1)), ac)
								.getRoll());
					}
				}
			}
		}

		return options;
	}

	public static TableOptions boomingBladeTesting(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		options.rowHeaders.addAll(Arrays.asList("Rogue3/Cleric8", "Arcane Trickster 11"));
		options.groupSize = 2;
		List<Integer> acs = Arrays.asList(0, 10, 13, 16, 18, 20, 25);

		RollBuilder attackRoll = factory.getAttackRoll(9);
		RollTemplate damageTemplate = new RollTemplate().add(5);
		RollTemplate critTemplate = new RollTemplate().repeat(2);
		RollBuilder baseDamage = factory.getXdYRoll(3, 8);
		RollBuilder damageRoll = damageTemplate.apply(baseDamage);
		RollBuilder critRoll = damageTemplate.prepend(critTemplate).apply(baseDamage);
		RollBuilder sneakDamage = factory.getXdYRoll(2, 6);
		RollBuilder sneakCrit = critTemplate.apply(sneakDamage);
		RollBuilder boomingBladeExtra = baseDamage;

		RollBuilder betterBaseDamage = factory.getXdYRoll(4, 8);
		RollBuilder betterNormalDamage = damageTemplate.apply(betterBaseDamage);
		RollBuilder betterCritDamage = damageTemplate.prepend(critTemplate).apply(betterBaseDamage);
		RollBuilder betterSneakDamage = factory.getXdYRoll(6, 6);
		RollBuilder betterSneakCrit = critTemplate.apply(betterSneakDamage);

		AttackRoll regularAttack = new AttackRoll(attackRoll.getRoll(), damageRoll.getRoll(), critRoll.getRoll());
		AttackRoll sneakAttack = new AttackRoll(sneakDamage.add(boomingBladeExtra).getRoll(),
				sneakCrit.add(boomingBladeExtra).getRoll());
		AttackRoll betterRegularAttack = new AttackRoll(attackRoll.getRoll(), betterNormalDamage.getRoll(),
				betterCritDamage.getRoll());
		AttackRoll betterSneakAttack = new AttackRoll(betterSneakDamage.add(boomingBladeExtra).getRoll(),
				betterSneakCrit.add(boomingBladeExtra).getRoll());

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
			rolls.add(factory.getSneakAttackVsAC("Rogue3/Cleric8 Booming Blade vs AC" + ac,
					Arrays.asList(regularAttack), sneakAttack, ac).getRoll());
			rolls.add(factory.getSneakAttackVsAC("Arcane Trickster 11 Booming Blade vs AC" + ac,
					Arrays.asList(betterRegularAttack), betterSneakAttack, ac).getRoll());
		}
		return options;
	}

	public static TableOptions getShieldBenefits(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> acs = ListAlgorithms.getRun(2, 20);
		List<Advantage> advs = Arrays.asList(Advantage.NONE, Advantage.ADVANTAGE, Advantage.DISADVANTAGE,
				Advantage.DOUBLE_ADVANTAGE);
		options.columnHeaders.addAll(Arrays.asList("Normal", "+Shield", "[%]"));
		RollBuilder attackRoll = factory.getAttackRoll(0);
		RollBuilder damageRoll = factory.getDiePlusMod(8, 7);
		RollBuilder critRoll = factory.getXdYRoll(2, 8).add(7);
		options.groupSize = 1;
		for (Advantage adv : advs) {
			for (int ac : acs) {
				AttackRoll attack = new AttackRoll(attackRoll.advantage(adv).getRoll(), damageRoll.getRoll(),
						critRoll.getRoll());
				rolls.add(factory.getDamageRollVsAC("Normal vs AC" + ac, attack, ac).getRoll());
				rolls.add(factory.getDamageRollVsAC("+Shield vs AC" + ac, attack, ac + 2).getRoll());
				rolls.add(StandardDice.mod0);
				options.rowHeaders.add("AC " + ac + " (" + adv.toString() + ")");
			}
		}
		return options;
	}

	public static TableOptions getEmilyVsOlivia(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		List<Integer> levels = new ArrayList<>();
		for (int i = 1; i <= 20; i++) {
			levels.add(i);
		}
		List<Integer> acs = Arrays.asList(0, 10, 13, 15, 18, 20, 25);
		Map<Pair<Integer, Integer>, EORolls> canonRolls = new HashMap<>();
		options.groupSize = EORolls.class.getFields().length;
		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
		}
		for (int level : levels) {
			for (int ac : acs) {
				EORolls eoRolls = getEmilyOliviaForLevel(level, ac, factory);
				canonRolls.put(Pair.of(level, ac), eoRolls);
			}
		}

		for (int level = 20; level >= 2; level--) {
			boolean allSame = true;
			for (int ac : acs) {
				Pair<Integer, Integer> pairA = Pair.of(level, ac);
				Pair<Integer, Integer> pairB = Pair.of(level - 1, ac);
				if (!Objects.equals(canonRolls.get(pairA), canonRolls.get(pairB))) {
					allSame = false;
					break;
				}
			}
			if (allSame) {
				for (int ac : acs) {
					Pair<Integer, Integer> pairA = Pair.of(level, ac);
					canonRolls.remove(pairA);
				}
				levels.remove((Object) level);
			}
		}

		Field[] fields = EORolls.class.getFields();
		for (int level : levels) {
			for (int ac : acs) {
				Pair<Integer, Integer> pairA = Pair.of(level, ac);
				EORolls eoRolls = canonRolls.get(pairA);
				for (Field field : fields) {
					try {
						Rollable roll = (Rollable) field.get(eoRolls);
						rolls.add(roll);
					} catch (IllegalArgumentException | IllegalAccessException e) {
						e.printStackTrace();
					}
				}
			}
			for (Field field : fields) {
				options.rowHeaders.add("L" + level + " " + field.getName());
			}
		}

		return options;
	}

	private static EORolls getEmilyOliviaForLevel(int level, int ac, RollFactory factory) {
		EORolls rolls = new EORolls();

		int emilyPaladinLevel;
		if (level <= 7) {
			emilyPaladinLevel = level;
		} else if (level <= 10) {
			emilyPaladinLevel = level - 1;
		} else if (level <= 14) {
			emilyPaladinLevel = 9;
		} else {
			emilyPaladinLevel = level - 5;
		}
		int emilyWarlockLevel;
		if (level <= 7) {
			emilyWarlockLevel = 0;
		} else if (level <= 10) {
			emilyWarlockLevel = 1;
		} else if (level <= 14) {
			emilyWarlockLevel = level - 9;
		} else {
			emilyWarlockLevel = 5;
		}

		int oliviaSorcererLevel;
		if (level <= 7) {
			oliviaSorcererLevel = level - 1;
		} else if (level <= 12) {
			oliviaSorcererLevel = 6;
		} else {
			oliviaSorcererLevel = level - 6;
		}
		int oliviaFighterLevel;
		if (level <= 9) {
			oliviaFighterLevel = 1;
		} else if (level <= 12) {
			oliviaFighterLevel = level - 8;
		} else {
			oliviaFighterLevel = 4;
		}
		int oliviaRogueLevel;
		if (level <= 7) {
			oliviaRogueLevel = 0;
		} else if (level <= 9) {
			oliviaRogueLevel = level - 7;
		} else {
			oliviaRogueLevel = 2;
		}

		int emilyAbilityScore = 16;
		int emilyAbilityMod = asMod(emilyAbilityScore);
		int oliviaAbilityScore = Math.min(20,
				16 + oliviaSorcererLevel / 4 * 2 + oliviaFighterLevel / 4 * 2 + oliviaRogueLevel / 4 * 2);
		int oliviaAbilityMod = asMod(oliviaAbilityScore);

		int emilySpellSlotLevel = (emilyPaladinLevel - 1) / 4 + 1;
		int emilyShadowBladeLevel = getShadowBlade(emilySpellSlotLevel);

		int oliviaSpellSlotLevel = (oliviaSorcererLevel - 1) / 2 + 1;
		int oliviaShadowBladeLevel = getShadowBlade(oliviaSpellSlotLevel);
		int profMod = getProf(level);
		int emilyWeaponBonus = 1;
		int emilyDuellingBonus = 2;
		int oliviaDuellingBonus = 2;
		int cantripExtraD8s = (level + 1) / 6;
		int emilyNumberOfAttacks = emilyPaladinLevel >= 5 ? 2 : 1;
		int emilyImprovedDivineSmite = emilyPaladinLevel >= 11 ? 1 : 0;

		Advantage oliviaAdvantage = oliviaSorcererLevel >= 4 ? Advantage.DOUBLE_ADVANTAGE : Advantage.ADVANTAGE;

		RollBuilder emilyCantripDamage = factory.getXdYRoll(emilyWarlockLevel >= 1 ? cantripExtraD8s : 0, 8);
		RollBuilder oliviaCantripDamage = factory.getXdYRoll(cantripExtraD8s, 8);
		RollBuilder emilyShadowBlade = factory.getXdYRoll(emilyShadowBladeLevel, 8);
		RollBuilder oliviaShadowBlade = factory.getXdYRoll(oliviaShadowBladeLevel, 8);
		RollBuilder oliviaSneakDamage = factory.getXdYRoll(oliviaRogueLevel >= 1 ? 1 : 0, 6);

		RollBuilder emilyAttack = factory.getAttackRoll(emilyAbilityMod + profMod + emilyWeaponBonus);
		RollBuilder emilyAttackShadow = factory.getAttackRoll(emilyAbilityMod + profMod);
		RollBuilder oliviaAttack = factory.getAttackRoll(oliviaAbilityMod + profMod);

		RollBuilder emilyDamage = factory.getXdYRoll(1 + emilyImprovedDivineSmite, 8);
		RollBuilder oliviaDamage = factory.getXdYRoll(1, 8);
		Rollable emilyDamageModifier = new Modifier(emilyAbilityMod + emilyDuellingBonus + emilyWeaponBonus);
		Rollable emilyShadowBladeModifier = new Modifier(emilyAbilityMod + emilyDuellingBonus);
		Rollable oliviaDamageModifier = new Modifier(oliviaAbilityMod + oliviaDuellingBonus);

		rolls.emilyBlessGFB = factory.getDamageRollVsAC("EmilyBlessGFB vs AC" + ac, emilyAttack.withBless().getRoll(),
				emilyDamage.add(emilyCantripDamage).add(emilyDamageModifier).getRoll(),
				emilyDamage.add(emilyCantripDamage).repeat(2).add(emilyDamageModifier).getRoll(), ac).getRoll();
		rolls.emilyShadowBlade = factory
				.getDamageRollVsAC("EmilyShadowBlade vs AC" + ac, emilyAttackShadow.advantage().getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyShadowBladeModifier).getRoll(),
						emilyDamage.add(emilyShadowBlade).repeat(2).add(emilyShadowBladeModifier).getRoll(), ac)
				.repeat(emilyNumberOfAttacks).getRoll();
		rolls.emilyShadowBladeBright = factory
				.getDamageRollVsAC("EmilyShadowBladeBright vs AC" + ac, emilyAttackShadow.getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyShadowBladeModifier).getRoll(),
						emilyDamage.add(emilyShadowBlade).repeat(2).add(emilyShadowBladeModifier).getRoll(), ac)
				.repeat(emilyNumberOfAttacks).getRoll();
		rolls.emilyShadowGFB = factory
				.getDamageRollVsAC("EmilyShadowGFB vs AC" + ac, emilyAttackShadow.advantage().getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyCantripDamage).add(emilyShadowBladeModifier)
								.getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyCantripDamage).repeat(2)
								.add(emilyShadowBladeModifier).getRoll(),
						ac)
				.getRoll();
		rolls.emilyShadowGFBBright = factory
				.getDamageRollVsAC("EmilyShadowGFBBright vs AC" + ac, emilyAttackShadow.getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyCantripDamage).add(emilyShadowBladeModifier)
								.getRoll(),
						emilyDamage.add(emilyShadowBlade).add(emilyCantripDamage).repeat(2)
								.add(emilyShadowBladeModifier).getRoll(),
						ac)
				.getRoll();
		rolls.emilyWithBless = factory
				.getDamageRollVsAC("EmilyWithBless vs AC" + ac, emilyAttack.withBless().getRoll(),
						emilyDamage.add(emilyDamageModifier).getRoll(),
						emilyDamage.repeat(2).add(emilyDamageModifier).getRoll(), ac)
				.repeat(emilyNumberOfAttacks).getRoll();

		AttackRoll oliviaDarknessAttack = new AttackRoll(oliviaAttack.advantage(oliviaAdvantage).getRoll(),
				oliviaDamage.add(oliviaCantripDamage).add(oliviaDamageModifier).getRoll(),
				oliviaDamage.add(oliviaCantripDamage).repeat(2).add(oliviaDamageModifier).getRoll());
		AttackRoll oliviaNormalAttack = new AttackRoll(oliviaAttack.getRoll(),
				oliviaDamage.add(oliviaCantripDamage).add(oliviaDamageModifier).getRoll(),
				oliviaDamage.add(oliviaCantripDamage).repeat(2).add(oliviaDamageModifier).getRoll());
		AttackRoll oliviaShadowAttack = new AttackRoll(oliviaAttack.advantage(oliviaAdvantage).getRoll(),
				oliviaDamage.add(oliviaShadowBlade).add(oliviaCantripDamage).add(oliviaDamageModifier).getRoll(),
				oliviaDamage.add(oliviaShadowBlade).add(oliviaCantripDamage).repeat(2).add(oliviaDamageModifier)
						.getRoll());
		AttackRoll oliviaShadowBrightAttack = new AttackRoll(oliviaAttack.getRoll(),
				oliviaDamage.add(oliviaShadowBlade).add(oliviaCantripDamage).add(oliviaDamageModifier).getRoll(),
				oliviaDamage.add(oliviaShadowBlade).add(oliviaCantripDamage).repeat(2).add(oliviaDamageModifier)
						.getRoll());
		AttackRoll oliviaSneakAttack = new AttackRoll(oliviaSneakDamage.getRoll(),
				oliviaSneakDamage.repeat(2).getRoll());
		rolls.oliviaDarkness = factory.getSneakAttackVsAC("OliviaDarkness vs AC" + ac,
				Arrays.asList(oliviaDarknessAttack.repeat(1)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaDarknessTwinned = factory.getSneakAttackVsAC("OliviaDarknessTwinned vs AC" + ac,
				Arrays.asList(oliviaDarknessAttack.repeat(2)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaNormal = factory.getSneakAttackVsAC("OliviaNormal vs AC" + ac,
				Arrays.asList(oliviaNormalAttack.repeat(1)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaNormalTwinned = factory.getSneakAttackVsAC("OliviaNormalTwinned vs AC" + ac,
				Arrays.asList(oliviaNormalAttack.repeat(2)), oliviaSneakAttack, ac).getRoll();

		rolls.oliviaShadow = factory.getSneakAttackVsAC("OliviaShadow vs AC" + ac,
				Arrays.asList(oliviaShadowAttack.repeat(1)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaShadowTwinned = factory.getSneakAttackVsAC("OliviaShadowTwinned vs AC" + ac,
				Arrays.asList(oliviaShadowAttack.repeat(2)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaShadowBright = factory.getSneakAttackVsAC("OliviaShadowBright vs AC" + ac,
				Arrays.asList(oliviaShadowBrightAttack.repeat(1)), oliviaSneakAttack, ac).getRoll();
		rolls.oliviaShadowBrightTwinned = factory.getSneakAttackVsAC("OliviaShadowBrightTwinned vs AC" + ac,
				Arrays.asList(oliviaShadowBrightAttack.repeat(2)), oliviaSneakAttack, ac).getRoll();

		return rolls;
	}

	private static int getShadowBlade(int spellSlotLevel) {
		if (spellSlotLevel >= 7)
			return 4;
		else if (spellSlotLevel >= 5)
			return 3;
		else if (spellSlotLevel >= 3)
			return 2;
		else if (spellSlotLevel >= 2)
			return 1;
		else
			return 0;
	}

	@SuppressWarnings("unused")
	private static class EORolls {
		public Rollable emilyWithBless;
		public Rollable emilyShadowBlade;
		public Rollable emilyShadowBladeBright;
		public Rollable emilyBlessGFB;
		public Rollable emilyShadowGFB;
		public Rollable emilyShadowGFBBright;
		public Rollable oliviaNormal;
		public Rollable oliviaNormalTwinned;
		public Rollable oliviaDarkness;
		public Rollable oliviaDarknessTwinned;
		public Rollable oliviaShadow;
		public Rollable oliviaShadowTwinned;
		public Rollable oliviaShadowBright;
		public Rollable oliviaShadowBrightTwinned;

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (o == null || !getClass().equals(o.getClass()))
				return false;
			EORolls e = (EORolls) o;
			Field[] fields = EORolls.class.getFields();
			for (Field field : fields) {
				try {
					Rollable a = (Rollable) field.get(this);
					Rollable b = (Rollable) field.get(e);

					if (!a.equivalentTo(b))
						return false;
				} catch (IllegalArgumentException | IllegalAccessException e1) {
					e1.printStackTrace();
					return false;
				}
			}
			return true;
		}
	}

	public static TableOptions getCustomCritFail(RollFactory factory, List<Rollable> rolls) {
		Rollable d6 = StandardDice.D6;
		RollBuilder counting = factory.getTransformed(d6, new Counter(new Outcome(1)));

		for (int i = 1; i <= 6; i++) {
			Rollable outcome = counting.repeat(i).getRoll();
			rolls.add(outcome);
		}

		return new TableOptions();
	}

	public static TableOptions getGWFvsTWF(RollFactory factory, List<Rollable> rolls) {
		boolean useModifiers = true;
		TableOptions options = new TableOptions();
		List<Integer> acs = Arrays.asList(0, 14, 16, 18, 20, 26);
		// List<Integer> acs = Arrays.asList(14);
		List<Integer> levels = Arrays.asList(1, 4, 5, 6, 8, 9, 11, 13, 17, 20);
		// List<Integer> levels = Arrays.asList(5);

		Modifier plus10 = new Modifier(10);
		Modifier minus5 = new Modifier(-5);

		options.groupSize = 3;
		for (int level : levels) {
			int ability;
			if (level >= 8) {
				ability = 20;
			} else if (level >= 6) {
				ability = 18;
			} else {
				ability = 16;
			}
			int strMod = asMod(ability);
			int dexMod = asMod(ability);

			if (useModifiers) {
				if (level >= 11) {
					dexMod++;
				}
				if (level >= 20) {
					dexMod++;
				}
			}

			int profMod = getProf(level);

			RollBuilder strAttackRoll = factory.getAttackRoll(strMod + profMod);
			RollBuilder dexAttackRoll = factory.getAttackRoll(dexMod + profMod);

			RollBuilder strWeapon = factory.getXdYGWFRoll(2, 6);
			int dexDieSize;
			if (level >= 4) {
				dexDieSize = 8;
			} else {
				dexDieSize = 6;
			}
			RollBuilder dexWeapon = factory.getDiePlusMod(dexDieSize, 0);

			RollBuilder strDamageRoll = strWeapon.add(new Modifier(strMod));
			RollBuilder strCritRoll = strWeapon.repeat(2).add(new Modifier(strMod));

			RollBuilder dexDamageRoll = dexWeapon.add(new Modifier(dexMod));
			RollBuilder dexCritRoll = dexWeapon.repeat(2).add(new Modifier(dexMod));

			int numOfAttacks;
			if (level < 5) {
				numOfAttacks = 1;
			} else if (level < 11) {
				numOfAttacks = 2;
			} else if (level < 20) {
				numOfAttacks = 3;
			} else {
				numOfAttacks = 4;
			}

			for (int ac : acs) {
				RollBuilder finalStrCritRoll;
				RollBuilder finalGwmStrCritRoll;
				if (level >= 4) {
					finalStrCritRoll = factory.getDamageRollVsAC("", strAttackRoll.getRoll(), strDamageRoll.getRoll(),
							strCritRoll.getRoll(), ac);
					finalGwmStrCritRoll = factory.getDamageRollVsAC("", strAttackRoll.add(minus5).getRoll(),
							strDamageRoll.add(plus10).getRoll(), strCritRoll.add(plus10).getRoll(), ac);
				} else {
					finalStrCritRoll = new RollBuilder(factory, StandardDice.mod0);
					finalGwmStrCritRoll = new RollBuilder(factory, StandardDice.mod0);
				}

				AttackRoll strengthAttack = new AttackRoll(strAttackRoll.getRoll(), strDamageRoll.getRoll(),
						strCritRoll.getRoll());
				AttackRoll strengthGWMAttack = new AttackRoll(strAttackRoll.add(minus5).getRoll(),
						strDamageRoll.add(plus10).getRoll(), strCritRoll.add(plus10).getRoll());
				AttackRoll dexterityAttack = new AttackRoll(dexAttackRoll.getRoll(), dexDamageRoll.getRoll(),
						dexCritRoll.getRoll());

				rolls.add(factory.getSneakAttackVsAC("L" + level + " Greatsword vs AC" + ac,
						Arrays.asList(strengthAttack.repeat(numOfAttacks)),
						new AttackRoll(StandardDice.mod0, finalStrCritRoll.getRoll()), ac, false).getRoll());
				rolls.add(factory.getSneakAttackVsAC("L" + level + " Greatsword (GWM Mode) vs AC" + ac,
						Arrays.asList(strengthGWMAttack.repeat(numOfAttacks)),
						new AttackRoll(StandardDice.mod0, finalGwmStrCritRoll.getRoll()), ac, false).getRoll());
				rolls.add(factory.getMultiAttackVsAC("L" + level + " Dual Swords vs AC" + ac,
						Arrays.asList(dexterityAttack.repeat(numOfAttacks + 1)), ac).getRoll());
			}
			options.rowHeaders.addAll(Arrays.asList("L" + level + " Greatsword x" + numOfAttacks,
					"L" + level + " Greatsword (GWM) x" + numOfAttacks,
					"L" + level + " Dual Swords x" + (numOfAttacks + 1)));
		}

		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
		}

		return options;
	}

	public static TableOptions getGamblingScenarios(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		options.csvSeparator = '|';
		List<GamblingOptions> optionsList = Arrays.asList(
				new GamblingOptions(Arrays.asList(0, 0, 0), Arrays.asList(-500, -300, 200, 400),
						new RollTemplate().subtract(factory.getXdYRoll(2, 6).add(3).getRoll()), new RollTemplate(),
						Advantage.NONE),
				new GamblingOptions(Arrays.asList(0, 0, 0), Arrays.asList(-1000, -400, 300, 700),
						new RollTemplate().subtract(factory.getXdYRoll(2, 8).add(4).getRoll()), new RollTemplate(),
						Advantage.NONE),
				new GamblingOptions(Arrays.asList(0, 0, 0), Arrays.asList(-2000, -500, 500, 1000),
						new RollTemplate().subtract(factory.getXdYRoll(2, 10).add(5).getRoll()), new RollTemplate(),
						Advantage.NONE),
				new GamblingOptions(Arrays.asList(0, 0, 0), Arrays.asList(-6000, -3000, -1000, 5000),
						new RollTemplate().subtract(factory.getXdYRoll(2, 12).add(9).getRoll()), new RollTemplate(),
						Advantage.NONE));

		List<Pair<String, RollTemplate>> templates = Arrays.asList(Pair.of("Normal", new RollTemplate()),
				Pair.of("Advantage", new RollTemplate().advantage()));

		List<Integer> modifierRuns = ListAlgorithms.getRun(-2, 22);
		options.columnHeaders.addAll(Arrays.asList("Low Stakes", "Medium Stakes", "High Stakes", "Extreme Stakes"));
		options.groupSize = templates.size();
		for (int baseModifier : modifierRuns) {
			for (GamblingOptions goptions : optionsList) {
				for (Pair<String, RollTemplate> templatePair : templates) {
					goptions.modifiers = Arrays.asList(baseModifier, baseModifier, baseModifier);
					goptions.playerTemplate = templatePair.second;
					getGamblingRoll(factory, rolls, goptions);
				}
			}
			for (Pair<String, RollTemplate> templatePair : templates) {
				options.rowHeaders.add("Modifiers: {" + baseModifier + "} - " + templatePair.first);
			}
		}

		return options;
	}

	public static class GamblingOptions {
		public List<Integer> modifiers = Arrays.asList(0, 0, 0);
		public List<Integer> results = Arrays.asList(-2000, -500, 500, 1000);
		public RollTemplate houseTemplate;
		public RollTemplate playerTemplate;

		public GamblingOptions() {
		}

		public GamblingOptions(List<Integer> modifiers, List<Integer> results, RollTemplate houseTemplate,
				RollTemplate playerTemplate, Advantage advantage) {
			this.modifiers = modifiers;
			this.results = results;
			this.houseTemplate = houseTemplate;
			this.playerTemplate = playerTemplate;
		}
	}

	public static TableOptions getGamblingRoll(RollFactory factory, List<Rollable> rolls, List<Integer> modifiers) {
		GamblingOptions options = new GamblingOptions();
		options.modifiers = modifiers;
		options.houseTemplate = new RollTemplate().subtract(factory.getXdYRoll(2, 10).add(5).getRoll());
		return getGamblingRoll(factory, rolls, options);
	}

	public static TableOptions getGamblingRoll(RollFactory factory, List<Rollable> rolls, GamblingOptions options) {
		List<Integer> modifiers = options.modifiers;
		final List<Integer> results = new ArrayList<>(options.results);
		RollBuilder base = new RollBuilder(factory);
		for (int modifier : modifiers) {
			RollTemplate template = options.playerTemplate.add(modifier).append(options.houseTemplate)
					.filterAndFlatten(0, FilterType.GREATER_EQUAL_TO);
			base = base.add(template.apply(factory.getD20Roll(0)));
		}

		String name;
		if (ListAlgorithms.allSame(modifiers)) {
			name = (modifiers.get(0) >= 0 ? "+" : "") + modifiers.get(0);
		} else {
			name = ListAlgorithms.toString(modifiers);
		}

		rolls.add(base.transform(roll -> {
			if (roll.value >= results.size())
				throw new RuntimeException("The number of Gambling Successes was " + roll.value
						+ ", but the Results table only had entries up to " + (results.size() - 1) + ".");
			else if (roll.value < 0)
				throw new RuntimeException("The number of Gambling Successes was negative!");
			return new Outcome(results.get(roll.value));
		}).rename("Gambling Roll for " + name + " with Results " + ListAlgorithms.toString(results)).getRoll());
		if (rolls.get(rolls.size() - 1) == null) {
			System.err.println("\"Gambling Roll for " + name + " with Results " + ListAlgorithms.toString(results)
					+ "\" was null!");
		}
		return new TableOptions();
	}

	// private static class GamblingCompositor implements Compositor {
	// int threshold;
	// public GamblingCompositor(int threshold) {this.threshold = threshold;}
	// @Override
	// public DieFace composite(DieFace roll1, DieFace roll2) {
	// if(roll1.value < threshold)
	// return roll2;
	// else
	// return roll1;
	// }
	//
	// public int hashCode() {return Objects.hash(threshold);}
	// public boolean equals(Object o) {
	// if(this == o)
	// return true;
	// else if(getClass() == o.getClass())
	// return ((GamblingCompositor)o).threshold == threshold;
	// else
	// return false;
	// }
	// }

	public static TableOptions getWitchBoltVsFireBolt(RollFactory factory, List<Rollable> rolls) {
		TableOptions options = new TableOptions();
		Rollable attackRoll = factory.getAttackRoll(0).getRoll();
		Rollable fireBoltDamage = StandardDice.D10;
		Rollable fireBoltCrit = factory.getXdYRoll(2, 10).getRoll();
		Rollable witchBoltDamage = factory.getXdYRoll(5, 12).getRoll();
		Rollable witchBoltCrit = factory.getXdYRoll(6, 12).getRoll();

		options.groupSize = 2;
		options.rowHeaders.addAll(Arrays.asList("Firebolt", "Witch Bolt"));
		List<Integer> acs = Arrays.asList(0, 11, 14, 16, 18, 20);
		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
			rolls.add(factory.getDamageRollVsAC("Firebolt vs AC" + ac, attackRoll, fireBoltDamage, fireBoltCrit, ac)
					.repeat(5).getRoll());
			rolls.add(factory.getDamageRollVsAC("Witch Bolt vs AC" + ac, attackRoll, witchBoltDamage, witchBoltCrit, ac)
					.getRoll());
		}
		return options;
	}

	public static TableOptions getFirearm(RollFactory factory, List<Rollable> rolls) {
		for (int i = 1; i <= 8; i++) {
			rolls.add(factory.getTransformed(StandardDice.D6, new Threshold(new Outcome(5))).repeat(i).getRoll());
			rolls.add(factory.getTransformed(StandardDice.D12, new Threshold(new Outcome(11))).repeat(i).getRoll());
		}

		return new TableOptions();
	}

	public static TableOptions getLevel20Fighter(RollFactory factory, List<Rollable> rolls) {
		int strengthMod = 5;
		int profMod = 6;

		Rollable gwfAttackRoll = factory.getAttackRoll(strengthMod + profMod - 5).getRoll();
		Rollable gwfDamageRoll = factory.getXdYGWFRoll(2, 6).add(new Modifier(strengthMod + 10)).getRoll();
		Rollable gwfCritRoll = factory.getXdYGWFRoll(4, 6).add(new Modifier(strengthMod + 10)).getRoll();
		Rollable gwfMinusAttackRoll = factory.getAttackRoll(strengthMod + profMod).getRoll();
		Rollable gwfMinusDamageRoll = factory.getXdYGWFRoll(2, 6).add(new Modifier(strengthMod)).getRoll();
		Rollable gwfMinusCritRoll = factory.getXdYGWFRoll(4, 6).add(new Modifier(strengthMod)).getRoll();

		Rollable longswordAttackRoll = factory.getAttackRoll(strengthMod + profMod).getRoll();
		Rollable longswordDamageRoll = factory.getDiePlusMod(8, strengthMod).getRoll();
		Rollable longswordCritRoll = factory.getXdYRoll(2, 8).add(new Modifier(strengthMod)).getRoll();
		Rollable longswordOffDamageRoll = factory.getDiePlusMod(8, 0).getRoll();
		Rollable longswordOffCritRoll = factory.getXdYRoll(2, 8).getRoll();

		TableOptions options = new TableOptions();
		options.groupSize = 4;
		options.rowHeaders.addAll(Arrays.asList("Greatsword x4", "Greatsword (no feat) x4",
				"Greatsword x3 + Longsword x2", "Greatsword (no feat) x3 + Longsword x2"));
		List<Integer> acs = Arrays.asList(0, 14, 16, 18, 20, 21, 22, 26);
		for (int ac : acs) {
			options.columnHeaders.add("AC " + ac);
			rolls.add(factory.getDamageRollVsAC("Greatsword vs AC" + ac, gwfAttackRoll, gwfDamageRoll, gwfCritRoll, ac)
					.repeat(4).getRoll());
			rolls.add(factory.getDamageRollVsAC("Greatsword (no feat) vs AC" + ac, gwfMinusAttackRoll,
					gwfMinusDamageRoll, gwfMinusCritRoll, ac).repeat(4).getRoll());
			rolls.add(factory.getDamageRollVsAC("Greatsword vs AC" + ac, gwfAttackRoll, gwfDamageRoll, gwfCritRoll, ac)
					.repeat(3)
					.add(factory.getDamageRollVsAC("Longsword vs AC" + ac, longswordAttackRoll, longswordDamageRoll,
							longswordCritRoll, ac))
					.add(factory.getDamageRollVsAC("Longsword (off) vs AC" + ac, longswordAttackRoll,
							longswordOffDamageRoll, longswordOffCritRoll, ac))
					.getRoll());
			rolls.add(factory
					.getDamageRollVsAC("Greatsword (no feat) vs AC" + ac, gwfMinusAttackRoll, gwfMinusDamageRoll,
							gwfMinusCritRoll, ac)
					.repeat(3)
					.add(factory.getDamageRollVsAC("Longsword vs AC" + ac, longswordAttackRoll, longswordDamageRoll,
							longswordCritRoll, ac))
					.add(factory.getDamageRollVsAC("Longsword (off) vs AC" + ac, longswordAttackRoll,
							longswordOffDamageRoll, longswordOffCritRoll, ac))
					.getRoll());
		}
		return options;
	}

	private static int asMod(int stat) {
		return (int) Math.floor(stat - 10 / 2.0);
	}

	private static int getProf(int level) {
		return (level + 7) / 4;
	}

	private MyRolls() {
	}
}
