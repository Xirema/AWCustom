package org.scratch.test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class FileCopier {
	public static void main(String[] args) throws IOException {
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle("Select Files to Copy");
		chooser.setMultiSelectionEnabled(true);
		int ret = chooser.showOpenDialog(null);
		if(ret != JFileChooser.APPROVE_OPTION)
			return;
		File[] files = chooser.getSelectedFiles();
		String replace = JOptionPane.showInputDialog("String to replace for copied files");
		String to = JOptionPane.showInputDialog("Comma Separated, list of strings to replace it with");
		if(replace == null || to == null)
			return;
		String[] replacements = to.split(",");
		for(File file : files) {
			File parent = file.getParentFile();
			String fileName = file.getName();
			for(String replacement : replacements) {
				String newFileName = fileName.replace(replace, replacement);
				File newFile = new File(parent, newFileName);
				Files.copy(file.toPath(), newFile.toPath());
			}
		}
	}
}
