package org.scratch.test;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class FindInManyFiles {
	
	public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Upper Directory");
		fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		if(fileChooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) {
			return;
		}
		
		Deque<File> directories = new ArrayDeque<>();
		directories.push(fileChooser.getSelectedFile());
		List<Future<String>> fileContents = new ArrayList<>();
		Executor executor = Executors.newCachedThreadPool();
		String searchString = JOptionPane.showInputDialog(null, "String to Search For");
		if(searchString == null)
			return;
		while(directories.size() > 0) {
			File directory = directories.pop();
			for(File file : directory.listFiles()) {
				if(file.isDirectory()) {
					directories.push(file);
				}
				else {
					FutureTask<String> task = new FutureTask<>(() -> {
						List<String> contents;
						try {
							contents = Files.readAllLines(file.toPath(), StandardCharsets.ISO_8859_1);
						} catch (Exception e) {
							e.printStackTrace();
							return "Unable to read " + file.getAbsolutePath() + ".";
						}
						for(int i = 0; i < contents.size(); i++) {
							if(contents.get(i).toUpperCase().contains(searchString.toUpperCase())) {
								
								return "File " + file.getAbsolutePath() + " contained reference on line " + i;
							}
						}
						return "File " + file.getAbsolutePath() + " did not contain reference.";
					});
					fileContents.add(task);
					executor.execute(task);
				}
			}
		}
		
		for(Future<String> fileContent : fileContents) {
			System.out.println(fileContent.get());
		}
	}
}
