package org.scratch.test;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryStack;

public class OGLTest {
	public static void main(String[] args) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			GLFW.glfwInit();
			long window = GLFW.glfwCreateWindow(800, 450, stack.UTF8("OpenGL Testing"), 0, 0);
			GLFW.glfwMakeContextCurrent(window);
			GLCapabilities capabilities = GL.createCapabilities();
			System.out.println("4.0: " + capabilities.OpenGL40);
			System.out.println("4.1: " + capabilities.OpenGL41);
			System.out.println("4.2: " + capabilities.OpenGL42);
			System.out.println("4.3: " + capabilities.OpenGL43);
			System.out.println("4.4: " + capabilities.OpenGL44);
			System.out.println("4.5: " + capabilities.OpenGL45);
			System.out.println("4.6: " + capabilities.OpenGL46);
			
		}
	}
}
