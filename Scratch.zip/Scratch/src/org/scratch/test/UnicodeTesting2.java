package org.scratch.test;

import java.io.UnsupportedEncodingException;

public class UnicodeTesting2 {
	public static void main(String[] args) throws UnsupportedEncodingException {
		System.out.println(System.getProperty("java.version"));
		String header = "\u2554\u2550";
		for(byte b : header.getBytes("UTF-8")) {
			System.out.printf("%02X ", b);
		}
		System.out.println();
		System.out.println(header);
	}
}
