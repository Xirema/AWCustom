package org.scratch.main.context.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;

import org.scratch.main.util.AutoSortedList;

public class ContextManager {
	private AutoSortedList<Context> contexts;

	public ContextManager() {
		contexts = new AutoSortedList<>();
	}

	public InputContext createContext(Object identity, int layer, Rect bounds) {
		Context context = new Context(layer, bounds, identity);
		contexts.add(context);
		return context;
	}

	public Collection<InputContext> getContexts(double x, double y) {
		Collection<InputContext> ret = new ArrayList<>();
		int currentLayer = 0;
		boolean found = false;
		for (InputContext context : contexts) {
			if (found && context.getLayer() != currentLayer) {
				break;
			}
			if (context.contains(x, y)) {
				found = true;
				ret.add(context);
			}
		}
		return ret;
	}

	private static class Context implements InputContext, Comparable<Context> {
		private int layer;
		private Rect bounds;
		private Object identity;

		public Context(int layer, Rect bounds, Object identity) {
			this.layer = layer;
			this.bounds = bounds;
			this.identity = identity;
		}

		@Override
		public boolean equals(Object o) {
			return Objects.equals(identity, ((Context) o).identity);
		}

		@Override
		public int getLayer() {
			return layer;
		}

		@Override
		public boolean contains(double x, double y) {
			return bounds.contains(x, y);
		}

		@Override
		public int compareTo(Context o) {
			return layer - o.layer;
		}

	}
}
