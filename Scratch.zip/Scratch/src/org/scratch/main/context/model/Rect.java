package org.scratch.main.context.model;

public class Rect {
	public final double x_w, x_e, y_s, y_n;

	public Rect() {
		this(0, 0, 0, 0);
	}

	public Rect(double x_w, double x_e, double y_s, double y_n) {
		this.x_w = x_w;
		this.x_e = x_e;
		this.y_s = y_s;
		this.y_n = y_n;
	}

	public boolean contains(double x, double y) {
		return x >= x_w && x < x_e && y >= y_s && y < y_n;
	}
}
