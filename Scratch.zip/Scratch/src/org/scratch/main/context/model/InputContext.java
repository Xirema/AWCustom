package org.scratch.main.context.model;

public interface InputContext {
	int getLayer();

	boolean contains(double x, double y);
}
