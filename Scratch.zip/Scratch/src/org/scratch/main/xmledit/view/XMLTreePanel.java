package org.scratch.main.xmledit.view;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

import javax.swing.JPanel;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellEditor;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeModel;

import java.util.Optional;
import org.scratch.main.xmledit.model.DocumentModel;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class XMLTreePanel extends JPanel implements DocumentModelListener {
	JTree tree = new JTree();
	TreeModel treeModel;

	public XMLTreePanel() {
		add(tree);
	}

	@Override
	public void setModel(DocumentModel model) {
		tree.setModel(buildTree(model.getDocument()));
		tree.setCellRenderer(new DefaultTreeCellRenderer());
		tree.setCellEditor(new DefaultTreeCellEditor(tree, (DefaultTreeCellRenderer) tree.getCellRenderer()));
	}

	private TreeModel buildTree(Document document) {
		Node root = document.getFirstChild();
		Deque<Node> nodeDeque = new ArrayDeque<>();
		nodeDeque.push(root);
		Deque<MutableTreeNode> treeNodeDeque = new ArrayDeque<>();
		MutableTreeNode treeRoot = new DefaultMutableTreeNode("XML");
		MutableTreeNode first = new XMLTreeNode(root.getNodeType(), root.getNodeName());
		treeRoot.insert(first, 0);
		treeNodeDeque.push(first);
		while (!nodeDeque.isEmpty()) {
			Node node = nodeDeque.pop();
			MutableTreeNode treeNode = treeNodeDeque.pop();
			if (node != null) {
				NamedNodeMap map = node.getAttributes();
				if (map != null) {
					for (int i = 0; i < map.getLength(); i++) {
						Node attribute = map.item(i);
						MutableTreeNode treeAttribute = new XMLTreeNode(attribute.getNodeType(), getValue(attribute));
						treeNode.insert(treeAttribute, treeNode.getChildCount());
					}
				}

				Node sibling = node.getNextSibling();
				if (sibling != null) {
					String value = getValue(sibling);
					MutableTreeNode treeSibling = new XMLTreeNode(sibling.getNodeType(), value);
					((MutableTreeNode) treeNode.getParent()).insert(treeSibling, treeNode.getParent().getChildCount());
					nodeDeque.push(sibling);
					treeNodeDeque.push(treeSibling);
				}

				Node child = node.getFirstChild();
				if (child != null) {
					String value = getValue(child);
					MutableTreeNode treeChild = new XMLTreeNode(child.getNodeType(), value);
					treeNode.insert(treeChild, treeNode.getChildCount());
					nodeDeque.push(child);
					treeNodeDeque.push(treeChild);
				}
			}
		}
		return new DefaultTreeModel(treeRoot);
	}

	private String getValue(Node node) {
		switch (XMLTreeNode.Type.toType(node.getNodeType())) {
		case ELEMENT:
			return node.getNodeName();
		case ATTRIBUTE:
			return node.getNodeName() + ": " + node.getNodeValue();
		case TEXT:
			return node.getNodeValue();
		default:
			return Optional.ofNullable(node.getNodeValue()).orElse(node.getNodeName());
		}
	}

	public static class XMLTreeNode extends DefaultMutableTreeNode {
		public static enum Type {
			ELEMENT, ATTRIBUTE, TEXT, CDATA_SECTION, ENTITY_REFERENCE, ENTITY, PROCESSING, COMMENT, DOCUMENT, DOCUMENT_TYPE, DOCUMENT_FRAGMENT, NOTATION;

			public static Type toType(short type) {
				if (type < Node.ELEMENT_NODE || type > Node.NOTATION_NODE)
					throw new RuntimeException("Invalid Node Type specified: " + type);
				return Type.values()[type - 1];
			}

			public short toConstant() {
				return (short) Arrays.binarySearch(Type.values(), this);
			}
		}

		private Type type;

		public XMLTreeNode(Type type, Object userData) {
			this(type, userData, true);
		}

		public XMLTreeNode(short type, Object userData) {
			this(Type.toType(type), userData);
		}

		public XMLTreeNode(Type type) {
			this(type, null);
		}

		public XMLTreeNode(Type type, Object userData, boolean allowsChildren) {
			super(userData, allowsChildren);
			this.type = type;
		}

		public void setType(Type type) {
			this.type = type;
		}

		public Type getType() {
			return type;
		}

	}
}
