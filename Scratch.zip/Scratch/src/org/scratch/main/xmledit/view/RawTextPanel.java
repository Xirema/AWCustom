package org.scratch.main.xmledit.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.scratch.main.xmledit.model.DocumentModel;

public class RawTextPanel extends JPanel implements DocumentModelListener {
	private static final long serialVersionUID = 0L;

	JTextArea textArea = new JTextArea();
	JScrollPane scrollPane = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
			JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

	public RawTextPanel() {
		setLayout(new BorderLayout());
		add(scrollPane, BorderLayout.CENTER);
		textArea.setFont(new Font("Courier New", Font.PLAIN, 12));
	}

	@Override
	public void setModel(DocumentModel model) {
		textArea.setText(model.getRawFile());
	}

	public String getText() {
		return textArea.getText();
	}

	public void enableTextArea(boolean enabled) {
		textArea.setEnabled(enabled);
		if (enabled) {
			textArea.setSelectionColor(new JTextArea().getSelectionColor());
		} else {
			textArea.setSelectionColor(Color.YELLOW);
		}
	}
}
