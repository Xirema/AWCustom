package org.scratch.main.xmledit.view;

import org.scratch.main.xmledit.model.DocumentModel;

public interface DocumentModelListener {
	void setModel(DocumentModel model);
}
