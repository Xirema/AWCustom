package org.scratch.main.xmledit;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.xml.parsers.ParserConfigurationException;

import org.scratch.main.xmledit.model.DocumentModel;
import org.scratch.main.xmledit.view.DocumentModelListener;
import org.scratch.main.xmledit.view.RawTextPanel;
import org.scratch.main.xmledit.view.XMLTreePanel;
import org.xml.sax.SAXException;

public class XMLEdit {
	public static void main(String[] args)
			throws FileNotFoundException, IOException, ParserConfigurationException, SAXException {
		JFrame frame = new JFrame("XML Edit");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(new BorderLayout());
		frame.add(new RawTextPanel(), BorderLayout.EAST);
		frame.add(new XMLTreePanel(), BorderLayout.WEST);
		frame.setVisible(true);
		frame.setMinimumSize(new Dimension(800, 600));
		JFileChooser chooser = new JFileChooser(".");
		chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		chooser.setMultiSelectionEnabled(false);
		chooser.setFileFilter(new FileNameExtensionFilter("XML Files", "xml"));
		if (chooser.showOpenDialog(frame) != JFileChooser.APPROVE_OPTION)
			return;
		File file = chooser.getSelectedFile();
		DocumentModel model;
		try (FileInputStream stream = new FileInputStream(file)) {
			model = new DocumentModel(stream);
		}
		Component[] components = frame.getContentPane().getComponents();
		for (Component component : components) {
			if (component instanceof DocumentModelListener) {
				((DocumentModelListener) component).setModel(model);
				System.out.println("Model Applied.");
			}
		}
		frame.pack();
	}
}
