package org.scratch.main.xmledit.model;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.scratch.main.util.StringUtil;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class DocumentModel {
	private Document document;
	private String rawFile;

	public DocumentModel(InputStream input) throws ParserConfigurationException, SAXException, IOException {
		this(StringUtil.toString(input));
	}

	public DocumentModel(String rawFile) throws ParserConfigurationException, SAXException, IOException {
		this(rawFile, createDocument(new ByteArrayInputStream(rawFile.getBytes())));
	}

	private DocumentModel(String rawFile, Document document) {
		this.rawFile = rawFile;
		this.document = document;
	}

	private static Document createDocument(InputStream input)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		return builder.parse(input);
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) throws TransformerException {
		this.document = document;
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		StringWriter writer = new StringWriter();
		transformer.transform(new DOMSource(document), new StreamResult(writer));
		rawFile = writer.getBuffer().toString().replaceAll("\n|\r", "");
	}

	public String getRawFile() {
		return rawFile;
	}

	public void setRawFile(String rawFile) throws ParserConfigurationException, SAXException, IOException {
		this.rawFile = rawFile;
		document = createDocument(new ByteArrayInputStream(rawFile.getBytes()));
	}
}
