package org.scratch.main.base64;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

public class Base64Converter {
	private static final int[] table = new int[64];
	private static final int[] reverseTable = new int[255];
	static {
		for (int i = 0; i < 26; i++) {
			table[i] = 'A' + i;
		}
		for (int i = 0; i < 26; i++) {
			table[i + 26] = 'a' + i;
		}
		for (int i = 0; i < 10; i++) {
			table[i + 52] = '0' + i;
		}
		table[62] = '+';
		table[63] = '/';

		Arrays.fill(reverseTable, 0);

		for (int i = 0; i < 64; i++) {
			reverseTable[table[i]] = i;
		}
	}

	public static void encode(InputStream in, OutputStream out) throws IOException {
		int[] outBytes = new int[4];
		byte[] outBytesRaw = new byte[4];
		byte[] inBytesRaw = new byte[3];
		int[] inBytes = new int[3];
		int read = 0;
		long last = System.nanoTime();
		long total = 0;
		while ((read = in.read(inBytesRaw)) != -1) {
			long now = System.nanoTime();
			total += read;
			if (now - last > 1_000_000_000) {
				last = now;
				System.err.println("Bytes read: " + total);
			}
			for (int i = 0; i < inBytesRaw.length; i++) {
				inBytes[i] = inBytesRaw[i] & 0xFF;
			}
			// System.err.println(ArrayPrinter.toString(inBytes));
			outBytes[0] = inBytes[0] >>> 2;
			if (read == 3) {
				outBytes[1] = ((inBytes[0] & 0x3) << 4) | (inBytes[1] >>> 4);
				outBytes[2] = ((inBytes[1] & 0xF) << 2) | (inBytes[2] >>> 6);
				outBytes[3] = inBytes[2] & 0x3F;
			} else if (read == 2) {
				outBytes[1] = ((inBytes[0] & 0x3) << 4) | (inBytes[1] >>> 4);
				outBytes[2] = ((inBytes[1] & 0xF) << 2);
			} else if (read == 1) {
				outBytes[1] = (inBytes[0] & 0x3) << 4;
			}
			// System.err.println(ArrayPrinter.toString(outBytes));
			for (int i = 0; i < outBytes.length; i++) {
				outBytesRaw[i] = (byte) table[outBytes[i]];
			}
			if (read == 2) {
				outBytesRaw[3] = '=';
			}
			if (read == 1) {
				outBytesRaw[2] = outBytesRaw[3] = '=';
			}
			out.write(outBytesRaw);
		}
	}

	public static void decode(InputStream in, OutputStream out) throws IOException {
		int[] outBytes = new int[3];
		int[] inBytes = new int[4];
		byte[] outBytesRaw = new byte[3];
		byte[] inBytesRaw = new byte[4];
		int read = 0;
		while ((read = in.read(inBytesRaw)) != -1) {
			for (int i = 0; i < inBytes.length; i++) {
				inBytes[i] = inBytesRaw[i] & 0xFF;
			}
			for (int i = 0; i < inBytes.length; i++) {
				if (inBytes[i] != '=') {
					inBytes[i] = reverseTable[inBytesRaw[i]];
				} else {
					inBytes[i] = 0;
				}
			}
			if (read == 4) {
				outBytes[0] = (inBytes[0] << 2) | (inBytes[1] >>> 4);
				outBytes[1] = ((inBytes[1] & 0xF) << 4) | (inBytes[2] >>> 2);
				outBytes[2] = ((inBytes[2] & 0x3) << 6) | inBytes[3];
			} else if (read == 3) {
				outBytes[0] = (inBytes[0] << 2) | (inBytes[1] >>> 4);
				outBytes[1] = ((inBytes[1] & 0xF) << 4) | (inBytes[2] >>> 2);
				outBytes[2] = ((inBytes[2] & 0x3) << 6);
			} else if (read == 2) {
				outBytes[0] = (inBytes[0] << 2) | (inBytes[1] >>> 4);
				outBytes[1] = ((inBytes[1] & 0xF) << 4);
				outBytes[2] = 0;
			} else if (read == 1) {
				outBytes[0] = (inBytes[0] << 2);
				outBytes[1] = 0;
				outBytes[2] = 0;
			}
			for (int i = 0; i < outBytes.length; i++) {
				outBytesRaw[i] = (byte) outBytes[i];
			}
			out.write(outBytesRaw);
		}
	}
}
