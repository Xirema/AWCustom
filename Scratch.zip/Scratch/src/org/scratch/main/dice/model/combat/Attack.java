package org.scratch.main.dice.model.combat;

import org.scratch.main.dice.model.RollFactory;
import org.scratch.main.dice.model.Rollable;

public class Attack {
	public final Rollable attackRoll;
	public final Rollable damageRoll;
	public final Rollable critRoll;
	public final String name;

	public Attack(String name, Rollable attackRoll, Rollable damageRoll, Rollable critRoll) {
		this.name = name;
		this.attackRoll = attackRoll;
		this.damageRoll = damageRoll;
		this.critRoll = critRoll;
	}

	public Rollable vsAC(RollFactory factory, int ac) {
		return factory.getDamageRollVsAC(name + "vs AC" + ac, attackRoll, damageRoll, critRoll, ac).getRoll();
	}
}
