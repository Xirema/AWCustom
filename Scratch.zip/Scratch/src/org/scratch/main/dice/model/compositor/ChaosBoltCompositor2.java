package org.scratch.main.dice.model.compositor;

import java.util.HashMap;
import java.util.Map;

import org.scratch.main.dice.model.Outcome;
import java.util.Optional;

public class ChaosBoltCompositor2 implements Compositor {
	private ChaosBoltCompositor2() {
	}

	public static final ChaosBoltCompositor2 instance = new ChaosBoltCompositor2();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		Outcome ret = new Outcome();
		Map<Outcome, Integer> results = new HashMap<>();
		results.put(new Outcome(roll1.value), Optional.ofNullable(results.get(new Outcome(roll1.value))).orElse(0) + 1);
		results.put(new Outcome(roll1.special), Optional.ofNullable(results.get(new Outcome(roll1.special))).orElse(0) + 1);
		results.put(new Outcome(roll2.value), Optional.ofNullable(results.get(new Outcome(roll2.value))).orElse(0) + 1);
		results.put(new Outcome(roll2.special), Optional.ofNullable(results.get(new Outcome(roll2.special))).orElse(0) + 1);
		for (Map.Entry<Outcome, Integer> entry : results.entrySet()) {
			if (entry.getKey().value <= 0) {
				continue;
			}
			if (entry.getValue() == 2) {
				if (ret.value == 1) {
					ret = new Outcome(1, 1);
				} else {
					ret = new Outcome(1, 0);
				}
			} else if (entry.getValue() == 3) {
				ret = new Outcome(2, 0);
			} else if (entry.getValue() == 4) {
				ret = new Outcome(2, 2);
			}
		}
		return ret;
	}
}
