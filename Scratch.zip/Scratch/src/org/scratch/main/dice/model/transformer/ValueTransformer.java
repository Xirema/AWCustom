package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class ValueTransformer implements Transformer {
	private ValueTransformer() {
	}

	public static final ValueTransformer instance = new ValueTransformer();

	@Override
	public Outcome transform(Outcome roll) {
		return new Outcome(roll.value);
	}

}
