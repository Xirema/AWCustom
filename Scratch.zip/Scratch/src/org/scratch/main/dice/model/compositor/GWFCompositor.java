package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class GWFCompositor implements Compositor {
	public final Outcome threshold;

	public GWFCompositor(Outcome threshold) {
		this.threshold = threshold;
	}

	public GWFCompositor() {
		this(new Outcome(2));
	}

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		if (roll1.compareTo(threshold) <= 0)
			return roll2;
		else
			return roll1;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof GWFCompositor))
			return false;
		GWFCompositor t = (GWFCompositor) o;
		return t.threshold == threshold;
	}

	@Override
	public int hashCode() {
		return threshold.hashCode();
	}
}
