package org.scratch.main.dice.model;

import java.util.Objects;
import java.util.Random;

import org.scratch.main.dice.model.compositor.Compositor;

public class CompositeRoll extends ProbabilityMapRoll {
	public final Rollable firstRoll, secondRoll;
	public final Compositor compositor;

	CompositeRoll(Rollable firstRoll, Rollable secondRoll, Compositor compositor) {
		this("Composite Roll", firstRoll, secondRoll, compositor);
	}

	CompositeRoll(String name, Rollable firstRoll, Rollable secondRoll, Compositor compositor) {
		super(name);
		this.firstRoll = firstRoll;
		this.secondRoll = secondRoll;
		this.compositor = compositor;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof CompositeRoll))
			return false;
		CompositeRoll r = (CompositeRoll) o;
		return ((r.firstRoll.equals(firstRoll) && r.secondRoll.equals(secondRoll))
				|| (r.firstRoll.equals(secondRoll) && r.secondRoll.equals(firstRoll)))
				&& r.compositor.equals(compositor);
	}

	@Override
	public int hashCode() {
		return Objects.hash(firstRoll.hashCode() + secondRoll.hashCode(), compositor);
	}

	@Override
	public Outcome roll(Random engine) {
		return compositor.composite(firstRoll.roll(engine), secondRoll.roll(engine));
	}
}
