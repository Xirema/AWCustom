package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Identity implements Transformer {
	private Identity() {
	}

	public static final Identity INSTANCE = new Identity();

	@Override
	public Outcome transform(Outcome roll) {
		return roll;
	}

}
