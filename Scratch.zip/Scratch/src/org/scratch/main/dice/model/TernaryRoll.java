package org.scratch.main.dice.model;

import java.util.Objects;
import java.util.Random;

import org.scratch.main.dice.model.ternary.TernaryOperator;

public class TernaryRoll extends ProbabilityMapRoll {
	TernaryRoll(String name, Rollable conditionRoll, Rollable trueRoll, Rollable falseRoll, TernaryOperator operator) {
		super(name);
		this.conditionRoll = conditionRoll;
		this.trueRoll = trueRoll;
		this.falseRoll = falseRoll;
		this.operator = operator;
	}

	public final Rollable conditionRoll, trueRoll, falseRoll;
	public final TernaryOperator operator;

	@Override
	public Outcome roll(Random engine) {
		Outcome condition = conditionRoll.roll(engine);
		Outcome trueFace = trueRoll.roll(engine);
		Outcome falseFace = falseRoll.roll(engine);
		return operator.test(condition) ? trueFace : falseFace;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof TernaryRoll))
			return false;
		TernaryRoll r = (TernaryRoll) o;
		return conditionRoll.equals(r.conditionRoll) && trueRoll.equals(r.trueRoll) && falseRoll.equals(r.falseRoll)
				&& operator.equals(r.operator);
	}

	@Override
	public int hashCode() {
		return Objects.hash(conditionRoll, trueRoll, falseRoll, operator);
	}
}
