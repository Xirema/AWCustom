package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;
import org.scratch.main.dice.model.RegularDie;

public class WildMagicCompositor implements Compositor {
	public final Outcome threshold;

	public WildMagicCompositor(Outcome threshold) {
		this.threshold = threshold;
	}

	public WildMagicCompositor(RegularDie die) {
		threshold = die.highestOutcome();
	}

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		if (roll1.compareTo(threshold) < 0)
			return roll1;
		else
			return new Outcome(roll1.value + roll2.value, roll1.special + roll2.special);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof WildMagicCompositor))
			return false;
		WildMagicCompositor t = (WildMagicCompositor) o;
		return t.threshold == threshold;
	}

	@Override
	public int hashCode() {
		return threshold.hashCode();
	}
}
