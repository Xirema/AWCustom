package org.scratch.main.dice.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.scratch.main.dice.model.compositor.ACCompositor;
import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.ternary.CritOperator;
import org.scratch.main.dice.model.ternary.TernaryOperator;

public class SneakAttackRoll extends ProbabilityMapRoll {
	final List<AttackRoll> rolls;
	final AttackRoll sneakAttack;
	final int ac;

	protected SneakAttackRoll(String name, List<AttackRoll> rolls, AttackRoll sneakAttack, int ac) {
		super(name);
		this.rolls = Collections.unmodifiableList(new ArrayList<>(rolls));
		this.sneakAttack = sneakAttack;
		this.ac = ac;
	}

	@Override
	public Outcome roll(Random engine) {
		int firstHit = -1;
		int totalDamage = 0;
		Compositor compositor = new ACCompositor(new Outcome(ac));
		TernaryOperator operator = CritOperator.instance;
		for (AttackRoll roll : rolls) {
			Outcome result = roll.attack.roll(engine);
			Outcome damageRoll = roll.damage.roll(engine);
			Outcome critRoll = roll.crit.roll(engine);
			Outcome damage = operator.test(result) ? damageRoll : critRoll;
			totalDamage += compositor.composite(result, damage).value;
			if (result.compareTo(new Outcome(ac)) >= 0 && firstHit == -1) {
				firstHit = result.special;
			}
		}
		Outcome damage = sneakAttack.damage.roll(engine);
		Outcome crit = sneakAttack.crit.roll(engine);
		if (firstHit == 0) {
			totalDamage += damage.value;
		} else if (firstHit == 1) {
			totalDamage += crit.value;
		}
		return new Outcome(totalDamage);
	}

}
