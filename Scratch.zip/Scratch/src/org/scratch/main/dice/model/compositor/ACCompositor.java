package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class ACCompositor implements Compositor {
	public final Outcome ac;

	public ACCompositor(Outcome ac) {
		this.ac = ac;
	}

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		if (roll1.compareTo(ac) >= 0)
			return roll2;
		else
			return new Outcome();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (getClass().equals(o.getClass()))
			return ac == ((ACCompositor) o).ac;
		else
			return false;
	}

	@Override
	public int hashCode() {
		return ac.hashCode();
	}
}
