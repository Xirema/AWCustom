package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class Accumulator implements Compositor {
	private Accumulator() {
	}

	public static final Accumulator instance = new Accumulator();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		return new Outcome(roll1.value + roll2.value, roll1.special + roll2.special);
	}
}
