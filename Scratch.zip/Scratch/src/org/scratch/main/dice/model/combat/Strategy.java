package org.scratch.main.dice.model.combat;

public interface Strategy {

}
