package org.scratch.main.dice.model.ternary;

import org.scratch.main.dice.model.Outcome;

public class CritOperator implements TernaryOperator {
	private CritOperator() {
	}

	public static final CritOperator instance = new CritOperator();

	// @Override
	// public DieFace operate(DieFace condition, DieFace ifTrue, DieFace
	// ifFalse) {
	// if(test(condition))
	// return ifTrue;
	// else
	// return ifFalse;
	// }

	@Override
	public boolean test(Outcome condition) {
		return condition.special <= 0;
	}

}
