package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.scratch.main.util.BigRational;

public abstract class ProbabilityMapRoll implements Rollable {
	protected TreeMap<Outcome, BigInteger> probabilityMap = new TreeMap<>();
	protected BigInteger denormalOdds = BigInteger.ZERO;
	public final String name;

	protected ProbabilityMapRoll(String name) {
		this.name = name;
	}

	protected void calcDenormal() {
		denormalOdds = BigInteger.ZERO;
		for (Outcome outcome : probabilityMap.keySet()) {
			denormalOdds = denormalOdds.add(probabilityMap.get(outcome));
		}
	}

	@Override
	public BigInteger denormalOdds() {
		return denormalOdds;
	}

	@Override
	public BigInteger denormalOdds(Outcome outcome) {
		BigInteger ret = probabilityMap.get(outcome);
		if (ret != null)
			return ret;
		else
			return BigInteger.ZERO;
	}

	@Override
	public BigRational oddsLessThan(Outcome outcome) {
		Map<Outcome, BigInteger> map = probabilityMap.headMap(outcome);
		BigInteger total = BigInteger.ZERO;
		for (Map.Entry<Outcome, BigInteger> entry : map.entrySet()) {
			total = total.add(entry.getValue());
		}
		return new BigRational(total, denormalOdds());
	}

	@Override
	public BigRational oddsLessEqualThan(Outcome outcome) {
		Map<Outcome, BigInteger> map = probabilityMap.headMap(outcome, true);
		BigInteger total = BigInteger.ZERO;
		for (Map.Entry<Outcome, BigInteger> entry : map.entrySet()) {
			total = total.add(entry.getValue());
		}
		return new BigRational(total, denormalOdds());
	}

	@Override
	public BigRational oddsGreaterThan(Outcome outcome) {
		Map<Outcome, BigInteger> map = probabilityMap.tailMap(outcome, false);
		BigInteger total = BigInteger.ZERO;
		for (Map.Entry<Outcome, BigInteger> entry : map.entrySet()) {
			total = total.add(entry.getValue());
		}
		return new BigRational(total, denormalOdds());
	}

	@Override
	public BigRational oddsGreaterEqualThan(Outcome outcome) {
		Map<Outcome, BigInteger> map = probabilityMap.tailMap(outcome, true);
		BigInteger total = BigInteger.ZERO;
		for (Map.Entry<Outcome, BigInteger> entry : map.entrySet()) {
			total = total.add(entry.getValue());
		}
		return new BigRational(total, denormalOdds());
	}

	@Override
	public int numOfUniqueOutcomes() {
		return probabilityMap.size();
	}

	// @Override
	// public BigRational oddsOfOutcome(Outcome outcome) {
	// BigRational odds = probabilityMap.get(outcome);
	// if(odds != null)
	// return odds;
	// else
	// return BigRational.ZERO;
	// }

	@Override
	public boolean hasOutcome(Outcome outcome) {
		return probabilityMap.containsKey(outcome);
	}

	@Override
	public Outcome[] outcomes() {
		Outcome[] ret = new Outcome[probabilityMap.size()];
		int index = 0;
		for (Map.Entry<Outcome, BigInteger> entry : probabilityMap.entrySet()) {
			ret[index++] = entry.getKey();
		}
		Arrays.sort(ret);
		return ret;
	}

	@Override
	public Iterator<Outcome> outcomeIterator() {
		return probabilityMap.keySet().iterator();
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public Outcome highestOutcome() {
		return probabilityMap.lastKey();
	}

	@Override
	public Outcome lowestOutcome() {
		return probabilityMap.firstKey();
	}
}
