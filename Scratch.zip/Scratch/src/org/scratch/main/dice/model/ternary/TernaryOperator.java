package org.scratch.main.dice.model.ternary;

import org.scratch.main.dice.model.Outcome;

public interface TernaryOperator {
	// DieFace operate(DieFace condition, DieFace ifTrue, DieFace ifFalse);
	boolean test(Outcome condition);
}
