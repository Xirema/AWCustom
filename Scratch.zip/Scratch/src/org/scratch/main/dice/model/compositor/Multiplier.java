package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class Multiplier implements Compositor {
	private Multiplier() {
	}

	public static final Multiplier instance = new Multiplier();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		return new Outcome(roll1.value * roll2.value, roll1.special * roll2.special);
	}
}
