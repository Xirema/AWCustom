package org.scratch.main.dice.model;

import java.util.Objects;
import java.util.function.Predicate;

import org.scratch.main.dice.model.RollFactory.Advantage;
import org.scratch.main.dice.model.compositor.AdvantageCompositor;
import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.compositor.DisadvantageCompositor;
import org.scratch.main.dice.model.transformer.Divider;
import org.scratch.main.dice.model.transformer.Negator;
import org.scratch.main.dice.model.transformer.Transformer;
import java.util.Optional;

public class RollBuilder {
	private static final Rollable mod0 = new Modifier(0);

	public enum FilterType {
		EQUAL_TO, NOT_EQUAL_TO, LESS_THAN, LESS_EQUAL_TO, GREATER_THAN, GREATER_EQUAL_TO
	}

	public static class Filter {
		public Outcome face;
		public FilterType type;

		// public boolean flatten;
		public Filter() {
			this(new Outcome(), FilterType.EQUAL_TO);
		}

		public Filter(int face, FilterType type) {
			this(new Outcome(face), type);
		}

		public Filter(Outcome face, FilterType type) {
			this.face = face;
			this.type = type;
		}
		// public Filter(int face, FilterType type, boolean flatten) {this(new
		// DieFace(face), type, flatten);}
		// public Filter(DieFace face, FilterType type, boolean flatten) {
		// this.face = face;
		// this.type = type;
		// this.flatten = flatten;
		// }
	}

	public final RollFactory factory;
	Rollable roll;
	// private boolean isMod0;

	public RollBuilder(RollFactory factory) {
		this(factory, mod0, true);
	}

	public RollBuilder(RollFactory factory, Rollable roll) {
		this(factory, roll, false);
	}

	private RollBuilder(RollFactory factory, Rollable roll, boolean isMod0) {
		this.factory = factory;
		this.roll = roll;
		// this.isMod0 = isMod0;
	}

	public RollBuilder withBless() {
		return factory.addBless(roll);
	}

	public RollBuilder combineWith(Rollable... rolls) {
		Rollable[] newRolls = new Rollable[rolls.length + 1];
		newRolls[0] = roll;
		System.arraycopy(rolls, 0, newRolls, 1, rolls.length);
		return factory.getCombined(newRolls);
	}

	public RollBuilder combineWith(RollBuilder... rolls) {
		Rollable[] newRolls = new Rollable[rolls.length + 1];
		newRolls[0] = roll;
		int index = 0;
		for (RollBuilder builder : rolls) {
			newRolls[++index] = builder.roll;
		}
		return factory.getCombined(newRolls);
	}

	public RollBuilder compose(Rollable other, Compositor compositor) {
		return factory.getCompositeRoll(roll, other, compositor);
	}

	public RollBuilder compose(RollBuilder other, Compositor compositor) {
		return factory.getCompositeRoll(roll, other.getRoll(), compositor);
	}

	public RollBuilder add(Rollable roll) {
		return combineWith(roll);
	}

	public RollBuilder add(RollBuilder roll) {
		return combineWith(roll);
	}

	public RollBuilder add(int modifier) {
		return combineWith(new Modifier(modifier));
	}

	public RollBuilder addDie(int size) {
		return combineWith(new RegularDie(size));
	}

	public RollBuilder subtract(Rollable roll) {
		return combineWith(factory.getTransformed(roll, Negator.instance));
	}

	public RollBuilder subtract(RollBuilder roll) {
		return subtract(roll.roll);
	}

	public RollBuilder subtract(int modifier) {
		return add(-modifier);
	}

	public RollBuilder subtractDie(int size) {
		return combineWith(factory.getDiePlusMod(size, 0).negate().getRoll());
	}

	public RollBuilder advantage() {
		return factory.getCompositeRoll(roll.getName() + "^", roll, roll, AdvantageCompositor.instance);
	}

	public RollBuilder disadvantage() {
		return factory.getCompositeRoll(roll.getName() + "v", roll, roll, DisadvantageCompositor.instance);
	}

	public RollBuilder middleOfThree() {
		return factory.getRoll3TakeMid(roll);
	}

	public RollBuilder advantage(Advantage advantageType) {
		switch (advantageType) {
		case NONE:
			return this;
		case ADVANTAGE:
			return advantage();
		case DISADVANTAGE:
			return disadvantage();
		case DOUBLE_ADVANTAGE:
			return factory.getCompositeRoll(roll.getName() + "A", advantage().roll, roll, AdvantageCompositor.instance);
		case HALF_ADVANTAGE:
			return factory.getCompositeRoll(roll.getName() + "/^", disadvantage().roll, roll,
					AdvantageCompositor.instance);
		case HALF_DISADVANTAGE:
			return factory.getCompositeRoll(roll.getName() + "/v", advantage().roll, roll,
					DisadvantageCompositor.instance);
		case MIDDLE_OF_3:
			return middleOfThree();
		default:
			throw new NullPointerException();
		}
	}

	private static class FilterTransformer implements Transformer {
		Predicate<Outcome> pred;

		FilterTransformer(Predicate<Outcome> pred) {
			this.pred = pred;
		}

		@Override
		public Outcome transform(Outcome roll) {
			if (pred.test(roll))
				return roll;
			else
				return new Outcome();
		}

		@Override
		public int hashCode() {
			return Objects.hash(pred);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass())) {
				FilterTransformer fp = (FilterTransformer) o;
				return pred.equals(fp.pred);
			} else
				return false;
		}
	}

	private static class FilterFlattenTransformer implements Transformer {
		Predicate<Outcome> pred;

		FilterFlattenTransformer(Predicate<Outcome> pred) {
			this.pred = pred;
		}

		@Override
		public Outcome transform(Outcome roll) {
			if (pred.test(roll))
				return new Outcome(1);
			else
				return new Outcome();
		}

		@Override
		public int hashCode() {
			return Objects.hash(pred);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass())) {
				FilterFlattenTransformer fp = (FilterFlattenTransformer) o;
				return pred.equals(fp.pred);
			} else
				return false;
		}
	}

	public RollBuilder filter(Predicate<Outcome> predicate) {
		return transform(new FilterTransformer(predicate));
	}

	public RollBuilder filterAndFlatten(Predicate<Outcome> predicate) {
		return transform(new FilterFlattenTransformer(predicate));
	}

	private static class FilterPredicate implements Predicate<Outcome> {
		Outcome face;
		FilterType type;

		FilterPredicate(Outcome face, FilterType type) {
			this.face = face;
			this.type = type;
		}

		@Override
		public boolean test(Outcome object) {
			switch (type) {
			case EQUAL_TO:
				return object.compareTo(face) == 0;
			case NOT_EQUAL_TO:
				return object.compareTo(face) != 0;
			case LESS_THAN:
				return object.compareTo(face) < 0;
			case GREATER_THAN:
				return object.compareTo(face) > 0;
			case LESS_EQUAL_TO:
				return object.compareTo(face) <= 0;
			case GREATER_EQUAL_TO:
				return object.compareTo(face) >= 0;
			default:
				throw new NullPointerException("`FilterType` must not be null.");
			}
		}

		@Override
		public int hashCode() {
			return Objects.hash(face, type);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass())) {
				FilterPredicate fp = (FilterPredicate) o;
				return face.equals(fp.face) && type.equals(fp.type);
			} else
				return false;
		}
	}

	public RollBuilder filter(Filter filter) {
		return filter(new FilterPredicate(filter.face, filter.type));
	}

	public RollBuilder filterAndFlatten(Filter filter) {
		return filterAndFlatten(new FilterPredicate(filter.face, filter.type));
	}

	private static class FlattenTransformer implements Transformer {
		private static final FlattenTransformer instance = new FlattenTransformer();

		@Override
		public Outcome transform(Outcome roll) {
			if (roll.compareTo(new Outcome()) == 0)
				return new Outcome();
			else
				return new Outcome(1);
		}
	}

	public RollBuilder flatten() {
		return transform(FlattenTransformer.instance);
	}

	public RollBuilder filter(int face, FilterType filterType) {
		return filter(new Filter(face, filterType));
	}

	public RollBuilder filterAndFlatten(int face, FilterType filterType) {
		return filterAndFlatten(new Filter(face, filterType));
	}

	public RollBuilder repeat(int num) {
		return factory.getRepeated(roll, num);
	}

	public RollBuilder transform(Transformer transformer) {
		return factory.getTransformed(roll, transformer);
	}

	public RollBuilder negate() {
		return factory.getNegatedRoll(roll);
	}

	public RollBuilder multiply(int factor) {
		return factory.getMultipliedRoll(roll, factor);
	}
	
	public RollBuilder divide(int factor) {
		return transform(new Divider(factor));
	}

	public RollBuilder rename(String name) {
		return factory.renameRoll(roll, name);
	}

	public Rollable getRoll() {
		return roll;
	}

	private static class Clamper implements Transformer {
		private final Optional<Integer> low, high;

		public Clamper(Optional<Integer> low, Optional<Integer> high) {
			this.low = low;
			this.high = high;
		}

		@Override
		public Outcome transform(Outcome roll) {
			int value = roll.value;
			if (value < low.orElse(Integer.MIN_VALUE)) {
				value = low.orElse(Integer.MIN_VALUE);
			} else if (value > high.orElse(Integer.MAX_VALUE)) {
				value = high.orElse(Integer.MAX_VALUE);
			}
			return new Outcome(value, roll.special);
		}

		@Override
		public int hashCode() {
			return Objects.hash(low, high);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass())) {
				Clamper c = (Clamper) o;
				return low.equals(c.low) && high.equals(c.high);
			} else
				return false;
		}
	}

	public RollBuilder clamp(Optional<Integer> low, Optional<Integer> high) {
		return transform(new Clamper(low, high));
	}

	public RollBuilder clamp(int value, FilterType type) {
		switch (type) {
		case EQUAL_TO:
			return transform(new Clamper(Optional.of(value), Optional.of(value)));
		case LESS_THAN:
			return transform(new Clamper(Optional.ofNullable((Integer) null), Optional.of(value - 1)));
		case GREATER_THAN:
			return transform(new Clamper(Optional.of(value + 1), Optional.ofNullable((Integer) null)));
		case LESS_EQUAL_TO:
			return transform(new Clamper(Optional.ofNullable((Integer) null), Optional.of(value)));
		case GREATER_EQUAL_TO:
			return transform(new Clamper(Optional.of(value), Optional.ofNullable((Integer) null)));
		default:
			throw new RuntimeException("Unsupported FilterType.");
		}
	}
}
