package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Renamer implements Transformer {
	@Override
	public Outcome transform(Outcome roll) {
		return roll;
	}

	@Override
	public boolean equals(Object o) {
		return super.equals(o);
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}
}
