package org.scratch.main.dice.model.transformer;

import java.util.Objects;

import org.scratch.main.dice.model.Outcome;

public class Threshold implements Transformer {
	public final Outcome threshold;

	public Threshold(Outcome threshold) {
		this.threshold = threshold;
	}

	public Threshold(int threshold) {
		this.threshold = new Outcome(threshold);
	}

	@Override
	public Outcome transform(Outcome roll) {
		if (roll.compareTo(threshold) >= 0)
			return roll;
		else
			return new Outcome();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Threshold))
			return false;
		Threshold t = (Threshold) o;
		return t.threshold.equals(threshold);
	}

	@Override
	public int hashCode() {
		return Objects.hash(threshold);
	}
}
