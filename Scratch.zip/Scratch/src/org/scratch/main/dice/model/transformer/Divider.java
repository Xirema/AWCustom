package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Divider implements Transformer {
	public final int factor;

	public Divider(int factor) {
		this.factor = factor;
	}

	@Override
	public Outcome transform(Outcome roll) {
		return new Outcome(roll.value / factor, roll.special / factor);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Divider))
			return false;
		Divider t = (Divider) o;
		return t.factor == factor;
	}

	@Override
	public int hashCode() {
		return factor;
	}
}
