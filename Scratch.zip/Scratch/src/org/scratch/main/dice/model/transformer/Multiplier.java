package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Multiplier implements Transformer {
	public final int factor;

	public Multiplier(int factor) {
		this.factor = factor;
	}

	@Override
	public Outcome transform(Outcome roll) {
		return new Outcome(roll.value * factor, roll.special * factor);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Multiplier))
			return false;
		Multiplier t = (Multiplier) o;
		return t.factor == factor;
	}

	@Override
	public int hashCode() {
		return factor;
	}
}
