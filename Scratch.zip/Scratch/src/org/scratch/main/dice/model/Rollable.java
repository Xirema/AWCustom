package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Random;

import org.scratch.main.util.BigRational;

public interface Rollable {
	Outcome roll(Random engine);

	BigInteger denormalOdds();

	BigInteger denormalOdds(Outcome outcome);

	boolean hasOutcome(Outcome outcome);

	Outcome[] outcomes();

	Iterator<Outcome> outcomeIterator();

	String getName();

	default BigRational oddsLessThan(Outcome outcome) {
		BigInteger currentOdds = BigInteger.ZERO;
		for (Iterator<Outcome> it = outcomeIterator(); it.hasNext();) {
			Outcome o = it.next();
			if (o.compareTo(outcome) >= 0)
				return new BigRational(currentOdds, denormalOdds());
			currentOdds = currentOdds.add(denormalOdds(o));
		}
		return BigRational.ONE;
	}

	default BigRational oddsLessEqualThan(Outcome outcome) {
		BigInteger currentOdds = BigInteger.ZERO;
		for (Iterator<Outcome> it = outcomeIterator(); it.hasNext();) {
			Outcome o = it.next();
			if (o.compareTo(outcome) > 0)
				return new BigRational(currentOdds, denormalOdds());
			currentOdds = currentOdds.add(denormalOdds(o));
		}
		return BigRational.ONE;
	}

	default BigRational oddsGreaterThan(Outcome outcome) {
		BigInteger currentOdds = BigInteger.ZERO;
		for (Iterator<Outcome> it = outcomeIterator(); it.hasNext();) {
			Outcome o = it.next();
			if (o.compareTo(outcome) > 0)
				return BigRational.ONE.minus(new BigRational(currentOdds, denormalOdds()));
			currentOdds = currentOdds.add(denormalOdds(o));
		}
		return BigRational.ZERO;
	}

	default BigRational oddsGreaterEqualThan(Outcome outcome) {
		BigInteger currentOdds = BigInteger.ZERO;
		for (Iterator<Outcome> it = outcomeIterator(); it.hasNext();) {
			Outcome o = it.next();
			if (o.compareTo(outcome) >= 0)
				return BigRational.ONE.minus(new BigRational(currentOdds, denormalOdds()));
			currentOdds = currentOdds.add(denormalOdds(o));
		}
		return BigRational.ZERO;
	}

	default BigRational oddsOfOutcome(Outcome outcome) {
		return new BigRational(denormalOdds(outcome), denormalOdds());
	}

	default BigRational oddsOfPassingDC(Outcome dc) {
		return oddsGreaterEqualThan(dc);
	}

	default BigRational oddsOfFailingDC(Outcome dc) {
		return oddsLessThan(dc);
	}

	default boolean equivalentTo(Rollable o) {
		if (!median().equals(o.median()))
			return false;
		if (!highestOutcome().equals(o.highestOutcome()))
			return false;
		if (!lowestOutcome().equals(o.lowestOutcome()))
			return false;
		// if(!numOfTrials().equals(o.numOfTrials()))
		// return false;
		if (!Arrays.equals(outcomes(), o.outcomes()))
			return false;
		for (Outcome outcome : outcomes()) {
			if (oddsOfOutcome(outcome).compareTo(o.oddsOfOutcome(outcome)) != 0)
				return false;
		}
		return true;
	}

	default Outcome highestOutcome() {
		Outcome[] outcomes = outcomes();
		return outcomes[outcomes.length - 1];
	}

	default Outcome lowestOutcome() {
		return outcomes()[0];
	}

	default BigRational mean() {
		BigRational sum = BigRational.ZERO;
		for (Outcome outcome : outcomes()) {
			sum = sum.plus(new BigRational(outcome.value).times(oddsOfOutcome(outcome)));
		}
		return sum;
	}

	default Outcome median() {
		return percentile(0.5);
	}

	default Outcome percentile(double percent) {
		BigRational trials = BigRational.ZERO;
		// BigInteger totalTrials = numOfTrials();
		for (Outcome outcome : outcomes()) {
			BigRational outcomeTrials = oddsOfOutcome(outcome);
			trials = trials.plus(outcomeTrials);
			double percentile = trials.doubleValue();
			if (Double.isNaN(percentile))
				return new Outcome();
			if (percentile >= percent)
				return outcome;
		}
		return new Outcome(0, -1);
	}

	default int numOfUniqueOutcomes() {
		return outcomes().length;
	}

	default Outcome[] outcomesLessThan(Outcome outcome) {
		Outcome[] all = outcomes();
		int index = Arrays.binarySearch(all, outcome);
		if (index >= 0)
			return Arrays.copyOfRange(all, 0, index);
		else
			return Arrays.copyOfRange(all, 0, Math.abs(index + 1));
	}

	default Outcome[] outcomesLessEqualThan(Outcome outcome) {
		Outcome[] all = outcomes();
		int index = Arrays.binarySearch(all, outcome);
		if (index >= 0)
			return Arrays.copyOfRange(all, 0, index + 1);
		else
			return Arrays.copyOfRange(all, 0, Math.abs(index + 1));
	}

	default Outcome[] outcomesGreaterThan(Outcome outcome) {
		Outcome[] all = outcomes();
		int index = Arrays.binarySearch(all, outcome);
		if (index >= 0)
			return Arrays.copyOfRange(all, index + 1, all.length);
		else
			return Arrays.copyOfRange(all, Math.abs(index + 1), all.length);
	}

	default Outcome[] outcomesGreaterEqualThan(Outcome outcome) {
		Outcome[] all = outcomes();
		int index = Arrays.binarySearch(all, outcome);
		if (index >= 0)
			return Arrays.copyOfRange(all, index, all.length);
		else
			return Arrays.copyOfRange(all, Math.abs(index + 1), all.length);
	}

	// String decomposedForm();
}
