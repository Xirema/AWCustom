package org.scratch.main.dice.model.transformer;

import java.util.Objects;

import org.scratch.main.dice.model.Outcome;
import java.util.Optional;

public class Clamper implements Transformer {
	public final Optional<Integer> minimum, maximum;
	private static final Optional<Integer> empty = Optional.empty();

	private Clamper(int minimum) {
		this(Optional.of(minimum), empty);
	}

	private Clamper(int maximum, boolean _ignored) {
		this(empty, Optional.of(maximum));
	}

	public Clamper(Optional<Integer> minimum, Optional<Integer> maximum) {
		this.minimum = minimum;
		this.maximum = maximum;
	}

	public Clamper(int minimum, int maximum) {
		this(Optional.of(minimum), Optional.of(maximum));
	}

	public static Clamper withMinimum(int minimum) {
		return new Clamper(minimum);
	}

	public static Clamper withMaximum(int maximum) {
		return new Clamper(maximum, false);
	}

	@Override
	public Outcome transform(Outcome roll) {
		if (minimum.isPresent() && roll.value < minimum.get())
			return new Outcome(minimum.get());
		if (maximum.isPresent() && roll.value > maximum.get())
			return new Outcome(maximum.get());
		return roll;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Clamper))
			return false;
		Clamper t = (Clamper) o;
		return t.minimum.equals(minimum) && t.maximum.equals(maximum);
	}

	@Override
	public int hashCode() {
		return Objects.hash(minimum, maximum);
	}

}
