package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class AdvantageCompositor implements Compositor {
	private AdvantageCompositor() {
	}

	public static final AdvantageCompositor instance = new AdvantageCompositor();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		if (roll1.compareTo(roll2) > 0)
			return roll1;
		else
			return roll2;
	}
}
