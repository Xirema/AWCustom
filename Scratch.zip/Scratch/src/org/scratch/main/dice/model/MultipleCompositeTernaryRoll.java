package org.scratch.main.dice.model;

import java.util.Objects;
import java.util.Random;

import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.ternary.TernaryOperator;

public class MultipleCompositeTernaryRoll extends ProbabilityMapRoll {
	MultipleCompositeTernaryRoll(String name, Rollable conditionRoll, Rollable trueRoll, Rollable falseRoll,
			Compositor compositor, TernaryOperator operator) {
		super(name);
		this.conditionRoll = conditionRoll;
		this.trueRoll = trueRoll;
		this.falseRoll = falseRoll;
		this.compositor = compositor;
		this.operator = operator;
	}

	public final Rollable conditionRoll;
	public final Rollable trueRoll, falseRoll;
	public final Compositor compositor;
	public final TernaryOperator operator;

	@Override
	public Outcome roll(Random engine) {
		Outcome condition = conditionRoll.roll(engine);
		Outcome roll1 = trueRoll.roll(engine);
		Outcome roll2 = falseRoll.roll(engine);

		Outcome outcome = operator.test(condition) ? roll1 : roll2;
		Outcome result = compositor.composite(condition, outcome);
		return result;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof CompositeTernaryRoll))
			return false;
		CompositeTernaryRoll r = (CompositeTernaryRoll) o;
		return conditionRoll.equals(r.conditionRoll) && trueRoll.equals(r.trueRoll) && falseRoll.equals(r.falseRoll)
				&& operator.equals(r.operator) && compositor.equals(r.compositor);
	}

	@Override
	public int hashCode() {
		return Objects.hash(conditionRoll, trueRoll, falseRoll, operator, compositor);
	}

}
