package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.function.Predicate;

import org.scratch.main.dice.model.RollBuilder.FilterType;
import org.scratch.main.dice.model.compositor.ACCompositor;
import org.scratch.main.dice.model.compositor.Accumulator;
import org.scratch.main.dice.model.compositor.AdvantageCompositor;
import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.compositor.DisadvantageCompositor;
import org.scratch.main.dice.model.compositor.GWFCompositor;
import org.scratch.main.dice.model.compositor.WildMagicCompositor;
import org.scratch.main.dice.model.ternary.BinaryOperator;
import org.scratch.main.dice.model.ternary.CritOperator;
import org.scratch.main.dice.model.ternary.TernaryOperator;
import org.scratch.main.dice.model.transformer.Flipper;
import org.scratch.main.dice.model.transformer.Multiplier;
import org.scratch.main.dice.model.transformer.Negator;
import org.scratch.main.dice.model.transformer.Renamer;
import org.scratch.main.dice.model.transformer.Transformer;
import org.scratch.main.dice.model.transformer.ValueTransformer;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.ListAlgorithms;
import java.util.Optional;

public class RollFactory {
	private Map<ProbabilityMapRoll, ProbabilityMapRoll> canonRolls = new HashMap<>();

	public RollFactory() {
	}

	public enum Advantage {
		NONE, ADVANTAGE, DISADVANTAGE, DOUBLE_ADVANTAGE, HALF_ADVANTAGE, HALF_DISADVANTAGE, MIDDLE_OF_3
	}

	private RollBuilder builderFor(Rollable roll) {
		return new RollBuilder(this, roll);
	}

	public RollBuilder getWildMagicRoll(int numOfDice, int sizeOfDice) {
		RegularDie[] dice = new RegularDie[numOfDice];
		Arrays.fill(dice, new RegularDie(sizeOfDice));
		return getWildMagicRoll(dice);
	}

	private static class WMCompositor implements Compositor {
		private WMCompositor() {
		}

		public static final WMCompositor instance = new WMCompositor();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			return new Outcome(roll1.value + roll2.value,
					roll1.special > roll2.special ? roll1.special : roll2.special);
		}
	}

	private static class WMCompositor2 implements Compositor {
		private final int size;

		public WMCompositor2(int size) {
			this.size = size;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (this.getClass().equals(o.getClass()))
				return ((WMCompositor2) o).size == size;
			else
				return false;
		}

		@Override
		public int hashCode() {
			return Objects.hashCode(size);
		}

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			if (roll1.special == size)
				return new Outcome(roll1.value + roll2.value, 0);
			else
				return new Outcome(roll1.value + roll2.value, roll1.special);
		}
	}

	private static class WMTernary implements TernaryOperator {
		private final int size;

		public WMTernary(int size) {
			this.size = size;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (this.getClass().equals(o.getClass()))
				return ((WMTernary) o).size == size;
			else
				return false;
		}

		@Override
		public int hashCode() {
			return Objects.hashCode(size);
		}
		// @Override
		// public DieFace operate(DieFace condition, DieFace ifTrue,
		// DieFace ifFalse) {
		// if(test(condition))
		// return ifTrue;
		// else
		// return ifFalse;
		// }

		@Override
		public boolean test(Outcome condition) {
			return condition.special == size;
		}

	}

	private static class WMTransformer implements Transformer {
		private final Outcome max;

		public WMTransformer(Outcome max) {
			this.max = max;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (this.getClass().equals(o.getClass()))
				return ((WMTransformer) o).max.equals(max);
			else
				return false;
		}

		@Override
		public int hashCode() {
			return Objects.hashCode(max);
		}

		@Override
		public Outcome transform(Outcome roll) {
			if (roll.equals(max))
				return new Outcome(roll.value, max.value);
			else
				return roll;
		}
	}

	public RollBuilder getWildMagicRoll(RegularDie... dice) {
		Rollable roll = assembleTransformer(dice[0], new WMTransformer(dice[0].highestOutcome()));
		String name = "WILD[";
		for (RegularDie die : dice) {
			name += die.getName() + ",";
		}
		name = name.substring(0, name.length() - 1) + "]";
		Set<RegularDie> dieVarieties = new HashSet<>();
		dieVarieties.add(dice[0]);
		for (int i = 1; i < dice.length; i++) {
			Rollable transformed = assembleTransformer(dice[i], new WMTransformer(dice[i].highestOutcome()));
			dieVarieties.add(dice[i]);
			roll = assembleComposite(roll, transformed, WMCompositor.instance);
		}
		for (RegularDie die : dieVarieties) {
			roll = assembleCompositeTernary(new CompositeTernaryRoll(name, roll, die, StandardDice.mod0,
					new WMCompositor2(die.highestOutcome().value), new WMTernary(die.highestOutcome().value)));
		}
		return builderFor(roll);
	}

	public RollBuilder getCompositeRoll(Rollable first, Rollable second, Compositor compositor) {
		return getCompositeRoll(first.getName() + second.getName(), first, second, compositor);
	}

	public RollBuilder getCompositeRoll(String name, Rollable first, Rollable second, Compositor compositor) {
		return builderFor(assembleComposite(name, first, second, compositor));
	}

	public RollBuilder getDiePlusMod(int dieSize, int modifier) {
		if (modifier != 0)
			return builderFor(assembleComposite("1d" + dieSize + (modifier >= 0 ? "+" : "") + modifier,
					new RegularDie(dieSize), new Modifier(modifier), Accumulator.instance));
		else
			return builderFor(new RegularDie(dieSize));
	}

	public RollBuilder getXdYWildHomebrewRoll(int numOfDice, int sizeOfDice) {
		if (numOfDice > 1)
			return builderFor(assembleComposite(numOfDice + "d" + sizeOfDice + "WildHB",
					getXdYWildHomebrewRoll(numOfDice / 2, sizeOfDice).roll,
					getXdYWildHomebrewRoll(numOfDice - (numOfDice / 2), sizeOfDice).roll, Accumulator.instance));
		else if (numOfDice == 1)
			return builderFor(assembleComposite(numOfDice + "d" + sizeOfDice + "WildHB", new RegularDie(sizeOfDice),
					new RegularDie(sizeOfDice), new WildMagicCompositor(new Outcome(sizeOfDice))));
		else
			return builderFor(StandardDice.mod0);
	}

	public RollBuilder getXdYGWFRoll(int numOfDice, int sizeOfDice) {
		return getXdYGWFRoll(numOfDice, sizeOfDice, 2);
	}

	public RollBuilder getXdYGWFRoll(int numOfDice, int sizeOfDice, int threshold) {
		if (numOfDice > 1)
			return builderFor(assembleComposite(numOfDice + "d" + sizeOfDice + "GWF",
					getXdYGWFRoll(numOfDice / 2, sizeOfDice, threshold).roll,
					getXdYGWFRoll(numOfDice - (numOfDice / 2), sizeOfDice, threshold).roll, Accumulator.instance));
		else if (numOfDice == 1)
			return builderFor(assembleComposite(numOfDice + "d" + sizeOfDice + "GWF", new RegularDie(sizeOfDice),
					new RegularDie(sizeOfDice), new GWFCompositor(new Outcome(threshold))));
		else
			return builderFor(StandardDice.mod0);
	}

	public RollBuilder getXdYRoll(int numOfDice, int sizeOfDice) {
		if (numOfDice > 1)
			return builderFor(
					assembleComposite(numOfDice + "d" + sizeOfDice, getXdYRoll(numOfDice / 2, sizeOfDice).roll,
							getXdYRoll(numOfDice - (numOfDice / 2), sizeOfDice).roll, Accumulator.instance));
		else if (numOfDice == 1)
			return builderFor(new RegularDie(sizeOfDice));
		else
			return builderFor(StandardDice.mod0);
	}

	public RollBuilder getXdYRollDrop1(int numOfDice, int sizeOfDice) {
		Rollable initRoll = getXdYRollDrop1Impl(numOfDice, sizeOfDice);
		return builderFor(
				assembleTransformer(initRoll.getName() + " Drop 1", initRoll, XdYRollDrop1Transformer.instance));
	}

	public RollBuilder dropX(int numDropped, Rollable... rolls) {
		if (numDropped >= rolls.length || rolls.length == 0)
			return builderFor(StandardDice.mod0);
		Rollable roll = rolls[0];
		for (int i = 1; i < rolls.length; i++) {
			CompositeRoll newRoll = new CompositeRoll(roll.getName() + "+" + rolls[i].getName(), roll, rolls[i],
					DropXCompositor.instance);
			newRoll.probabilityMap = new TreeMap<>(new OutcomeDropXComparator());
			roll = assembleComposite(newRoll);
		}
		RollBuilder builder = builderFor(roll).transform(new DropXTransformer(numDropped));
		return builder.rename(builder.getRoll().getName() + "_Drop_" + numDropped);
	}

	public RollBuilder dropX(String name, int numDropped, Rollable... rolls) {
		if (numDropped >= rolls.length || rolls.length == 0)
			return builderFor(StandardDice.mod0);
		Rollable roll = rolls[0];
		for (int i = 1; i < rolls.length; i++) {
			CompositeRoll newRoll = new CompositeRoll(roll.getName() + "+" + rolls[i].getName(), roll, rolls[i],
					DropXCompositor.instance);
			newRoll.probabilityMap = new TreeMap<>(new OutcomeDropXComparator());
			roll = assembleComposite(newRoll);
		}
		RollBuilder builder = builderFor(roll).transform(new DropXTransformer(numDropped));
		return builder.rename(name + "_Drop_" + numDropped);
	}

	public RollBuilder getXdYRollDropX(int numOfDice, int sizeOfDice, int numDropped) {
		Rollable[] rolls = new Rollable[numOfDice];
		Arrays.fill(rolls, new RegularDie(sizeOfDice));
		return dropX(numOfDice + "d" + sizeOfDice, numDropped, rolls);
	}

	private static class OutcomeDropX extends Outcome {
		public final List<Outcome> lowest;

		public OutcomeDropX(int value, int special, List<Outcome> lowest) {
			super(value, special);
			this.lowest = Collections.unmodifiableList(new ArrayList<>(lowest));
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (!super.equals(o))
				return false;
			OutcomeDropX x = (OutcomeDropX) o;
			return lowest.equals(x.lowest);
		}

		@Override
		public int hashCode() {
			return Objects.hash(value, special, lowest);
		}
	}

	private static class OutcomeDropXComparator implements Comparator<Outcome> {
		private static final Comparator<List<Outcome>> listComparator = ListAlgorithms.getComparator(Outcome.class);

		@Override
		public int compare(Outcome o1, Outcome o2) {
			int diff = o1.compareTo(o2);
			if (diff != 0)
				return diff;
			boolean o1x = o1 instanceof OutcomeDropX;
			boolean o2x = o2 instanceof OutcomeDropX;
			OutcomeDropX x1 = o1x ? (OutcomeDropX) o1 : null;
			OutcomeDropX x2 = o2x ? (OutcomeDropX) o2 : null;
			if (o1x && o2x)
				return listComparator.compare(x1.lowest, x2.lowest);
			if (o1x && !o2x)
				return 1;
			if (!o1x && o2x)
				return -1;
			return 0;
		}
	}

	private static class DropXCompositor implements Compositor {
		private DropXCompositor() {
		}

		public static final DropXCompositor instance = new DropXCompositor();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			int value = roll1.value + roll2.value;
			List<Outcome> lowest = new ArrayList<>();
			if (roll1 instanceof OutcomeDropX) {
				lowest.addAll(((OutcomeDropX) roll1).lowest);
			} else {
				lowest.add(roll1);
			}
			lowest.add(roll2);
			Collections.sort(lowest);
			return new OutcomeDropX(value, 0, lowest);
		}
	}

	private static class DropXTransformer implements Transformer {
		public final int numDropped;

		public DropXTransformer(int numDropped) {
			this.numDropped = numDropped;
		}

		@Override
		public Outcome transform(Outcome roll) {
			OutcomeDropX x = (OutcomeDropX) roll;
			int value = roll.value;
			List<Outcome> lowest = x.lowest;
			// List<Outcome> lowest = new ArrayList<>(x.lowest);
			// Collections.sort(lowest);
			for (int i = 0; i < Math.min(numDropped, lowest.size()); i++) {
				value -= lowest.get(i).value;
			}
			return new Outcome(value);
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass()))
				return ((DropXTransformer) o).numDropped == numDropped;
			else
				return false;
		}
	}

	private Rollable getXdYRollDrop1Impl(int numOfDice, int sizeOfDice) {
		if (numOfDice > 1)
			return assembleComposite(numOfDice + "d" + sizeOfDice, getXdYRollDrop1Impl(numOfDice / 2, sizeOfDice),
					getXdYRollDrop1Impl(numOfDice - (numOfDice / 2), sizeOfDice), XdYRollDrop1Compositor.instance);
		else if (numOfDice == 1)
			return new RegularDie(sizeOfDice);
		else
			return StandardDice.mod0;
	}

	private static class XdYRollDrop1Compositor implements Compositor {
		private XdYRollDrop1Compositor() {
		}

		public static final XdYRollDrop1Compositor instance = new XdYRollDrop1Compositor();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			int value = roll1.value + roll2.value;
			int special1 = roll1.special != 0 ? roll1.special : roll1.value;
			int special2 = roll2.special != 0 ? roll2.special : roll2.value;
			return new Outcome(value, Math.min(special1, special2));
		}
	}

	private static class XdYRollDrop1Transformer implements Transformer {
		private XdYRollDrop1Transformer() {
		}

		public static final XdYRollDrop1Transformer instance = new XdYRollDrop1Transformer();

		@Override
		public Outcome transform(Outcome roll) {
			return new Outcome(roll.value - roll.special);
		}
	}

	public RollBuilder getRepeated(Rollable roll, int num) {
		if (num == 1)
			return builderFor(roll);
		if (num < 1)
			return builderFor(StandardDice.mod0);
		return getCombined("[" + roll.getName() + "]x" + num, getRepeated(roll, num / 2).getRoll(),
				getRepeated(roll, num - (num / 2)).getRoll());
		// Rollable[] rolls = new Rollable[num];
		// Arrays.fill(rolls, roll);
		// return getCombined("[" + roll.getName() + "]x" + num, rolls);
	}

	public RollBuilder truncateRoll(Rollable roll, Outcome... outcomes) {
		TreeMap<Outcome, BigInteger> probabilityMap = new TreeMap<>();
		Arrays.sort(outcomes);
		for (Outcome outcome : roll.outcomes()) {
			if (Arrays.binarySearch(outcomes, outcome) >= 0) {
				probabilityMap.put(outcome, roll.denormalOdds(outcome));
			}
		}

//		for (Outcome outcome : probabilityMap.keySet()) {
//			probabilityMap.put(outcome, probabilityMap.get(outcome));
//		}
		CustomDie ret = new CustomDie(roll.getName() + "T", probabilityMap);
		return builderFor(ret);
	}

	public RollBuilder truncateRoll(Rollable roll, Predicate<Outcome> predicate) {
		TreeMap<Outcome, BigInteger> probabilityMap = new TreeMap<>();
		for (Outcome outcome : roll.outcomes()) {
			if (predicate.test(outcome)) {
				probabilityMap.put(outcome, roll.denormalOdds(outcome));
			}
		}

//		for (Outcome outcome : probabilityMap.keySet()) {
//			probabilityMap.put(outcome, probabilityMap.get(outcome));
//		}
		CustomDie ret = new CustomDie(roll.getName() + "T", probabilityMap);
		return builderFor(ret);
	}

	public RollBuilder getCombined(String name, Rollable... rolls) {
		Rollable finalRoll = null;
		for (int i = 0; i < rolls.length; i++) {
			Rollable roll = rolls[i];
			if (finalRoll == null) {
				finalRoll = roll;
			} else {
				if (i == rolls.length - 1) {
					finalRoll = assembleComposite(name, finalRoll, roll, Accumulator.instance);
				} else {
					finalRoll = assembleComposite(finalRoll.getName() + "+" + roll.getName(), finalRoll, roll,
							Accumulator.instance);
				}
			}
		}
		return builderFor(finalRoll);
	}

	public RollBuilder getTransformed(Rollable roll, Transformer transformer) {
		return builderFor(assembleTransformer(roll, transformer));
	}

	public RollBuilder getNegatedRoll(Rollable roll) {
		return builderFor(assembleTransformer("-[" + roll.getName() + "]", roll, Negator.instance));
	}

	public RollBuilder getMultipliedRoll(Rollable roll, int factor) {
		return builderFor(assembleTransformer(factor + "x(" + roll.getName() + ")", roll, new Multiplier(factor)));
	}

	public RollBuilder getCombined(Rollable... rolls) {
		String name = "";
		for (int i = 0; i < rolls.length; i++) {
			Rollable roll = rolls[i];
			if (roll instanceof Modifier || i == 0) {
				name += roll.getName();
			} else {
				name += "+" + roll.getName();
			}
		}
		return getCombined(name, rolls);
	}

	public RollBuilder getAttackRoll(int modifier) {
		return getAttackRoll(modifier, Advantage.NONE);
	}

	public RollBuilder getAttackRoll(int modifier, Advantage advantage) {
		return getAttackRoll(modifier, advantage, 0);
	}

	public RollBuilder getAttackRoll(int modifier, Advantage advantage, int critRangeExpansion) {
		RollBuilder roll = builderFor(StandardDice.superiorAttackDie(critRangeExpansion));
		roll = roll.advantage(advantage);
		if (modifier != 0) {
			roll = roll.add(modifier);
		}
		return roll;
	}

	public RollBuilder getD20Roll(int modifier) {
		return getD20Roll(modifier, Advantage.NONE);
	}

	public RollBuilder getD20Roll(int modifier, Advantage advantage) {
		RollBuilder roll = builderFor(StandardDice.D20);
		roll = roll.advantage(advantage);
		if (modifier != 0) {
			roll = roll.add(modifier);
		}
		return roll;
	}

	public RollBuilder addBless(Rollable roll) {
		return builderFor(assembleComposite(roll.getName() + "+1d4", roll, new RegularDie(4), Accumulator.instance));
	}

	public RollBuilder getTernaryRoll(String name, Rollable condition, Rollable ifTrue, Rollable ifFalse,
			TernaryOperator operator) {
		return builderFor(assembleTernary(new TernaryRoll(name, condition, ifTrue, ifFalse, operator)));
	}

	public RollBuilder getCompositeTernaryRoll(String name, Rollable condition, Rollable ifTrue, Rollable ifFalse,
			TernaryOperator operator, Compositor compositor) {
		return builderFor(assembleCompositeTernary(
				new CompositeTernaryRoll(name, condition, ifTrue, ifFalse, compositor, operator)));
	}

	public RollBuilder getCritRoll(int attackMod, Rollable normalDamage, Rollable critDamage) {
		return getTernaryRoll("Crit Roll", StandardDice.ATTACK_DIE, normalDamage, critDamage, CritOperator.instance);
	}

	public RollBuilder getDamageRollVsAC(String name, Rollable attackRoll, Rollable normalDamage, Rollable critDamage,
			int ac) {
		return getCompositeTernaryRoll(name, attackRoll, normalDamage, critDamage, CritOperator.instance,
				new ACCompositor(new Outcome(ac)));
	}

	public RollBuilder getDamageRollVsAC(String name, int attackMod, Rollable normalDamage, Rollable critDamage,
			int ac) {
		return getDamageRollVsAC(name, getCombined(StandardDice.ATTACK_DIE, new Modifier(attackMod)).roll, normalDamage,
				critDamage, ac);
	}

	public RollBuilder getMultiAttackVsAC(String name, List<AttackRoll> attacks, int ac) {
		if (attacks.size() == 0)
			return builderFor(StandardDice.mod0);
		RollBuilder builder = getDamageRollVsAC(attacks.get(0).attack.getName(), attacks.get(0), ac);
		for (int i = 1; i < attacks.size(); i++) {
			builder = builder.add(getDamageRollVsAC(attacks.get(i).attack.getName(), attacks.get(i), ac));
		}
		return builder.rename(name);
	}

	private static class SneakACCompositor extends ACCompositor {
		public SneakACCompositor(Outcome ac) {
			super(ac);
		}

		@Override
		public Outcome composite(Outcome a, Outcome b) {
			if (a.compareTo(ac) >= 0)
				return new Outcome(b.value, a.special);
			else
				return new Outcome(0, -1);
		}
	}

	private Rollable asRoll(AttackRoll attack, int ac) {
		// DEBUG_RollCheck(attack.attack);
		// DEBUG_RollCheck(attack.damage);
		// DEBUG_RollCheck(attack.crit);
		return getCompositeTernaryRoll(attack.attack.getName(), attack.attack, attack.damage, attack.crit,
				CritOperator.instance, new SneakACCompositor(new Outcome(ac))).getRoll();
	}

	private static class SneakAccumulator implements Compositor {
		static final SneakAccumulator instance = new SneakAccumulator();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			Outcome ret = new Outcome(roll1.value + roll2.value);
			if (roll1.special == -1)
				return new Outcome(ret.value, roll2.special);
			else
				return new Outcome(ret.value, roll1.special);
		}
	}

	private static class SneakAccumulatorB implements Compositor {
		static final SneakAccumulatorB instance = new SneakAccumulatorB();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			return new Outcome(roll1.value + roll2.value, Math.max(roll1.special, roll2.special));
		}
	}

	private static class SneakAccumulatorC implements Compositor {
		static final SneakAccumulatorC instance = new SneakAccumulatorC();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			boolean firstHitCrit = 
				roll1.special == -1 && roll2.special == 1 ||
				(roll1.special % 10) == 1;
			boolean bestHitCrit = firstHitCrit || roll2.special == 1 || roll1.special / 10 == 1;
			int special;
			if(firstHitCrit)
				special = 11;
			else if(bestHitCrit)
				special = 10;
			else
				special = Math.max(roll1.special, roll2.special);
			return new Outcome(roll1.value + roll2.value, special);
		}
	}

	private static class SneakAccumulator2 implements Compositor {
		static final SneakAccumulator2 instance = new SneakAccumulator2();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			if (roll1.special == -1)
				return new Outcome(roll1.value);
			else
				return new Outcome(roll1.value + roll2.value);
		}
	}

	private static class SneakAccumulator3 implements Compositor {
		static final SneakAccumulator3 instance = new SneakAccumulator3();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			if (roll1.special == -1)
				return new Outcome(roll1.value, roll1.special);
			else
				return new Outcome(roll1.value + roll2.value, roll1.special);
		}
	}
	private static class SneakTernary2 implements TernaryOperator {
		static final SneakTernary2 instance = new SneakTernary2();
		@Override
		public boolean test(Outcome condition) {
			return !(condition.special != -1 && condition.special % 10 == 1);
		}
	}
	private static class SneakTernary3 implements TernaryOperator {
		static final SneakTernary3 instance = new SneakTernary3();
		@Override
		public boolean test(Outcome condition) {
			return !(condition.special != -1 && (condition.special / 10 == 1 || condition.special % 10 == 1));
		}
	}

	public RollBuilder getSneakAttackVsAC(String name, List<AttackRoll> attacks, AttackRoll sneakAttack, int ac) {
		return getSneakAttackVsAC(name, attacks, sneakAttack, ac, true);
	}

	public RollBuilder getSneakAttackVsAC(String name, List<AttackRoll> attacks, AttackRoll sneakAttack, int ac,
			boolean onlyFirstHitForCrit) {
		Rollable roll = asRoll(attacks.get(0), ac);
		Compositor compositor;
		if (onlyFirstHitForCrit) {
			compositor = SneakAccumulator.instance;
		} else {
			compositor = SneakAccumulatorB.instance;
		}
		for (int i = 1; i < attacks.size(); i++) {
			roll = getCompositeRoll(roll, asRoll(attacks.get(i), ac), compositor).getRoll();
		}
		RollBuilder ret = getCompositeTernaryRoll(name, roll, sneakAttack.damage, sneakAttack.crit,
				CritOperator.instance, SneakAccumulator2.instance);
		return ret;
	}

	public RollBuilder getSneakAttackVsAC(String name, List<AttackRoll> attacks, AttackRoll firstHitSneak, AttackRoll bestHitSneak, int ac) {
		Rollable roll = asRoll(attacks.get(0), ac);
//		DEBUG_RollCheck(roll);
		Compositor compositor = SneakAccumulatorC.instance;
		for (int i = 1; i < attacks.size(); i++) {
			roll = getCompositeRoll(roll, asRoll(attacks.get(i), ac), compositor).getRoll();
//			DEBUG_RollCheck(roll);
		}
		roll = getCompositeTernaryRoll(name, roll, firstHitSneak.damage, firstHitSneak.crit, 
			SneakTernary2.instance, SneakAccumulator3.instance).getRoll();
//		DEBUG_RollCheck(roll);
		roll = getCompositeTernaryRoll(name, roll, bestHitSneak.damage, bestHitSneak.crit, 
			SneakTernary3.instance, SneakAccumulator2.instance).getRoll();
//		DEBUG_RollCheck(roll);
		return builderFor(roll);
	}

	private static class Mid3Step1 implements Compositor {
		private Mid3Step1() {
		}

		private static final Mid3Step1 instance = new Mid3Step1();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			return new Outcome(roll1.value, roll2.value);
		}
	}

	private static class Mid3Step2 implements Compositor {
		private Mid3Step2() {
		}

		private static final Mid3Step2 instance = new Mid3Step2();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			List<Integer> values = Arrays.asList(roll1.value, roll1.special, roll2.value);
			Collections.sort(values);
			return new Outcome(values.get(1));
		}
	}

	public RollBuilder getRoll3TakeMid(Rollable roll) {
		return builderFor(
				assembleComposite("^" + roll.getName() + "v",
						assembleComposite(roll, roll, Mid3Step1.instance), roll, Mid3Step2.instance));
	}

	public RollBuilder getRoll3TakeMid(Rollable first, Rollable second, Rollable third) {
		return builderFor(
				assembleComposite("[v" + first.getName() + "^" + second.getName() + "v" + third.getName() + "^]",
						assembleComposite(first, second, Mid3Step1.instance), third, Mid3Step2.instance));
	}

//	public RollBuilder createAverageOutcomeRoll(double mean) {
//		double originalMean = mean;
//		int level = 0;
//		while (Math.round(mean) != mean && mean < Integer.MAX_VALUE / 10) {
//			mean *= 10;
//			level++;
//		}
//		//throw new UnsupportedOperationException("Unimplemented!");
//		TreeMap<Outcome, BigInteger> outcomes = new TreeMap<>();
//		outcomes.put(new Outcome((int)mean), BigInteger.ONE);
//		outcomes.put(new Outcome(), BigInteger.valueOf(10).pow(level).subtract(BigInteger.ONE));
//		return builderFor(new CustomDie("Average: " + originalMean,
//				outcomes));
//	}
	
	public SavingThrow getBasicSavingThrow(int dc, int numOfDice, int sizeOfDice, boolean halfOnSave) {
		return new SavingThrow(
			dc,
			getXdYRoll(numOfDice, sizeOfDice).getRoll(),
			halfOnSave ? getXdYRoll(numOfDice, sizeOfDice).divide(2).getRoll() : StandardDice.mod0
		);
	}
	
	public SavingThrow getBasicSavingThrow(int dc, int numOfDice, int sizeOfDice) {
		return getBasicSavingThrow(dc, numOfDice, sizeOfDice, true);
	}
	
	public RollBuilder getSavingThrowDamageRoll(String name, int saveModifier, SavingThrow savingThrow) {
		Rollable roll = getD20Roll(saveModifier)
				.subtract(savingThrow.dc)
				.filterAndFlatten(0, FilterType.LESS_THAN)
				.getRoll();
		return getTernaryRoll(
			name,
			roll,
			savingThrow.damageOnSuccess,
			savingThrow.damageOnFail,
			BinaryOperator.instance
		);
	}

	public RollBuilder createAverageOutcomeRoll(double mean) {
		double frac = Math.abs(mean) - (int)Math.abs(mean);
		int level = 0;
		while(frac != Math.round(frac)) {
			frac *= 10;
			level++;
		}
		BigInteger whole = BigInteger.valueOf(10).pow(level);
		//throw new UnsupportedOperationException("Unimplemented!");
		TreeMap<Outcome, BigInteger> outcomes = new TreeMap<>();
		outcomes.put(new Outcome((int)mean), whole.subtract(BigInteger.valueOf((long)frac)));
		if(mean < 0) 
			outcomes.put(new Outcome((int)mean - 1), BigInteger.valueOf((long)frac));
		else
			outcomes.put(new Outcome((int)mean + 1), BigInteger.valueOf((long)frac));
		return builderFor(new CustomDie("Average: " + mean,
				outcomes));
	}

	public RollBuilder getTimeToDownRoll(int initialHealth, Rollable roll) {
		return getTimeToDownRoll(initialHealth, roll, 5000);
	}

	private static class TimeToDownSubtractor implements Compositor {
		private TimeToDownSubtractor() {
		}

		public static final TimeToDownSubtractor instance = new TimeToDownSubtractor();

		@Override
		public Outcome composite(Outcome roll1, Outcome roll2) {
			if (roll1.special > 0)
				return roll1;
			int value = roll1.value - roll2.value;
			int special;
			if (value < 0) {
				special = 1;
				value = 0;
			} else {
				special = 0;
			}
			if (special == 1)
				return new Outcome(value, Math.abs(roll1.special) + 1);
			else
				return new Outcome(value, roll1.special - 1);
		}
	}

	private static class TimeToDownTransformer implements Transformer {
		// private final int maxRounds;
		// public TimeToDownTransformer(int maxRounds) {
		// this.maxRounds = maxRounds;
		// }
		private TimeToDownTransformer() {
		}

		public static final TimeToDownTransformer instance = new TimeToDownTransformer();

		// @Override
		// public Outcome transform(Outcome roll) {
		// if(roll.special < maxRounds)
		// return new Outcome(roll.special);
		// else
		// return new Outcome(roll.special, 1);
		// }
		// public int hashCode() {
		// return maxRounds;
		// }
		//
		// public boolean equals(Object o) {
		// if(this == o)
		// return true;
		// if(this.getClass().equals(o.getClass())) {
		// return maxRounds == ((TimeToDownTransformer)o).maxRounds;
		// } else
		// return false;
		// }
		@Override
		public Outcome transform(Outcome roll) {
			if (roll.special < 0)
				return new Outcome(Math.abs(roll.special) + 1, 1);
			else
				return new Outcome(roll.special);
		}
	}

	public RollBuilder getTimeToDownRoll(int initialHealth, Rollable roll, int maxRounds) {
		Rollable initialRoll = new Modifier(initialHealth);
		RollBuilder combined = builderFor(initialRoll);
		// System.out.println("Testing for " + roll.getName());
		for (int i = 0; i < maxRounds; i++) {
			// System.out.println(" Index " + i);
			combined = combined.compose(roll, TimeToDownSubtractor.instance);
			ProbabilityMapRoll probMapRoll = (ProbabilityMapRoll) combined.getRoll();
			BigRational failingOdds = probMapRoll.oddsOfFailingDC(new Outcome());
			BigRational succeedingOdds = probMapRoll.oddsOfPassingDC(new Outcome());
			// DEBUG_MapCheck("", probMapRoll.probabilityMap);
			if (failingOdds.compareTo(new BigRational(1, 10000)) <= 0 && failingOdds.compareTo(succeedingOdds) < 0) {
				break;
			}
		}
		// combined = combined.transform(new TimeToDownTransformer(maxRounds));
		combined = combined.transform(TimeToDownTransformer.instance);
		combined = combined.rename("Time to Down " + initialHealth + " vs " + roll.getName());
		// System.out.println();
		return combined;
	}

	public static class AttackOptions {
		public boolean greatWeaponFighting = false;
		public int extraCritDice = 0;
		public int critRangeExpansion = 0;

		public void setCritRangeFromChampionLevel(int level) {
			if (level < 3) {
				critRangeExpansion = 0;
			} else if (level < 15) {
				critRangeExpansion = 1;
			} else {
				critRangeExpansion = 2;
			}
		}
	}

	public AttackRoll getSimpleSneakAttack(int numOfDice, int sizeOfDice) {
		return new AttackRoll(getXdYRoll(numOfDice, sizeOfDice), getXdYRoll(numOfDice * 2, sizeOfDice));
	}

	public AttackRoll getSimpleSneakAttack(int numOfDice) {
		return getSimpleSneakAttack(numOfDice, 6);
	}

	public AttackRoll getSimpleAttackRoll(int attackMod, int numOfDamageDice, int sizeOfDamageDice, int damageMod,
			Advantage advantage, AttackOptions options) {
		RollBuilder attackRoll = getAttackRoll(attackMod, advantage, options.critRangeExpansion);

		RollBuilder damageRoll;
		if (options.greatWeaponFighting) {
			damageRoll = getXdYGWFRoll(numOfDamageDice, sizeOfDamageDice);
		} else {
			damageRoll = getXdYRoll(numOfDamageDice, sizeOfDamageDice);
		}
		damageRoll = damageRoll.add(damageMod);
		damageRoll = damageRoll.clamp(0, FilterType.GREATER_EQUAL_TO);

		int numOfCritDice = numOfDamageDice * 2 + options.extraCritDice;
		RollBuilder critRoll;
		if (options.greatWeaponFighting) {
			critRoll = getXdYGWFRoll(numOfCritDice, sizeOfDamageDice);
		} else {
			critRoll = getXdYRoll(numOfCritDice, sizeOfDamageDice);
		}
		critRoll = critRoll.add(damageMod);
		critRoll = critRoll.clamp(0, FilterType.GREATER_EQUAL_TO);
		return new AttackRoll(attackRoll, damageRoll, critRoll);
	}

	public AttackRoll getSimpleAttackRoll(int attackMod, int numOfDamageDice, int sizeOfDamageDice, int damageMod) {
		return getSimpleAttackRoll(attackMod, numOfDamageDice, sizeOfDamageDice, damageMod, Advantage.NONE);
	}

	public AttackRoll getSimpleAttackRoll(int attackMod, int numOfDamageDice, int sizeOfDamageDice, int damageMod,
			Advantage advantage) {
		return getSimpleAttackRoll(attackMod, numOfDamageDice, sizeOfDamageDice, damageMod, advantage,
				new AttackOptions());
	}

	private static class DdYOperator implements TernaryOperator {
		int value;

		public DdYOperator(int value) {
			this.value = value;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o)
				return true;
			if (getClass().equals(o.getClass()))
				return ((DdYOperator) o).value == value;
			else
				return false;
		}

		@Override
		public int hashCode() {
			return value;
		}

		@Override
		public boolean test(Outcome condition) {
			return condition.special == value;
		}
	}

	public RollBuilder getDdYRoll(Rollable count, int die) {
		return getDdYRoll(count, new RegularDie(die));
	}

	public RollBuilder getDdYRoll(Rollable count, RegularDie die) {
		RollBuilder ret = builderFor(count).transform(Flipper.INSTANCE);
		Iterator<Outcome> iterator = ret.getRoll().outcomeIterator();
		while (iterator.hasNext()) {
			final Outcome outcome = iterator.next();
			Rollable next = getXdYRoll(outcome.special, die.maximumValue).getRoll();
			ret = getCompositeTernaryRoll(outcome.special + "d(" + die.getName() + ")", ret.getRoll(), next,
					StandardDice.mod0, new DdYOperator(outcome.special), Accumulator.instance);
			// DEBUG_RollCheck(ret.getRoll());
		}
		ret = ret.transform(ValueTransformer.instance);
		ret = ret.rename("(" + count.getName() + ")" + die.getName());
		return ret;
	}

	public RollBuilder getdXdYRoll(int x, int y) {
		return getDdYRoll(new RegularDie(x), new RegularDie(y));
	}
	
	public RollBuilder getHigherOf(Rollable first, Rollable second) {
		return build(assembleComposite(
				"max(" + first.getName() + "," + second.getName() + ")",
				first,
				second,
				AdvantageCompositor.instance
			));
	}
	
	public RollBuilder getLowerOf(Rollable first, Rollable second) {
		return build(assembleComposite(
				"min(" + first.getName() + "," + second.getName() + ")",
				first,
				second,
				DisadvantageCompositor.instance
			));
	}

	public RollBuilder build(Rollable roll) {
		return builderFor(roll);
	}

	private ProbabilityMapRoll assembleTransformer(Rollable roll, Transformer transformer) {
		return assembleTransformer(roll.getName(), roll, transformer);
	}

	private ProbabilityMapRoll assembleTransformer(String name, Rollable roll, Transformer transformer) {
		return assembleTransformer(new TransformingRoll(name, roll, transformer));
	}

	private ProbabilityMapRoll assembleTransformer(TransformingRoll roll) {
		ProbabilityMapRoll canon = canonRolls.get(roll);
		if (canon != null) {
			roll = (TransformingRoll) canon;
			// System.err.println("Canonical Die found for " + roll.getName());
		} else {
			Map<Outcome, BigInteger> outcomes = roll.probabilityMap;
			for (Outcome roll1 : roll.original.outcomes()) {
				BigInteger odds = roll.original.denormalOdds(roll1);
				Outcome transformedRoll = roll.transformer.transform(roll1);
				BigInteger old = outcomes.get(transformedRoll);
				if (old == null) {
					old = BigInteger.ZERO;
				}
				old = old.add(odds);
				outcomes.put(transformedRoll, old);
			}
			roll.calcDenormal();
			canonRolls.put(roll, roll);
		}
		return roll;
	}

	private ProbabilityMapRoll assembleComposite(Rollable firstRoll, Rollable secondRoll, Compositor compositor) {
		return assembleComposite(new CompositeRoll(firstRoll, secondRoll, compositor));
	}

	private ProbabilityMapRoll assembleComposite(String name, Rollable firstRoll, Rollable secondRoll,
			Compositor compositor) {
		return assembleComposite(new CompositeRoll(name, firstRoll, secondRoll, compositor));
	}

	private ProbabilityMapRoll assembleComposite(CompositeRoll roll) {
		ProbabilityMapRoll canon = canonRolls.get(roll);
		if (canon != null) {
			roll = (CompositeRoll) canon;
			// System.err.println("Canonical Die found for " + roll.getName());
		} else {
			Map<Outcome, BigInteger> outcomes = roll.probabilityMap;
			for (Outcome roll1 : roll.firstRoll.outcomes()) {
				for (Outcome roll2 : roll.secondRoll.outcomes()) {
					BigInteger total = roll.firstRoll.denormalOdds(roll1).multiply(roll.secondRoll.denormalOdds(roll2));
					Outcome compositeRoll = roll.compositor.composite(roll1, roll2);
					BigInteger old = outcomes.get(compositeRoll);
					if (old == null) {
						old = BigInteger.ZERO;
					}
					old = old.add(total);
					outcomes.put(compositeRoll, old);
				}
			}
			roll.calcDenormal();
			canonRolls.put(roll, roll);
		}
		return roll;
	}

	private ProbabilityMapRoll assembleTernary(TernaryRoll roll) {
		ProbabilityMapRoll canon = canonRolls.get(roll);
		if (canon != null) {
			roll = (TernaryRoll) canon;
		} else {
			Map<Outcome, BigRational> tempProbabilityMap = new HashMap<>();
			for (Outcome condition : roll.conditionRoll.outcomes()) {
				boolean result = roll.operator.test(condition);
				BigRational conditionOdds = roll.conditionRoll.oddsOfOutcome(condition);
				Rollable second;
				if (result) {
					second = roll.trueRoll;
				} else {
					second = roll.falseRoll;
				}
				for (Outcome outcome : second.outcomes()) {
					BigRational outcomeOdds = second.oddsOfOutcome(outcome);
					BigRational old = tempProbabilityMap.get(outcome);
					if (old == null) {
						old = BigRational.ZERO;
					}
					old = old.plus(outcomeOdds.times(conditionOdds));
					tempProbabilityMap.put(outcome, old);
				}
			}
			BigInteger lcd = BigInteger.ONE;
			for (BigRational rational : tempProbabilityMap.values()) {
				lcd = lcd.multiply(rational.den.divide(lcd.gcd(rational.den)));
			}
			for (Map.Entry<Outcome, BigRational> entry : tempProbabilityMap.entrySet()) {
				BigInteger denorm = entry.getValue().times(new BigRational(lcd, BigInteger.ONE)).num;
				roll.probabilityMap.put(entry.getKey(), denorm);
			}
			// roll.probabilityMap = new TreeMap<>(tempProbabilityMap);
			roll.calcDenormal();
			canonRolls.put(roll, roll);
		}
		return roll;
	}

	private ProbabilityMapRoll assembleCompositeTernary(CompositeTernaryRoll roll) {
		ProbabilityMapRoll canon = canonRolls.get(roll);
		if (canon != null) {
			roll = (CompositeTernaryRoll) canon;
		} else {
			Map<Outcome, BigRational> tempProbabilityMap = new HashMap<>();
			for (Outcome condition : roll.conditionRoll.outcomes()) {
				boolean result = roll.operator.test(condition);
				BigRational conditionOdds = roll.conditionRoll.oddsOfOutcome(condition);
				Rollable second;
				if (result) {
					second = roll.trueRoll;
				} else {
					second = roll.falseRoll;
				}
				for (Outcome outcome : second.outcomes()) {
					Outcome compositedOutcome = roll.compositor.composite(condition, outcome);
					BigRational outcomeOdds = second.oddsOfOutcome(outcome);
					BigRational old = tempProbabilityMap.get(compositedOutcome);
					if (old == null) {
						old = BigRational.ZERO;
					}
					old = old.plus(outcomeOdds.times(conditionOdds));
					tempProbabilityMap.put(compositedOutcome, old);
				}
			}
			BigInteger lcd = BigInteger.ONE;
			for (BigRational rational : tempProbabilityMap.values()) {
				lcd = lcd.multiply(rational.den.divide(lcd.gcd(rational.den)));
			}
			for (Map.Entry<Outcome, BigRational> entry : tempProbabilityMap.entrySet()) {
				BigInteger denorm = entry.getValue().times(new BigRational(lcd, BigInteger.ONE)).num;
				roll.probabilityMap.put(entry.getKey(), denorm);
			}
			// roll.probabilityMap = new TreeMap<>(tempProbabilityMap);
			roll.calcDenormal();
			canonRolls.put(roll, roll);
		}
		return roll;
	}

	@SuppressWarnings({ "unused" })
	private void DEBUG_MapCheck(String name, Map<?, ?> map) {
		System.err.println("Testing \"" + name + "\"");
		for (Map.Entry<?, ?> entry : map.entrySet()) {
			Outcome face = (Outcome) entry.getKey();
			System.err.println("[" + face.value + "," + face.special + "]=" + entry.getValue());
		}
	}

	@SuppressWarnings({ "unused" })
	private void DEBUG_RollCheck(Rollable roll) {
		System.err.println("Testing \"" + roll.getName() + "\": " + roll.mean());
		Map<Integer, BigRational> specials = new TreeMap<>();
		for (Outcome face : roll.outcomes()) {
			System.err.println("[" + face.value + "," + face.special + "]=" + roll.oddsOfOutcome(face) + " ("
					+ roll.oddsOfOutcome(face).doubleValue() * 100 + "%)");
			specials.put(face.special, Optional.ofNullable(specials.get(face.special)).orElse(BigRational.ZERO)
					.plus(roll.oddsOfOutcome(face)));
		}
		System.err.println("Special odds:");
		for (Map.Entry<Integer, BigRational> entry : specials.entrySet()) {
			System.err.println(
					entry.getKey() + ": " + entry.getValue() + " (" + entry.getValue().doubleValue() * 100 + "%)");
		}
	}

	public RollBuilder getDamageRollVsAC(String name, AttackRoll attack, int ac) {
		return getDamageRollVsAC(name, attack.attack, attack.damage, attack.crit, ac);
	}

	public RollBuilder renameRoll(Rollable roll, String name) {
		return builderFor(assembleTransformer(name, roll, new Renamer()));
	}
}
