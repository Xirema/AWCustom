package org.scratch.main.dice.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class WildMagicRoll extends ProbabilityMapRoll {
	public final List<RegularDie> dice;

	WildMagicRoll(RegularDie... dice) {
		this(Arrays.asList(dice));
	}

	WildMagicRoll(List<RegularDie> dice) {
		this(dice, true);
	}

	private static String constructName(List<RegularDie> dice) {
		StringBuilder ss = new StringBuilder();
		ss.append("WILD[");
		for (int i = 0; i < dice.size(); i++) {
			ss.append(dice.get(i).getName());
			if (i != dice.size() - 1) {
				ss.append(',');
			}
		}
		ss.append("]");
		return ss.toString();
	}

	private WildMagicRoll(List<RegularDie> dice, boolean makeCopy) {
		super(constructName(dice));
		if (makeCopy) {
			dice = new ArrayList<>(dice);
		}
		Collections.sort(dice, (o1, o2) -> o1.mean().compareTo(o2.mean()));
		this.dice = Collections.unmodifiableList(dice);
	}

	@Override
	public Outcome roll(Random engine) {
		Outcome total = new Outcome(0);
		RegularDie biggestDie = null;
		for (RegularDie die : dice) {
			Outcome roll = die.roll(engine);
			// total += roll;
			total = new Outcome(total.value + roll.value, total.special + roll.special);
			if (roll.equals(die.highestOutcome())) {
				if (biggestDie == null || biggestDie.mean().compareTo(die.mean()) < 0) {
					biggestDie = die;
				}
			}
		}
		if (biggestDie != null) {
			Outcome roll = biggestDie.roll(engine);
			total = new Outcome(total.value + roll.value, total.special + roll.special);
		}
		return total;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof WildMagicRoll))
			return false;
		WildMagicRoll r = (WildMagicRoll) o;
		return r.dice.equals(dice);
	}

	@Override
	public int hashCode() {
		return Objects.hash(dice.toArray());
	}
}
