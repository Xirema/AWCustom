package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class Subtractor implements Compositor {
	private Subtractor() {
	}

	public static final Subtractor instance = new Subtractor();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		return new Outcome(roll1.value - roll2.value, roll1.special - roll2.special);
	}

}
