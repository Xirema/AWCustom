package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public class DisadvantageCompositor implements Compositor {
	private DisadvantageCompositor() {
	}

	public static final DisadvantageCompositor instance = new DisadvantageCompositor();

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		if (roll1.compareTo(roll2) < 0)
			return roll1;
		else
			return roll2;
	}
}
