package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

import org.scratch.main.util.BigRational;

public class Modifier implements Rollable {
	public final int modifier;

	public Modifier() {
		this(0);
	}

	public Modifier(int modifier) {
		this.modifier = modifier;
	}

	@Override
	public Outcome roll(Random engine) {
		return new Outcome(modifier, 0);
	}

	@Override
	public int numOfUniqueOutcomes() {
		return 1;
	}

	@Override
	public BigInteger denormalOdds() {
		return BigInteger.ONE;
	}

	@Override
	public BigInteger denormalOdds(Outcome outcome) {
		if (hasOutcome(outcome))
			return BigInteger.ONE;
		else
			return BigInteger.ZERO;
	}

	@Override
	public boolean hasOutcome(Outcome outcome) {
		return outcome.value == modifier;
	}

	@Override
	public Outcome[] outcomes() {
		return new Outcome[] { new Outcome(modifier) };
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof Modifier))
			return false;
		return ((Modifier) o).modifier == modifier;
	}

	@Override
	public int hashCode() {
		return modifier;
	}

	@Override
	public String getName() {
		if (modifier >= 0)
			return "+" + modifier;
		else
			return "" + modifier;
	}

	@Override
	public BigRational oddsLessThan(Outcome outcome) {
		return BigRational.valueOf(outcome.value > modifier ? 1 : 0);
	}

	@Override
	public BigRational oddsLessEqualThan(Outcome outcome) {
		return BigRational.valueOf(outcome.value >= modifier ? 1 : 0);
	}

	@Override
	public BigRational oddsGreaterThan(Outcome outcome) {
		return BigRational.valueOf(outcome.value < modifier ? 1 : 0);
	}

	@Override
	public BigRational oddsGreaterEqualThan(Outcome outcome) {
		return BigRational.valueOf(outcome.value <= modifier ? 1 : 0);
	}

	@Override
	public BigRational mean() {
		return new BigRational(modifier);
	}

	@Override
	public Outcome highestOutcome() {
		return new Outcome(modifier);
	}

	@Override
	public Outcome lowestOutcome() {
		return new Outcome(modifier);
	}

	@Override
	public Outcome median() {
		return new Outcome(modifier);
	}

	@Override
	public Outcome percentile(double percent) {
		return new Outcome(modifier);
	}

	@Override
	public Iterator<Outcome> outcomeIterator() {
		return Collections.singleton(new Outcome(modifier)).iterator();
	}
}
