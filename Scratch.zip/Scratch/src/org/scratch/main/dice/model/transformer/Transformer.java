package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public interface Transformer {
	Outcome transform(Outcome roll);
}
