package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Counter implements Transformer {
	public final Outcome canon;

	public Counter(Outcome canon) {
		this.canon = canon;
	}

	@Override
	public Outcome transform(Outcome roll) {
		if (roll.equals(canon))
			return new Outcome(1);
		else
			return new Outcome();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Counter))
			return false;
		Counter t = (Counter) o;
		return t.canon.equals(canon);
	}

	@Override
	public int hashCode() {
		return canon.hashCode();
	}
}
