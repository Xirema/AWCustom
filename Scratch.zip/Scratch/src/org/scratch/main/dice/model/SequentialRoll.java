package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class SequentialRoll implements Rollable {
	List<RegularDie> dice;

	public SequentialRoll(List<RegularDie> dice) {
		this.dice = Collections.unmodifiableList(new ArrayList<>(dice));
	}

	@Override
	public Outcome roll(Random engine) {
		int count = 1;
		for (RegularDie die : dice) {
			int local = 0;
			for (int i = 0; i < count; i++) {
				local += die.roll(engine).value;
			}
			count = local;
		}
		return new Outcome(count);
	}

	@Override
	public BigInteger denormalOdds() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BigInteger denormalOdds(Outcome outcome) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean hasOutcome(Outcome outcome) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Outcome[] outcomes() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterator<Outcome> outcomeIterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
