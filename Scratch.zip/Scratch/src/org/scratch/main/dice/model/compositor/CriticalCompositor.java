package org.scratch.main.dice.model.compositor;

import java.util.Objects;

import org.scratch.main.dice.model.Outcome;

public class CriticalCompositor implements Compositor {
	public final Outcome reqToPass;
	public final boolean advDisadv;

	public CriticalCompositor(Outcome reqToPass, boolean advDisadv) {
		this.reqToPass = reqToPass;
		this.advDisadv = advDisadv;
	}

	public CriticalCompositor(Outcome reqToPass) {
		this(reqToPass, true);
	}

	public CriticalCompositor(int reqToPass) {
		this(reqToPass, true);
	}

	public CriticalCompositor(int reqToPass, boolean advDisadv) {
		this(new Outcome(reqToPass), advDisadv);
	}

	@Override
	public Outcome composite(Outcome roll1, Outcome roll2) {
		int value, special;
		if (advDisadv) {
			value = Math.max(roll1.value, roll2.value);
		} else {
			value = Math.min(roll1.value, roll2.value);
		}
		if (advDisadv && value == 20 && roll1.compareTo(reqToPass) >= 0 && roll2.compareTo(reqToPass) >= 0) {
			special = 1;
		} else if (!advDisadv && value == 1 && roll1.compareTo(reqToPass) < 0 && roll2.compareTo(reqToPass) < 0) {
			special = -1;
		} else {
			special = 0;
		}
		return new Outcome(value, special);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (getClass().equals(o.getClass()))
			return reqToPass == ((CriticalCompositor) o).reqToPass && advDisadv == ((CriticalCompositor) o).advDisadv;
		else
			return false;
	}

	@Override
	public int hashCode() {
		return Objects.hash(reqToPass, advDisadv);
	}
}
