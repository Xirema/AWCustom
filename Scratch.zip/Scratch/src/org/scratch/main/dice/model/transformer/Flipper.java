package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Flipper implements Transformer {
	private Flipper() {
	}

	public static final Flipper INSTANCE = new Flipper();

	@Override
	public Outcome transform(Outcome roll) {
		return new Outcome(roll.special, roll.value);
	}
}
