package org.scratch.main.dice.model;

import java.util.Objects;
import java.util.Random;

import org.scratch.main.dice.model.transformer.Transformer;

public class TransformingRoll extends ProbabilityMapRoll {
	public final Rollable original;
	public final Transformer transformer;

	TransformingRoll(String name, Rollable original, Transformer transformer) {
		super(name);
		this.original = original;
		this.transformer = transformer;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof TransformingRoll))
			return false;
		TransformingRoll r = ((TransformingRoll) o);
		return r.original.equals(original) && r.transformer.equals(transformer);
	}

	@Override
	public int hashCode() {
		return Objects.hash(original, transformer);
	}

	@Override
	public Outcome roll(Random engine) {
		return transformer.transform(original.roll(engine));
	}
}
