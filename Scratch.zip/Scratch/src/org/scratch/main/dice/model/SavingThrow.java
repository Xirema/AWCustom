package org.scratch.main.dice.model;

import java.util.Arrays;
import java.util.List;

public class SavingThrow {
	public final int dc;
	public final Rollable damageOnSuccess, damageOnFail;
	
	public SavingThrow(int dc, Rollable damageOnSuccess, Rollable damageOnFail) {
		this.dc = dc;
		this.damageOnFail = damageOnFail;
		this.damageOnSuccess = damageOnSuccess;
	}

	public SavingThrow[] repeat(int num) {
		SavingThrow[] rolls = new SavingThrow[num];
		Arrays.fill(rolls, this);
		return rolls;
	}

	public List<SavingThrow> repeatList(int num) {
		return Arrays.asList(repeat(num));
	}
}
