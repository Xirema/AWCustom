package org.scratch.main.dice.model.combat;

public class Character {

}
