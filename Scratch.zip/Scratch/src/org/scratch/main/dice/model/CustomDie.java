package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

public class CustomDie extends ProbabilityMapRoll {
	public CustomDie() {
		this("Custom d6", fromNumbers(Arrays.asList(1, 2, 3, 4, 5, 6)), false);
	}

	private CustomDie(String name, List<Outcome> faces, boolean makeCopy) {
		super(name);
		probabilityMap = new TreeMap<>();
		for (Outcome face : faces) {
			BigInteger value = probabilityMap.get(face);
			denormalOdds = denormalOdds.add(BigInteger.ONE);
			if (value == null) {
				probabilityMap.put(face, BigInteger.ONE);
			} else {
				probabilityMap.put(face, value.add(BigInteger.ONE));
			}
		}
	}

	public CustomDie(String name, Map<Outcome, BigInteger> probabilityMap) {
		super(name);
		this.probabilityMap = new TreeMap<>(probabilityMap);
		calcDenormal();
	}

	private static List<Outcome> fromNumbers(List<Integer> nums) {
		List<Outcome> faces = new ArrayList<>();
		for (int num : nums) {
			faces.add(new Outcome(num));
		}
		return faces;
	}

	public CustomDie(String name, List<Outcome> faces) {
		this(name, faces, true);
	}

	public static CustomDie fromNums(String name, List<Integer> numbers) {
		return new CustomDie(name, fromNumbers(numbers));
	}

	@Override
	public Outcome roll(Random engine) {
		BigInteger val;
		do {
			val = new BigInteger(denormalOdds.bitCount(), engine);
		} while (val.compareTo(denormalOdds) >= 0);
		for (Outcome outcome : probabilityMap.keySet()) {
			if (val.compareTo(BigInteger.ZERO) <= 0)
				return outcome;
			val = val.subtract(probabilityMap.get(outcome));
		}

		return probabilityMap.lastEntry().getKey();
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof CustomDie))
			return false;
		return ((CustomDie) o).probabilityMap.equals(probabilityMap);
	}

	@Override
	public int hashCode() {
		return probabilityMap.hashCode();
	}
}
