package org.scratch.main.dice.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class StandardDice {
	private StandardDice() {
	}

	private static final RollFactory factory = new RollFactory();

	public static final Rollable mod0 = new Modifier(0);

	public static final RegularDie D4 = new RegularDie(4);
	public static final RegularDie D6 = new RegularDie(6);
	public static final RegularDie D8 = new RegularDie(8);
	public static final RegularDie D10 = new RegularDie(10);
	public static final RegularDie D12 = new RegularDie(12);
	public static final RegularDie D20 = new RegularDie(20);
	public static final RegularDie D100 = new RegularDie(100);
	public static final CustomDie ATTACK_DIE;
	static {
		List<Outcome> faces = new ArrayList<>();
		for (int i = 1; i <= 20; i++) {
			int special;
			if (i == 1) {
				special = -1;
			} else if (i == 20) {
				special = 1;
			} else {
				special = 0;
			}
			faces.add(new Outcome(i, special));
		}
		ATTACK_DIE = new CustomDie("Attack Die", faces);
	}

	public static CustomDie superiorAttackDie(int critRangeExpansion) {
		if (critRangeExpansion <= 0)
			return ATTACK_DIE;
		else {
			List<Outcome> faces = new ArrayList<>();
			for (int i = 1; i <= 20; i++) {
				int special;
				if (i == 1) {
					special = -1;
				} else if (i >= 20 - critRangeExpansion) {
					special = 1;
				} else {
					special = 0;
				}
				faces.add(new Outcome(i, special));
			}
			return new CustomDie("Attack Die (Crit " + (20 - critRangeExpansion) + "-20)", faces);
		}
	}

	public static final Rollable CATAN = factory.getXdYRoll(2, 6).getRoll();
	public static final Rollable BETRAYAL = factory.getDiePlusMod(3, -1).getRoll();

	public static final CustomDie SMP_MARIO = CustomDie.fromNums("SMP_Mario", Arrays.asList(1, 3, 3, 3, 5, 6));
	public static final CustomDie SMP_LUIGI = CustomDie.fromNums("SMP_Luigi", Arrays.asList(1, 1, 1, 5, 6, 7));
	public static final CustomDie SMP_PEACH = CustomDie.fromNums("SMP_Peach", Arrays.asList(0, 2, 4, 4, 4, 6));
	public static final CustomDie SMP_YOSHI = CustomDie.fromNums("SMP_Yoshi", Arrays.asList(0, 1, 3, 3, 5, 7));
	public static final CustomDie SMP_WARIO = CustomDie.fromNums("SMP_Wario", Arrays.asList(0, 0, 6, 6, 6, 6));
	public static final CustomDie SMP_DONKEY_KONG = CustomDie.fromNums("SMP_Donkey_Kong",
			Arrays.asList(0, 0, 0, 0, 10, 10));
	public static final CustomDie SMP_DAISY = CustomDie.fromNums("SMP_Daisy", Arrays.asList(3, 3, 3, 3, 4, 4));
	public static final CustomDie SMP_WALUIGI = CustomDie.fromNums("SMP_Waluigi", Arrays.asList(0, 1, 3, 5, 5, 7));
	public static final CustomDie SMP_BOO = CustomDie.fromNums("SMP_Boo", Arrays.asList(0, 0, 5, 5, 7, 7));
	public static final CustomDie SMP_DRY_BONES = CustomDie.fromNums("SMP_Dry_Bones", Arrays.asList(1, 1, 1, 6, 6, 6));
	public static final CustomDie SMP_HAMMER_BRO = CustomDie.fromNums("SMP_Hammer_Bro",
			Arrays.asList(0, 1, 1, 5, 5, 5));
	public static final CustomDie SMP_KOOPA = CustomDie.fromNums("SMP_Koopa", Arrays.asList(1, 1, 2, 3, 3, 10));
	public static final CustomDie SMP_SHY_GUY = CustomDie.fromNums("SMP_Shy_Guy", Arrays.asList(0, 4, 4, 4, 4, 4));
	public static final CustomDie SMP_ROSALINA = CustomDie.fromNums("SMP_Rosalina", Arrays.asList(0, 0, 2, 3, 4, 8));
	public static final CustomDie SMP_BOWSER_JR = CustomDie.fromNums("SMP_Bowser_Jr", Arrays.asList(1, 1, 1, 4, 4, 9));
	public static final CustomDie SMP_DIDDY_KONG = CustomDie.fromNums("SMP_Diddy_Kong",
			Arrays.asList(0, 0, 0, 7, 7, 7));
	public static final CustomDie SMP_BOWSER = CustomDie.fromNums("SMP_Bowser", Arrays.asList(0, 0, 1, 8, 9, 10));
	public static final CustomDie SMP_GOOMBA = CustomDie.fromNums("SMP_Goomba", Arrays.asList(0, 0, 3, 4, 5, 6));
	public static final CustomDie SMP_MONTY_MOLE = CustomDie.fromNums("SMP_Monty_Mole",
			Arrays.asList(0, 2, 3, 4, 5, 6));
	public static final CustomDie SMP_POM_POM = CustomDie.fromNums("SMP_Pom_Pom", Arrays.asList(0, 3, 3, 3, 3, 8));

	public static final List<CustomDie> SMP_DICE = Collections
			.unmodifiableList(Arrays.asList(CustomDie.fromNums("SMP_Regular", Arrays.asList(1, 2, 3, 4, 5, 6)),
					SMP_MARIO, SMP_LUIGI, SMP_PEACH, SMP_YOSHI, SMP_WARIO, SMP_DONKEY_KONG, SMP_DAISY, SMP_WALUIGI,
					SMP_BOO, SMP_DRY_BONES, SMP_HAMMER_BRO, SMP_KOOPA, SMP_SHY_GUY, SMP_ROSALINA, SMP_BOWSER_JR,
					SMP_DIDDY_KONG, SMP_BOWSER, SMP_GOOMBA, SMP_MONTY_MOLE, SMP_POM_POM));
}
