package org.scratch.main.dice.model.compositor;

import org.scratch.main.dice.model.Outcome;

public interface Compositor {
	Outcome composite(Outcome roll1, Outcome roll2);
}
