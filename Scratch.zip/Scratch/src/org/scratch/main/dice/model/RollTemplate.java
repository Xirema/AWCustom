package org.scratch.main.dice.model;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.scratch.main.dice.model.RollBuilder.Filter;
import org.scratch.main.dice.model.RollBuilder.FilterType;
import org.scratch.main.dice.model.RollFactory.Advantage;
import org.scratch.main.dice.model.transformer.Transformer;

public class RollTemplate {
	private static interface Template {
		RollBuilder apply(RollBuilder roll);
	}

	private List<Template> templates = new ArrayList<>();

	public RollBuilder apply(RollBuilder original) {
		for (Template template : templates) {
			original = template.apply(original);
		}
		return original;
	}

	private RollTemplate attach(Template effect) {
		RollTemplate newTemplate = new RollTemplate();
		newTemplate.templates.addAll(templates);
		newTemplate.templates.add(effect);
		return newTemplate;
	}

	public RollTemplate prepend(RollTemplate o) {
		RollTemplate newTemplate = new RollTemplate();
		newTemplate.templates.addAll(templates);
		newTemplate.templates.addAll(0, o.templates);
		return newTemplate;
	}

	public RollTemplate append(RollTemplate o) {
		RollTemplate newTemplate = new RollTemplate();
		newTemplate.templates.addAll(templates);
		newTemplate.templates.addAll(o.templates);
		return newTemplate;
	}

	public RollTemplate advantage(final Advantage type) {
		return attach(roll -> roll.advantage(type));
	}

	public RollTemplate advantage() {
		return advantage(Advantage.ADVANTAGE);
	}

	public RollTemplate disadvantage() {
		return advantage(Advantage.DISADVANTAGE);
	}

	public RollTemplate add(final Rollable roll) {
		return attach(rollBuilder -> rollBuilder.add(roll));
	}

	public RollTemplate add(int modifier) {
		return add(new Modifier(modifier));
	}

	public RollTemplate addDie(int size) {
		return add(new RegularDie(size));
	}

	public RollTemplate subtract(int modifier) {
		return add(-modifier);
	}

	public RollTemplate subtract(final Rollable roll) {
		return attach(rollBuilder -> rollBuilder.subtract(roll));
	}

	public RollTemplate subtractDie(int size) {
		return subtract(new RegularDie(size));
	}

	public RollTemplate transform(final Transformer transformer) {
		return attach(roll -> roll.transform(transformer));
	}

	public RollTemplate filter(final Filter type) {
		return attach(roll -> roll.filter(type));
	}

	public RollTemplate filter(int value, FilterType type) {
		return filter(new Filter(value, type));
	}

	public RollTemplate filter(final Predicate<Outcome> predicate) {
		return attach(roll -> roll.filter(predicate));
	}

	public RollTemplate flatten() {
		return attach(roll -> roll.flatten());
	}

	public RollTemplate filterAndFlatten(final Filter type) {
		return attach(roll -> roll.filterAndFlatten(type));
	}

	public RollTemplate filterAndFlatten(int value, FilterType type) {
		return filterAndFlatten(new Filter(value, type));
	}

	public RollTemplate filterAndFlatten(final Predicate<Outcome> predicate) {
		return attach(roll -> roll.filterAndFlatten(predicate));
	}

	public RollTemplate repeat(final int count) {
		return attach(roll -> roll.repeat(count));
	}
}
