package org.scratch.main.dice.model.ternary;

import org.scratch.main.dice.model.Outcome;

public class BinaryOperator implements TernaryOperator {
	private BinaryOperator() {}
	public static final BinaryOperator instance = new BinaryOperator();
	@Override
	public boolean test(Outcome condition) {
		return condition.compareTo(new Outcome()) != 0;
	}

}
