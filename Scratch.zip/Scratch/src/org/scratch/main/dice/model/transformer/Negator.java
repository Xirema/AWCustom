package org.scratch.main.dice.model.transformer;

import org.scratch.main.dice.model.Outcome;

public class Negator implements Transformer {
	private Negator() {
	}

	public static final Negator instance = new Negator();

	@Override
	public Outcome transform(Outcome roll) {
		return new Outcome(-roll.value, -roll.special);
	}

}
