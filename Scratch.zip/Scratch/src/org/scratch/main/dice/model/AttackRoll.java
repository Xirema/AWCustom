package org.scratch.main.dice.model;

import java.util.Arrays;
import java.util.List;

public class AttackRoll {
	public final Rollable attack, damage, crit;

	public AttackRoll(Rollable attack, Rollable damage, Rollable crit) {
		this.attack = attack;
		this.damage = damage;
		this.crit = crit;
	}

	public AttackRoll(Rollable damage, Rollable crit) {
		this(StandardDice.mod0, damage, crit);
	}

	public AttackRoll(RollBuilder attack, RollBuilder damage, RollBuilder crit) {
		this(attack.getRoll(), damage.getRoll(), crit.getRoll());
	}

	public AttackRoll(RollBuilder damage, RollBuilder crit) {
		this(damage.getRoll(), crit.getRoll());
	}

	public AttackRoll[] repeat(int num) {
		AttackRoll[] rolls = new AttackRoll[num];
		Arrays.fill(rolls, this);
		return rolls;
	}

	public List<AttackRoll> repeatList(int num) {
		return Arrays.asList(repeat(num));
	}
}
