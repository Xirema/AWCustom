package org.scratch.main.dice.model;

import java.util.Objects;

public class Outcome implements Comparable<Outcome> {
	public final int value, special;

	public Outcome() {
		this(0);
	}

	public Outcome(int value) {
		this(value, 0);
	}

	public Outcome(int value, int special) {
		this.value = value;
		this.special = special;
	}

	@Override
	public int hashCode() {
		return Objects.hash(value, special);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o.getClass().equals(getClass())) {
			Outcome d = (Outcome) o;
			return d.value == value && d.special == special;
		} else
			return false;
	}

	@Override
	public int compareTo(Outcome o) {
		if (special != o.special)
			return special - o.special;
		else
			return value - o.value;
	}

	@Override
	public String toString() {
		String ret = "";
		if (value > 0) {
			ret += "+";
		}
		ret += value;
		if (special != 0) {
			ret += "*";
		}
		return ret;
	}
}
