package org.scratch.main.dice.model;

import java.math.BigInteger;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Random;

import org.scratch.main.util.BigRational;

public class RegularDie implements Rollable {
	public final int minimumValue;
	public final int maximumValue;

	public RegularDie() {
		this(1, 6);
	}

	public RegularDie(int minimumValue, int maximumValue) {
		if (minimumValue > maximumValue)
			throw new RuntimeException(
					"Invalid Die Parameters: Must have positive number of faces, minimum must be larger than maximum.");
		this.minimumValue = minimumValue;
		this.maximumValue = maximumValue;
	}

	public RegularDie(int numOfFaces) {
		this(1, numOfFaces);
	}

	@Override
	public BigRational mean() {
		return new BigRational(minimumValue + maximumValue, 2);
	}

	public RegularDie withMinimum(int minimumValue) {
		return new RegularDie(minimumValue, maximumValue);
	}

	public RegularDie withMaximum(int maximumValue) {
		return new RegularDie(minimumValue, maximumValue);
	}

	@Override
	public Outcome roll(Random engine) {
		return new Outcome(engine.nextInt(numOfOutcomesImpl()) + minimumValue);
	}

	private int numOfOutcomesImpl() {
		return maximumValue - minimumValue + 1;
	}

	@Override
	public int numOfUniqueOutcomes() {
		return numOfOutcomesImpl();
	}

	// @Override
	// public BigRational oddsOfOutcome(Outcome outcome) {
	// return new BigRational(1, numOfOutcomesImpl());
	// }
	@Override
	public Outcome[] outcomes() {
		Outcome[] out = new Outcome[numOfOutcomesImpl()];
		for (int i = minimumValue; i <= maximumValue; i++) {
			out[i - minimumValue] = new Outcome(i);
		}
		return out;
	}

	@Override
	public boolean hasOutcome(Outcome outcome) {
		return outcome.value >= minimumValue && outcome.value <= maximumValue;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof RegularDie))
			return false;
		return ((RegularDie) o).minimumValue == minimumValue && ((RegularDie) o).maximumValue == maximumValue;
	}

	@Override
	public int hashCode() {
		return Objects.hash(minimumValue, maximumValue);
	}

	@Override
	public String getName() {
		if (minimumValue == 1)
			return "d" + maximumValue;
		else
			return "d" + minimumValue + "..." + maximumValue;
	}

	@Override
	public String toString() {
		return getName();
	}

	@Override
	public Outcome highestOutcome() {
		return new Outcome(maximumValue);
	}

	@Override
	public Outcome lowestOutcome() {
		return new Outcome(minimumValue);
	}

	@Override
	public Outcome median() {
		return new Outcome((maximumValue + minimumValue) / 2);
	}

	@Override
	public Outcome percentile(double percent) {
		return new Outcome((int) (minimumValue + (maximumValue - minimumValue) * percent));
	}

	@Override
	public BigRational oddsLessThan(Outcome outcome) {
		if (outcome.value <= minimumValue)
			return BigRational.ZERO;
		if (outcome.value > maximumValue)
			return BigRational.ONE;
		return new BigRational(outcome.value - minimumValue, numOfOutcomesImpl());
	}

	@Override
	public BigRational oddsLessEqualThan(Outcome outcome) {
		return oddsLessThan(new Outcome(outcome.value + 1, outcome.special));
	}

	@Override
	public BigRational oddsGreaterThan(Outcome outcome) {
		if (outcome.value < minimumValue)
			return BigRational.ONE;
		if (outcome.value >= maximumValue)
			return BigRational.ZERO;
		return new BigRational(maximumValue - outcome.value, numOfOutcomesImpl());
	}

	@Override
	public BigRational oddsGreaterEqualThan(Outcome outcome) {
		return oddsGreaterThan(new Outcome(outcome.value - 1, outcome.special));
	}

	@Override
	public BigInteger denormalOdds() {
		return BigInteger.valueOf(numOfOutcomesImpl());
	}

	@Override
	public BigInteger denormalOdds(Outcome outcome) {
		if (hasOutcome(outcome))
			return BigInteger.ONE;
		else
			return BigInteger.ZERO;
	}

	@Override
	public Iterator<Outcome> outcomeIterator() {
		final int min = minimumValue, max = maximumValue;
		return new Iterator<Outcome>() {
			int current = min;

			@Override
			public boolean hasNext() {
				return current < max;
			}

			@Override
			public Outcome next() {
				if (current <= max)
					return new Outcome(current++);
				else
					throw new NoSuchElementException();
			}

			@Override
			public void remove() {
				throw new UnsupportedOperationException("Rolls are immutable");
			}
		};
	}
}
