package org.scratch.main.dice.format;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.scratch.main.dice.model.CompositeRoll;
import org.scratch.main.dice.model.CustomDie;
import org.scratch.main.dice.model.Modifier;
import org.scratch.main.dice.model.Outcome;
import org.scratch.main.dice.model.RegularDie;
import org.scratch.main.dice.model.Rollable;
import org.scratch.main.dice.model.TernaryRoll;
import org.scratch.main.dice.model.TransformingRoll;
import org.scratch.main.dice.model.compositor.Compositor;
import org.scratch.main.dice.model.ternary.TernaryOperator;
import org.scratch.main.dice.model.transformer.Transformer;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.Matrix;
import java.util.Optional;

public class RollPrinter {
	public static class PrinterOptions {
		public boolean showPassOdds = true;
		public boolean terseStats = false;
		public List<Double> percentiles = Arrays.asList(0.8, 0.95, 0.995);
		public boolean splitTrials = false;
		public boolean denorm = true;
		public boolean removeOdds = false;
		public boolean wholeOutcome = false;
	}

	public static class TableOptions {
		public List<String> rowHeaders = new ArrayList<>(Arrays.asList(""));
		public List<String> columnHeaders = new ArrayList<>(Arrays.asList("Name"));
		public List<String> groupHeaders = new ArrayList<>();
		public int groupSize = 1;
		public char csvSeparator = ',';
	}

	public static String formatRoll(Rollable roll) {
		return formatRoll(roll, new PrinterOptions());
	}

	private static String formatOutcome(Outcome face) {
		if (face.special == 0)
			return "" + face.value;
		else if (face.special == -1)
			return "" + face.value + "†";
		else
			return "" + face.value + "*";
	}

	private static String fullOutcome(Outcome face) {
		if (face.special == 0)
			return "[" + face.value + "]";
		else
			return "[" + face.value + "," + face.special + "]";
	}

	public static String printDecomposedRolls(Rollable roll) {
		Set<Rollable> uniqueRolls = new HashSet<>();
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			Deque<Rollable> deque = new ArrayDeque<>();
			deque.push(roll);
			while (deque.size() != 0) {
				Rollable currentRoll = deque.pop();
				if (uniqueRolls.contains(currentRoll)) {
					continue;
				}
				uniqueRolls.add(currentRoll);
				printDecomposedRoll(out, currentRoll, deque);
			}
			return stream.toString("UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Lolwut");
		}
	}

	private static void printDecomposedRoll(PrintStream out, Rollable roll, Deque<Rollable> deque) {
		out.println("Name: " + roll.getName());
		out.println("Outcome | Trials");
		for (Outcome outcome : roll.outcomes()) {
			out.println(fullOutcome(outcome) + " | " + roll.oddsOfOutcome(outcome));
		}
		out.println();
		if (roll instanceof Modifier || roll instanceof RegularDie || roll instanceof CustomDie) {
			// Nothing else needed
		} else if (roll instanceof CompositeRoll) {
			CompositeRoll cRoll = (CompositeRoll) roll;
			deque.push(cRoll.firstRoll);
			deque.push(cRoll.secondRoll);
			printCompositeRollTable(cRoll, out);
		} else if (roll instanceof TransformingRoll) {
			TransformingRoll tRoll = (TransformingRoll) roll;
			deque.push(tRoll.original);
			printTransformedRollTable(tRoll, out);
		} else
			throw new UnsupportedOperationException("We haven't implemented this function for Ternary Rolls yet: "
					+ roll.getName() + ", " + roll.getClass());
	}

	private static void printTernaryRollTable(TernaryRoll roll, PrintStream out) {
		Rollable condition = roll.conditionRoll;
		TernaryOperator operator = roll.operator;
		Outcome[] outcomes = condition.outcomes();
		out.println("Original|ifTrue Trials|ifTrue Outcomes|ifFalse Trials|ifFalse Outcomes");
		for (Outcome outcome : outcomes) {
			out.print(fullOutcome(outcome) + "|");
			operator.test(outcome);
		}
		out.println();
	}

	private static void printTransformedRollTable(TransformingRoll roll, PrintStream out) {
		Rollable original = roll.original;
		Transformer transformer = roll.transformer;
		Outcome[] outcomes = original.outcomes();
		out.println("Original|Trials|Transformed");
		for (Outcome outcome : outcomes) {
			out.println(fullOutcome(outcome) + "|" + original.oddsOfOutcome(outcome) + "|"
					+ fullOutcome(transformer.transform(outcome)));
		}
		out.println();
	}

	private static void printCompositeRollTable(CompositeRoll roll, PrintStream out) {
		Rollable first = roll.firstRoll, second = roll.secondRoll;
		Compositor compositor = roll.compositor;
		Outcome[] firstOutcomes = first.outcomes();
		Outcome[] secondOutcomes = second.outcomes();
		out.print("Outcomes|" + first.getName() + "→|");
		for (int i = 0; i < firstOutcomes.length; i++) {
			out.print(fullOutcome(firstOutcomes[i]));
			if (i != firstOutcomes.length - 1) {
				out.print("|");
			}
		}
		out.println();
		out.print(second.getName() + "↓|Odds|");
		for (int i = 0; i < firstOutcomes.length; i++) {
			out.print(first.oddsOfOutcome(firstOutcomes[i]));
			if (i != firstOutcomes.length - 1) {
				out.print("|");
			}
		}
		out.println();
		for (Outcome secondOutcome : secondOutcomes) {
			out.print(fullOutcome(secondOutcome) + "|" + second.oddsOfOutcome(secondOutcome) + "|");
			for (int column = 0; column < firstOutcomes.length; column++) {
				Outcome outcome = compositor.composite(firstOutcomes[column], secondOutcome);
				BigRational trials = first.oddsOfOutcome(firstOutcomes[column])
						.times(second.oddsOfOutcome(secondOutcome));
				out.print(fullOutcome(outcome) + " (" + trials + ")");
				if (column != firstOutcomes.length - 1) {
					out.print("|");
				}
			}
			out.println();
		}
		out.println();
	}

	public static String printOutcomeArray(Rollable roll) {
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			out.println("|Outcomes|Odds %|Odds|Cumulative|");
			out.println("|:---|:---:|:---:|:---:|");
			for (Outcome outcome : roll.outcomes()) {
				out.print("|__" + formatOutcome(outcome) + "__|" + roll.oddsOfOutcome(outcome) + "|");
				out.printf("%.3f%%", roll.oddsOfOutcome(outcome).doubleValue() * 100);
				out.print(" (" + roll.oddsOfOutcome(outcome) + ")|");
				out.printf("%.3f%%|", roll.oddsOfPassingDC(outcome).doubleValue() * 100);
				out.println();
			}
			out.println("|__Total__||__100%__|");
			out.print("|__Average: ");
			out.printf("%.3f", roll.mean());
			out.println("__|__Median: " + formatOutcome(roll.median()) + "__|__95th: ["
					+ formatOutcome(roll.percentile(0.025)) + "," + formatOutcome(roll.percentile(0.975)) + "]__|");

			return stream.toString("UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Lolwut");
		}
	}

	public static String printCSVTable(List<Rollable> rolls, TableOptions options) {
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			if (options.columnHeaders.size() <= 1 || options.rowHeaders.size() <= 1)
				return "";
			Matrix<String> mat = new Matrix<>(options.rowHeaders.size(), options.columnHeaders.size());
			for (int i = 0; i < options.columnHeaders.size(); i++) {
				mat.set(0, i, options.columnHeaders.get(i));
			}
			for (int i = 1; i < options.rowHeaders.size(); i++) {
				mat.set(i, 0, options.rowHeaders.get(i));
			}

			int rollIndex = 0;
			while (rollIndex < rolls.size()) {
				int column = ((rollIndex / options.groupSize) % (options.columnHeaders.size() - 1)) + 1;
				int row = (rollIndex / (options.columnHeaders.size() - 1) / options.groupSize) * options.groupSize
						+ (rollIndex % options.groupSize) + 1;
				if (!(column >= mat.size().second || row >= mat.size().first)) {
					mat.set(row, column, String.format("%.3f", rolls.get(rollIndex).mean().doubleValue()));
				}
				rollIndex++;
			}

			int groupIndex = -1;
			for (int row = 0; row < mat.size().first; row++) {
				for (int column = 0; column < mat.size().second; column++) {
					out.print(mat.get(row, column));
					if (column != mat.size().second - 1) {
						out.print(options.csvSeparator);
					}
				}
				out.println();
				groupIndex++;
				if (groupIndex == options.groupSize && options.groupSize > 1 && row != mat.size().first - 1) {
					out.println();
					groupIndex = 0;
				}
			}

			return stream.toString("UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Lolwut");
		}
	}

	public static String printFormattedTable(List<Rollable> rolls, TableOptions options) {
		if (options.columnHeaders.size() <= 1 || options.rowHeaders.size() <= 1)
			return "";
		Matrix<String> mat;
		// if(options.groupSize == 1)
		mat = new Matrix<>(options.rowHeaders.size(), options.columnHeaders.size());
		// else
		// mat = new Matrix<>(options.rowHeaders.size() +
		// options.rowHeaders.size() / options.groupSize,
		// options.columnHeaders.size());
		for (int i = 0; i < options.columnHeaders.size(); i++) {
			mat.set(0, i, options.columnHeaders.get(i));
		}
		for (int i = 1; i < options.rowHeaders.size(); i++) {
			mat.set(i, 0, options.rowHeaders.get(i));
		}

		int rollIndex = 0;
		while (rollIndex < rolls.size()) {
			int column = ((rollIndex / options.groupSize) % (options.columnHeaders.size() - 1)) + 1;
			int row = (rollIndex / (options.columnHeaders.size() - 1) / options.groupSize) * options.groupSize
					+ (rollIndex % options.groupSize) + 1;
			if (!(column >= mat.size().second || row >= mat.size().first)) {
				mat.set(row, column, String.format("%.3f", rolls.get(rollIndex).mean().doubleValue()));
			}
			rollIndex++;
		}

		FlatTableOptions foptions = new FlatTableOptions();
		foptions.dividerInterval = options.groupSize;
		return flatTable(mat, foptions);
	}

	public static String printLaTEXTable(List<Rollable> rolls, TableOptions options) {
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			if (options.columnHeaders.size() <= 1 || options.rowHeaders.size() <= 1)
				return "";
			Matrix<String> mat = new Matrix<>(options.rowHeaders.size(), options.columnHeaders.size());
			for (int i = 0; i < options.columnHeaders.size(); i++) {
				mat.set(0, i, options.columnHeaders.get(i));
			}
			for (int i = 1; i < options.rowHeaders.size(); i++) {
				mat.set(i, 0, options.rowHeaders.get(i));
			}

			int rollIndex = 0;
			while (rollIndex < rolls.size()) {
				int column = ((rollIndex / options.groupSize) % (options.columnHeaders.size() - 1)) + 1;
				int row = (rollIndex / (options.columnHeaders.size() - 1) / options.groupSize) * options.groupSize
						+ (rollIndex % options.groupSize) + 1;
				if (!(column >= mat.size().second || row >= mat.size().first)) {
					mat.set(row, column, String.format("%.3f", rolls.get(rollIndex).mean().doubleValue()));
				}
				rollIndex++;
			}

			out.print("\\begin{array}");
			out.print("{|l|");
			for (int i = 1; i < options.columnHeaders.size(); i++) {
				out.print("r|");
			}
			out.println("}");

			out.println("\\hline");
			int groupIndex = -1;
			for (int row = 0; row < mat.size().first; row++) {
				for (int column = 0; column < mat.size().second; column++) {
					if (row == 0 || column == 0) {
						out.print("\\text{" + mat.get(row, column) + "}");
					} else {
						out.print(mat.get(row, column));
					}
					if (column != mat.size().second - 1) {
						out.print(" & ");
					}
				}
				out.println("\\\\ \\hline");
				groupIndex++;
				if (groupIndex == options.groupSize && options.groupSize > 1 && row != mat.size().first - 1) {
					out.println("\\\\ \\hline");
					groupIndex = 0;
				}
			}

			out.println("\\end{array}");

			return stream.toString("UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Lolwut");
		}
	}

	public static String printLaTEXArray(Rollable roll, PrinterOptions options) {
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			out.println("\\begin{array}{l|rrr}");

			out.print("\\text{Outcomes} & \\text{Odds} & ");
			if (options.splitTrials) {
				out.print("\\text{# of Trials} & \\text{(raw)}");
			} else {
				out.print("\\text{# of Trials}");
			}
			if (options.showPassOdds) {
				out.print(" & \\text{% ≥ Outcome}");
			}
			out.println();
			out.print("\\\\ \\hline");
			for (Outcome outcome : roll.outcomes()) {
				out.println();
				out.print("\\text{" + fullOutcome(outcome) + "}");
				if (!options.removeOdds) {
					out.print(" & ");
					out.printf("\\text{%.3f%%}", roll.oddsOfOutcome(outcome).doubleValue() * 100);
				}
				out.print(" & ");
				if (options.denorm) {
					out.print(roll.denormalOdds(outcome));
				} else if (options.splitTrials) {
					out.printf("\\text{%.3g}", roll.oddsOfOutcome(outcome).doubleValue());
					out.print(" & (" + roll.oddsOfOutcome(outcome) + ") ");
				} else {
					out.print(roll.oddsOfOutcome(outcome));
				}
				if (options.showPassOdds) {
					out.print(" & ");
					out.printf("\\text{%.3f%%}", roll.oddsOfPassingDC(outcome).doubleValue() * 100);
				}
				out.print("\\\\");
			}
			out.println(" \\hline");
			out.print("\\text{Average} & ");
			out.printf("%.3f", roll.mean().doubleValue());
			out.println();
			out.println("\\end{array}");

			return stream.toString("UTF-8");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	public static class FlatTableOptions {
		int dividerInterval = 0;
	}
	
	public static String flatTable(Matrix<String> cells) {
		return flatTable(cells, new FlatTableOptions());
	}

	public static String flatTable(Matrix<String> cells, FlatTableOptions options) {
		if (cells.getRows() == 0 || cells.getColumns() == 0)
			return "";
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintWriter out = new PrintWriter(stream)) {
			List<Integer> maxColumnSizes = new ArrayList<>();
			for (int column = 0; column < cells.getColumns(); column++) {
				int maxSize = 0;
				for (int row = 0; row < cells.getRows(); row++) {
					maxSize = Math.max(maxSize, Optional.ofNullable(cells.get(row, column)).orElse("").length());
				}
				maxColumnSizes.add(maxSize);
			}
			String header = "\u2554\u2550";
			int columnSize = maxColumnSizes.get(0);
			for (int i = 0; i < columnSize; i++) {
				header += "\u2550";
			}
			for (int column = 1; column < cells.getColumns(); column++) {
				columnSize = maxColumnSizes.get(column);
				header += "\u2550\u2564\u2550";
				for (int i = 0; i < columnSize; i++) {
					header += "\u2550";
				}
			}
			header += "\u2550\u2557";
			out.println(header);

			for (int row = 0; row < cells.getRows(); row++) {
				if (row % 10_000 == 9999) {
					System.out.println("Writing Row " + (row + 1) + "/" + cells.getRows());
				}
				columnSize = maxColumnSizes.get(0);
				out.print("\u2551 " + String.format("%" + columnSize + "s", cells.get(row, 0)));
				for (int column = 1; column < cells.getColumns(); column++) {
					columnSize = maxColumnSizes.get(column);
					out.print(" \u2502 ");
					out.printf("%" + columnSize + "s", Optional.ofNullable(cells.get(row, column)).orElse(""));
				}
				out.println(" \u2551");
				if (row == 0 ||
						(options.dividerInterval != 0 && 
						(row + 0) % options.dividerInterval == 0 &&
						(row + 1) < cells.getRows())
				) {
					columnSize = maxColumnSizes.get(0);
					out.print("\u255f\u2500");
					for (int i = 0; i < columnSize; i++) {
						out.print("\u2500");
					}

					for (int column = 1; column < cells.getColumns(); column++) {
						columnSize = maxColumnSizes.get(column);
						out.print("\u2500\u253c\u2500");
						for (int i = 0; i < columnSize; i++) {
							out.print("\u2500");
						}
					}
					out.println("\u2500\u2562");
				}
			}

			header = "\u255a\u2550";
			columnSize = maxColumnSizes.get(0);
			for (int i = 0; i < columnSize; i++) {
				header += "\u2550";
			}
			for (int column = 1; column < cells.getColumns(); column++) {
				columnSize = maxColumnSizes.get(column);
				header += "\u2550\u2567\u2550";
				for (int i = 0; i < columnSize; i++) {
					header += "\u2550";
				}
			}
			header += "\u2550\u255d";
			out.println(header);
			out.flush();

			return stream.toString("UTF-8");
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public static String formatRoll(Rollable roll, PrinterOptions options) {
		try (ByteArrayOutputStream stream = new ByteArrayOutputStream(); PrintStream out = new PrintStream(stream)) {
			out.println("Stats for Roll [" + roll.getName() + "]");

			Outcome[] outcomes = roll.outcomes();
			int numOfColumns;
			if (options.showPassOdds) {
				numOfColumns = 5;
			} else {
				numOfColumns = 4;
			}
			Matrix<String> table = new Matrix<>(outcomes.length + 1, numOfColumns, false);
			if (!options.terseStats) {
				table.set(0, 0, "Outcome");
				table.set(0, 1, "Odds");
				table.set(0, 2, "Trials");
				table.set(0, 3, "Denorm");
				if (options.showPassOdds) {
					table.set(0, 4, "Pass Odds");
				}
			}

			Outcome mode = (outcomes.length != 0 ? outcomes[0] : new Outcome());
			BigRational modeOccurrences = roll.oddsOfOutcome(mode);

			for (int row = 0; row < outcomes.length; row++) {
				if ((row % 10_000) == 9999) {
					System.out.println("Processing row " + (row + 1) + "/" + outcomes.length);
				}
				Outcome outcome = outcomes[row];
				BigRational num = roll.oddsOfOutcome(outcome);
				BigInteger denorm = roll.denormalOdds(outcome);
				double odds = roll.oddsOfOutcome(outcome).doubleValue();
				double oddsOfPassing;
				if (options.showPassOdds) {
					oddsOfPassing = roll.oddsOfPassingDC(outcome).doubleValue();
				} else {
					oddsOfPassing = 0;
				}
				if (num.compareTo(modeOccurrences) > 0) {
					mode = outcome;
					modeOccurrences = num;
				}
				if (!options.terseStats) {
					if(options.wholeOutcome)
						table.set(row + 1,  0, fullOutcome(outcome));
					else
						table.set(row + 1, 0, outcome.toString());
					table.set(row + 1, 1, String.format("%7.3f%%", odds * 100));
					table.set(row + 1, 2, num.toString());
					table.set(row + 1, 3, denorm.toString());
					if (options.showPassOdds) {
						table.set(row + 1, 4, String.format("%7.3f%%", oddsOfPassing * 100));
					}
				}
			}
			if (!options.terseStats) {
				out.println(flatTable(table));
			}
			// out.println("Total Possible Rolls: " +
			// roll.oddsOfOutcome().doubleValue() + " (" + roll.numOfTrials() +
			// ")");
			out.printf("Mean: %f\n", roll.mean().doubleValue());
			out.println("Median: " + roll.median());
			out.println("Mode: " + mode + " (" + modeOccurrences.doubleValue() + ")");
			for (double percentile : options.percentiles) {
				double low = (0.5 - percentile / 2), high = (0.5 + percentile / 2);
				out.println(
						(percentile * 100) + "% Range: [" + roll.percentile(low) + "," + roll.percentile(high) + "]");
			}
			return stream.toString("UTF-8");
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException("Lolwut");
		}
	}
}
