package org.scratch.main.zgl.model;

public class Triangle {
	public final Vector a, b, c;

	public Triangle() {
		this(new Vector(), new Vector(), new Vector());
	}

	public Triangle(Vector a, Vector b, Vector c) {
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public static Triangle of(Vector a, Vector b, Vector c) {
		return new Triangle(a, b, c);
	}

	public static Triangle copyOf(Triangle t) {
		return of(t.a, t.b, t.c);
	}

	public float area() {
		Vector ac = c.minus(a);
		Vector ab = b.minus(a);
		return ab.cross(ac).length() / 2;
	}

	public Triangle translate(Vector v) {
		return of(a.plus(v), b.plus(v), c.plus(v));
	}

	public Triangle scale(Vector anchor, float scale) {
		return of(a.plus(a.minus(anchor).scale(scale - 1)), b.plus(b.minus(anchor).scale(scale - 1)),
				c.plus(c.minus(anchor).scale(scale - 1)));
	}

	public Vector orthocenter() {
		throw new RuntimeException("Not Implemented!");
	}
}
