package org.scratch.main.zgl.model;

import java.util.Optional;

public class Line {
	public final Vector a, b;

	public Line() {
		this(new Vector(), new Vector());
	}

	public Line(Vector a, Vector b) {
		this.a = a;
		this.b = b;
	}

	public static Line of(Vector a, Vector b) {
		return new Line(a, b);
	}

	public static Line copyOf(Line l) {
		return of(l.a, l.b);
	}

	public Vector midpoint() {
		return a.midpoint(b);
	}

	public Vector lengthVector() {
		return b.minus(a);
	}

	public Optional<Vector> intersection(Line l) {
		// Pa = Oa + t * Da
		// Pb = Ob + t * Db
		// Oa + t * Da = Ob + t * Db
		// t * Da - t * Db = Ob - Oa
		// t(Da - Db) = Ob - Oa
		// t = (Ob - Oa) / (Da - Db)
		// tx = (Obx - Oax) / (Dax - Dbx);
		// ty = (Oby - Oay) / (Day - Dby);
		// tz = (Obz - Oaz) / (Daz - Dbz);
		throw new RuntimeException("Not Implemented!");
	}
}
