package org.scratch.main.zgl.model;

public class Vector {
	public final float x, y, z;

	public Vector() {
		this(0, 0, 0);
	}

	public Vector(float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static Vector of(float x, float y, float z) {
		return new Vector(x, y, z);
	}

	public static Vector copyOf(Vector v) {
		return of(v.x, v.y, v.z);
	}

	public Vector plus(Vector v) {
		return of(x + v.x, y + v.y, z + v.z);
	}

	public Vector minus(Vector v) {
		return of(x - v.x, y - v.y, z - v.z);
	}

	public Vector multipliedBy(Vector v) {
		return of(x * v.x, y * v.y, z * v.z);
	}

	public Vector dividedBy(Vector v) {
		return of(x / v.x, y / v.y, z / v.z);
	}

	public float length() {
		return (float) Math.sqrt(x * x + y * y + z * z);
	}

	public Vector normalized() {
		return normalized(1);
	}

	public Vector normalized(float newLength) {
		float ratio = newLength / length();
		return scale(ratio);
	}

	public float dot(Vector v) {
		return x * v.x + y * v.y + z * v.z;
	}

	public Vector cross(Vector v) {
		return of(y * v.z - z * v.y, z * v.x - x * v.z, x * v.y - y * v.x);
	}

	public Vector scale(float f) {
		return of(x * f, y * f, z * f);
	}

	public float angleBetween(Vector v) {
		float ratio = dot(v) / (length() * v.length());
		return (float) Math.acos(ratio);
	}

	public Vector rotateAround(Vector origin, Vector normal, float radians) {
		throw new RuntimeException("Not Implemented!");
	}

	public Vector midpoint(Vector v) {
		return of((x + v.x) * 0.5f, (y + v.y) * 0.5f, (z + v.z) * 0.5f);
	}

	@Override
	public String toString() {
		return "<" + x + "," + y + "," + z + ">";
	}
}
