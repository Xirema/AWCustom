package org.scratch.main.kdtree;

import java.lang.reflect.Array;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import java.util.Optional;

public class KDTree<T extends KDComparable<T>> implements Collection<T> {
	protected static class KDNode<T> {
		protected T object;
		protected Optional<KDNode<T>> rightChild;
		protected Optional<KDNode<T>> leftChild;

		protected KDNode(T object) {
			// Valid in Java 8, invalid in Java 7
			// this(object, Optional.empty(), Optional.empty());
			this(object, Optional.ofNullable((KDNode<T>) null), Optional.ofNullable((KDNode<T>) null));
		}

		protected KDNode(T object, Optional<KDNode<T>> rightChild, Optional<KDNode<T>> leftChild) {
			this.object = object;
			this.rightChild = rightChild;
			this.leftChild = leftChild;
		}
	}

	protected Optional<KDNode<T>> root;
	protected int treeSize;
	protected List<Comparator<T>> comparators;

	public KDTree() {
		root = Optional.empty();
		treeSize = 0;
		comparators = null;
	}

	private void addLeaf(KDNode<T> node, T object, int dim) {
		if (object.kdCompareTo(node.object, dim % object.getMaxDim()) <= 0) {
			if (!node.leftChild.isPresent()) {
				node.leftChild = Optional.of(new KDNode<>(object));
			} else {
				addLeaf(node.leftChild.get(), object, dim + 1);
			}
		} else {
			if (!node.rightChild.isPresent()) {
				node.rightChild = Optional.of(new KDNode<>(object));
			} else {
				addLeaf(node.rightChild.get(), object, dim + 1);
			}
		}
	}

	@Override
	public boolean add(T o) {
		treeSize++;
		if (root.isPresent()) {
			addLeaf(root.get(), o, 0);
		} else {
			root = Optional.of(new KDNode<>(o));
		}

		return true;
	}

	private KDNode<T> buildWholeTree(List<T> objectList, int dim, List<Comparator<T>> comparators) {
		if (objectList.size() == 0)
			return null;
		int axis = dim % comparators.size();
		Collections.sort(objectList, comparators.get(axis));
		int median = objectList.size() / 2;
		KDNode<T> node = new KDNode<>(objectList.get(median),
				Optional.ofNullable(buildWholeTree(objectList.subList(0, median), dim + 1, comparators)),
				Optional.ofNullable(
						buildWholeTree(objectList.subList(median + 1, objectList.size()), dim + 1, comparators)));
		return node;
	}

	@Override
	public boolean addAll(Collection<? extends T> collection) {
		if (root.isPresent()) {
			for (T obj : collection) {
				add(obj);
			}
			return true;
		}
		return addAll(new ArrayList<>(collection));
	}

	private List<Comparator<T>> getComparators(int dim) {
		if (comparators == null) {
			comparators = new ArrayList<>();
			for (int i = 0; i < dim; i++) {
				final int _i = i;
				comparators.add((a, b) -> a.kdCompareTo(b, _i));
			}
		}
		return comparators;
	}

	private boolean addAll(List<T> list) {
		if (list.isEmpty())
			return true;
		List<Comparator<T>> comparators = getComparators(list.get(0).getMaxDim());
		root = Optional.of(buildWholeTree(list, 0, comparators));
		treeSize = list.size();
		return true;
	}

	@Override
	public void clear() {
		root = Optional.empty();
		treeSize = 0;
	}

	private Optional<KDNode<T>> find(KDNode<T> node, T object, int depth, boolean allowNearest) {
		if (node == null)
			return Optional.empty();
		if (object.equals(node.object))
			return Optional.of(node);
		// TODO: Finish this
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean contains(Object object) {
		if (!(object instanceof KDComparable<?>))
			return false;
		if (!root.isPresent())
			return false;
		return find(root.get(), (T) object, 0, false).isPresent();
	}

	@Override
	public boolean containsAll(Collection<?> collection) {
		for (Object object : collection)
			if (!contains(object))
				return false;
		return true;
	}

	@Override
	public boolean isEmpty() {
		return !root.isPresent();
	}

	private static class KDIterator<T> implements Iterator<T> {
		private KDNode<T> node;
		private Deque<KDNode<T>> parentStack;

		private KDIterator(KDNode<T> node) {
			this.node = node;
			parentStack = new ArrayDeque<>();
		}

		@Override
		public boolean hasNext() {
			return !parentStack.isEmpty() || node.leftChild.isPresent() || node.rightChild.isPresent();
		}

		@Override
		public T next() {
			if (node == null)
				throw new NoSuchElementException("Last Element of KDTree Reached");
			T object = node.object;
			if (node.leftChild.isPresent()) {
				parentStack.push(node);
				node = node.leftChild.get();
			} else if (node.rightChild.isPresent()) {
				node = node.rightChild.get();
			} else {
				do {
					if (parentStack.isEmpty()) {
						node = null;
						break;
					}
					node = parentStack.pop();
					if (node.rightChild.isPresent()) {
						node = node.rightChild.get();
						break;
					}
				} while (true);

			}
			return object;
		}

		@Override
		public void remove() {
			throw new UnsupportedOperationException("Implementation for KDIterator.remove() not complete.");
		}
	}

	@Override
	public Iterator<T> iterator() {
		return new KDIterator<>(root.orElse(null));
	}

	@Override
	public boolean remove(Object object) {
		throw new UnsupportedOperationException("Removal of nodes not implemented.");
	}

	@Override
	public boolean removeAll(Collection<?> collection) {
		boolean anyRemoved = false;
		for (Object o : collection) {
			boolean ret = remove(o);
			anyRemoved = anyRemoved || ret;
		}
		return anyRemoved;
	}

	@Override
	public boolean retainAll(Collection<?> arg0) {
		throw new UnsupportedOperationException("Retaining Nodes not implemented.");
	}

	@Override
	public int size() {
		return treeSize;
	}

	@Override
	public Object[] toArray() {
		List<T> list = new ArrayList<>();
		list.addAll(this);
		return list.toArray();
	}

	@SuppressWarnings("unchecked")
	@Override
	public <E> E[] toArray(E[] array) {
		int size = size();
		if (array.length < size) {
			// If array is too small, allocate the new one with the same
			// component type
			array = (E[]) Array.newInstance(array.getClass().getComponentType(), size);
		} else if (array.length > size) {
			// If array is to large, set the first unassigned element to null
			array[size] = null;
		}

		int i = 0;
		for (T e : this) {
			// No need for checked cast - ArrayStoreException will be thrown
			// if types are incompatible, just as required
			array[i] = (E) e;
			i++;
		}
		return array;
	}

}
