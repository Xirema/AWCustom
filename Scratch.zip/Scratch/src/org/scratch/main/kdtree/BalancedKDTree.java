package org.scratch.main.kdtree;

public class BalancedKDTree<T extends KDComparable<T>> extends KDTree<T> {
	KDNode node;

	public void doStuff() {
		node.leftChild = null;
	}
}
