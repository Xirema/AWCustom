package org.scratch.main.kdtree;

public interface KDComparable<T> {
	int kdCompareTo(T other, int dim);

	double distance(T other);

	int getMaxDim();
}
