package org.scratch.main.calc;

import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SmallCalcApp implements ActionListener {

	JFrame frame;
	JLabel firstOperand, secondOperand, answer;
	JTextField op1, op2, ans;
	JButton plus, mul;
	GridBagLayout layout;

	public SmallCalcApp() {
		initGUI();
	}

	public void initGUI() {

		frame = new JFrame();
		Container con = frame.getContentPane();

		// initialization of objects
		plus = new JButton("+");
		mul = new JButton("*");
		op1 = new JTextField();
		op2 = new JTextField();
		ans = new JTextField();
		firstOperand = new JLabel("First Number: ");
		secondOperand = new JLabel("Second Number: ");
		answer = new JLabel("Calculated Result: ");

		GridBagConstraints firstOperandConstraints = new GridBagConstraints(0, 0, 3, 1, 1, 1,
				GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints op1Constraints = new GridBagConstraints(4, 0, 3, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints secondOperandConstraints = new GridBagConstraints(0, 4, 3, 1, 1, 1,
				GridBagConstraints.NORTHWEST, GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints op2Constraints = new GridBagConstraints(4, 4, 3, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints answerConstraints = new GridBagConstraints(0, 6, 3, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints ansConstraints = new GridBagConstraints(6, 6, 3, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 30, 0), 0, 0);
		GridBagConstraints plusConstraints = new GridBagConstraints(0, 8, 1, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0);
		GridBagConstraints mulConstraints = new GridBagConstraints(4, 8, 1, 1, 1, 1, GridBagConstraints.NORTHWEST,
				GridBagConstraints.BOTH, new Insets(0, 0, 0, 0), 0, 0);

		JPanel panel = new JPanel();

		panel.setLayout(layout = new GridBagLayout());
		layout.columnWidths = new int[9];
		Arrays.fill(layout.columnWidths, 50);
		layout.rowHeights = new int[9];
		Arrays.fill(layout.rowHeights, 50);

		panel.add(firstOperand, firstOperandConstraints);
		panel.add(op1, op1Constraints);
		panel.add(secondOperand, secondOperandConstraints);
		panel.add(op2, op2Constraints);
		panel.add(answer, answerConstraints);
		panel.add(ans, ansConstraints);
		panel.add(plus, plusConstraints);
		panel.add(mul, mulConstraints);

		GridBagLayout rootLayout = new GridBagLayout();
		rootLayout.columnWidths = new int[] { 450 };
		rootLayout.rowHeights = new int[] { 450 };
		con.setLayout(rootLayout);
		con.add(panel, new GridBagConstraints(0, 0, 1, 1, 1, 1, GridBagConstraints.NORTHWEST, GridBagConstraints.NONE,
				new Insets(0, 0, 0, 0), 0, 0));

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setMinimumSize(null);
		frame.pack();
		frame.setMinimumSize(frame.getSize());
		frame.setVisible(true);

		plus.addActionListener(this);
		mul.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		String oper, result;
		int num1, num2, res;

		if (event.getSource() == plus) {
			oper = op1.getText();
			num1 = Integer.parseInt(oper);

			oper = op2.getText();
			num2 = Integer.parseInt(oper);

			res = num1 + num2;
			result = res + "";

			ans.setText(result);
		}

		if (event.getSource() == mul) {
			oper = op1.getText();
			num1 = Integer.parseInt(oper);

			oper = op2.getText();
			num2 = Integer.parseInt(oper);

			res = num1 * num2;
			result = res + "";

			ans.setText(result);
		}
	}

	public static void main(String[] args) {
		new SmallCalcApp();
	}
}