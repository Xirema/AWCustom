package org.scratch.main.util;

import java.awt.Color;

public final class MathUtil {
	private MathUtil() {
	}

	public static int ipow(int value, int exponent) {
		if (exponent == 0)
			return 1;
		if ((exponent & 1) == 0)
			return ipow(value * value, exponent / 2);
		return value * ipow(value, exponent - 1);
	}

	public static long ipow(long value, long exponent) {
		if (exponent == 0)
			return 1;
		if ((exponent & 1) == 0)
			return ipow(value * value, exponent / 2);
		return value * ipow(value, exponent - 1);
	}
	
	public static Color blend(Color a, Color b, float factor, float gamma) {
		if(gamma != 1) {
			float[] af = a.getComponents(null);
			float[] bf = b.getComponents(null);
			for(int i = 0; i < af.length; i++) {
				af[i] = (float)Math.pow(af[i], 1 / gamma);
				bf[i] = (float)Math.pow(bf[i], 1 / gamma);
				af[i] += (bf[i] - af[i]) * factor;
				af[i] = (float)Math.pow(af[i], gamma);
			}
			return new Color(af[0], af[1], af[2], af[3]);
		} else {
			float[] af = a.getComponents(null);
			float[] bf = b.getComponents(null);
			for(int i = 0; i < af.length; i++) {
				af[i] += (bf[i] - af[i]) * factor;
			}
			return new Color(af[0], af[1], af[2], af[3]);
		}
	}
	
	public static Color blend(Color a, Color b, float factor) {
		return blend(a, b, factor, 1);
	}
}
