package org.scratch.main.util;

import java.util.NoSuchElementException;
import java.util.Objects;

@Deprecated
public class Optional<T> {
	private final T object;
	private static final Optional<?> EMPTY_OPTIONAL = new Optional<>();

	private Optional() {
		this(null);
	}

	private Optional(T object) {
		this.object = object;
	}

	public static <T> Optional<T> of(T object) {
		if (object == null)
			throw new NullPointerException("Object must not be null");
		return new Optional<>(object);
	}

	public static <T> Optional<T> ofNullable(T object) {
		if (object == null)
			return empty();
		else
			return new Optional<>(object);
	}

	public static <T> Optional<T> empty() {
		@SuppressWarnings("unchecked")
		Optional<T> t = (Optional<T>) EMPTY_OPTIONAL;
		return t;
	}

	public T get() {
		if (isPresent())
			return object;
		else
			throw new NoSuchElementException("Optional was Empty");
	}

	public boolean isPresent() {
		return object != null;
	}

	public T or(T other) {
		if (isPresent())
			return object;
		else
			return other;
	}

	public boolean equals(Optional<T> o) {
		return Objects.equals(object, o.object);
	}

	@Override
	public int hashCode() {
		if (isPresent())
			return object.hashCode();
		else
			return 0;
	}

	@Override
	public String toString() {
		if (isPresent())
			return "[]";
		else
			return "[" + object.toString() + "]";
	}

	/*
	 * Java 8 functions which may or may not be reproducible here
	 *
	 * public void ifPresent(Consumer<? super T> consumer) { if(isPresent())
	 * consumer.accept(object); }
	 *
	 * public Optional<T> filter(Predicate<? super T> predicate) { if(isPresent
	 * && predicate.test(object)) return this; else return empty(); }
	 *
	 * public <U> Optional<U> map(Function<? super T, ? extends U> mapper) {
	 * if(isPresent()) return Optional.ofNullable(mapper.apply(object)); else
	 * return empty(); }
	 * 
	 * public <U> Optional<U> flatMap(Function<? super T, Optional<U>> mapper) {
	 * if(isPresent()) return mapper.apply(object); else return empty(); }
	 *
	 * public T orElseGet(Supplier<? extends T> other) { if(isPresent()) return
	 * object; else return other.get(); }
	 *
	 * public <X extends Throwable> T orElseThrow(Supplier<? extends X>
	 * exceptionSupplier) throws X extends Throwable { if(isPresent()) return
	 * object; else throw supplier.get(); }
	 */
}
