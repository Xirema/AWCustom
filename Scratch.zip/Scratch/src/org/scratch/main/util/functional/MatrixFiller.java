package org.scratch.main.util.functional;

public interface MatrixFiller<T> {
	T fill(int row, int column);
}
