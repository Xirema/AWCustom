package org.scratch.main.util.functional;

import java.util.Objects;

@Deprecated
public abstract class Predicate<T> {
	public abstract boolean test(T object);

	public Predicate<T> and(Predicate<T> other) {
		final Predicate<T> first = this;
		final Predicate<T> second = other;
		return new Predicate<T>() {
			@Override
			public boolean test(T object) {
				return first.test(object) && second.test(object);
			}
		};
	}

	public Predicate<T> negate() {
		final Predicate<T> first = this;
		return new Predicate<T>() {
			@Override
			public boolean test(T object) {
				return !first.test(object);
			}
		};
	}

	public Predicate<T> or(Predicate<T> other) {
		final Predicate<T> first = this;
		final Predicate<T> second = other;
		return new Predicate<T>() {
			@Override
			public boolean test(T object) {
				return first.test(object) || second.test(object);
			}
		};
	}

	public static <T> Predicate<T> isEqual(T object) {
		final T obj = object;
		return new Predicate<T>() {
			@Override
			public boolean test(T object) {
				return Objects.equals(object, obj);
			}
		};
	}
}
