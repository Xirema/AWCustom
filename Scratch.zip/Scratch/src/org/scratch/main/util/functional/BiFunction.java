package org.scratch.main.util.functional;

@Deprecated
public interface BiFunction<T, U, V> {
	T apply(U u, V v);
}
