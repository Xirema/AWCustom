package org.scratch.main.util.functional;

@Deprecated
public interface Supplier<E> {
	E get();
}
