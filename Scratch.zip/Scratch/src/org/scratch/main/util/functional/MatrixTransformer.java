package org.scratch.main.util.functional;

public interface MatrixTransformer<T, U> {
	public U transform(int row, int column, T object);
}
