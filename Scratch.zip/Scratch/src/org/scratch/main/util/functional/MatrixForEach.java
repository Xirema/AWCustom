package org.scratch.main.util.functional;

public interface MatrixForEach<T> {
	void apply(int row, int column, T object);
}
