package org.scratch.main.util.functional;

public interface MatrixPredicate<T> {
	boolean test(int row, int column, T object);
}
