package org.scratch.main.util;

import java.util.Objects;

public class Pair<K, V> implements Cloneable, Comparable<Pair<K, V>> {
	public final K first;
	public final V second;

	public Pair() {
		this(null, null);
	}

	public Pair(K first, V second) {
		this.first = first;
		this.second = second;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Pair<?, ?>))
			return false;
		try {
			@SuppressWarnings("unchecked")
			Pair<K, V> p = (Pair<K, V>) o;
			return Objects.equals(first, p.first) && Objects.equals(second, p.second);
		} catch (ClassCastException e) {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return Objects.hash(first, second);
	}

	@Override
	public Object clone() {
		return new Pair<>(first, second);
	}

	public static <K, V> Pair<K, V> of(K k, V v) {
		return new Pair<>(k, v);
	}

	@Override
	public String toString() {
		return "<" + first + "," + second + ">";
	}

	@SuppressWarnings("unchecked")
	@Override
	public int compareTo(Pair<K, V> o) {
		if (!(first instanceof Comparable))
			return 0;
		else {
			int ret = ((Comparable<K>) first).compareTo(o.first);
			if (ret != 0)
				return ret;
		}
		if (!(second instanceof Comparable))
			return 0;
		else {
			int ret = ((Comparable<V>) second).compareTo(o.second);
			return ret;
		}
	}
}
