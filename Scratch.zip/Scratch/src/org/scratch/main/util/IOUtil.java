package org.scratch.main.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class IOUtil {
	private IOUtil() {
	}

	public static void print(String string, PrintStream... writers) {
		for (PrintStream writer : writers) {
			writer.print(string);
		}
	}

	public static void println(String string, PrintStream... writers) {
		for (PrintStream writer : writers) {
			writer.println(string);
		}
	}
	
	public static<T> String getFileFromClassPath(Class<T> clazz, String path) throws IOException {
		try(InputStream inputStream = clazz.getResourceAsStream(path);
			BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			return reader.lines().reduce("", (s1, s2) -> s1 + s2 + '\n');
		} catch (NullPointerException e) {
			throw new IOException("Unable to find path: " + path, e);
		}
	}
}
