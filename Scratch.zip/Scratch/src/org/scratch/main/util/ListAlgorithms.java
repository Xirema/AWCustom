package org.scratch.main.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class ListAlgorithms {
	private ListAlgorithms() {
	}

	public static <T extends Comparable<T>> boolean isSorted(Collection<T> list) {
		T first = null;
		for (T t : list) {
			if (first != null) {
				if (first.compareTo(t) > 0)
					return false;
			}
			first = t;
		}
		return true;
	}

	public static <T> boolean isSorted(Collection<T> list, Comparator<T> comparator) {
		T first = null;
		for (T t : list) {
			if (first != null) {
				if (comparator.compare(first, t) > 0)
					return false;
			}
			first = t;
		}
		return true;
	}

	public static <T extends Comparable<T>> int selectIndex(List<T> list, int k) {
		if (list.size() <= k)
			throw new IndexOutOfBoundsException();
		int[] indexes = new int[list.size()];
		for (int i = 0; i < indexes.length; i++) {
			indexes[i] = i;
		}
		int from = 0, to = indexes.length - 1;

		while (from < to) {
			int r = from, w = to;
			T mid = list.get(indexes[(r + w) / 2]);

			while (r < w) {
				if (list.get(indexes[r]).compareTo(mid) >= 0) {
					int tmp = indexes[w];
					indexes[w] = indexes[r];
					indexes[r] = tmp;
					w--;
				} else {
					r++;
				}
			}
			if (list.get(indexes[r]).compareTo(mid) > 0) {
				r--;
			}
			if (k <= r) {
				to = r;
			} else {
				from = r + 1;
			}
		}
		return indexes[k];
	}

	public static <T extends Comparable<T>> T select(List<T> list, int k) {
		return list.get(selectIndex(list, k));
	}

	public static <T extends Comparable<T>> int medianIndex(List<T> list) {
		return selectIndex(list, list.size() / 2);
	}

	public static <T extends Comparable<T>> T median(List<T> list) {
		return list.get(medianIndex(list));
	}

	public static List<Integer> getRun(int size) {
		return getRun(1, size);
	}

	public static List<Integer> getRun(int start, int end) {
		ArrayList<Integer> list = new ArrayList<>();
		for (; start <= end; start++) {
			list.add(start);
		}
		return list;
	}

	public static <T> String toString(List<T> list) {
		if (list.size() == 0)
			return "{}";
		StringBuilder ss = new StringBuilder();
		ss.append("{" + list.get(0));
		for (int i = 1; i < list.size(); i++) {
			ss.append(",").append(list.get(i).toString());
		}
		ss.append("}");
		return ss.toString();
	}

	public static <T> boolean allSame(List<T> list) {
		if (list.size() == 0)
			return true;
		T o = list.get(0);
		for (int i = 1; i < list.size(); i++) {
			if (!Objects.equals(o, list.get(i)))
				return false;
		}
		return true;
	}

	public static List<Integer> add(List<Integer> values, int adjustment) {
		List<Integer> list = new ArrayList<>();
		for (int t : values) {
			list.add(t + adjustment);
		}
		return list;
	}

	public static List<Short> add(List<Short> values, short adjustment) {
		List<Short> list = new ArrayList<>();
		for (short t : values) {
			list.add((short) (t + adjustment));
		}
		return list;
	}

	public static List<Float> add(List<Float> values, float adjustment) {
		List<Float> list = new ArrayList<>();
		for (float t : values) {
			list.add(t + adjustment);
		}
		return list;
	}

	public static List<Double> add(List<Double> values, double adjustment) {
		List<Double> list = new ArrayList<>();
		for (double t : values) {
			list.add(t + adjustment);
		}
		return list;
	}

	public static List<Long> add(List<Long> values, long adjustment) {
		List<Long> list = new ArrayList<>();
		for (long t : values) {
			list.add(t + adjustment);
		}
		return list;
	}

	public static <T extends Comparable<T>> Comparator<List<T>> getComparator(Class<T> clazz) {
		return (o1, o2) -> {
			for (int i = 0; i < Math.min(o1.size(), o2.size()); i++) {
				int c = o1.get(i).compareTo(o2.get(i));
				if (c != 0)
					return c;
			}
			return o1.size() - o2.size();
		};
	}

}
