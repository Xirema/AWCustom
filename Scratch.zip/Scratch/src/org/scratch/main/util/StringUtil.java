package org.scratch.main.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.StringWriter;
import java.util.Map;

public class StringUtil {
	private StringUtil() {
	}

	public static int indexOfAny(String s, char[] ch) {
		int minimumIndex = s.length();
		for (char c : ch) {
			int index = s.indexOf(c);
			if (index < minimumIndex && index != -1) {
				minimumIndex = index;
			}
		}
		if (minimumIndex == s.length())
			return -1;
		return minimumIndex;
	}

	public static String toString(InputStream input) throws IOException {
		byte[] bytes = new byte[1_000_000];
		try (StringWriter out = new StringWriter()) {
			int read;
			while ((read = input.read(bytes)) != -1) {
				out.write(new String(bytes, 0, read));
			}
			return out.toString();
		}
	}

	public static <K, V> String toString(Map<K, V> map) {
		ByteArrayOutputStream stream = new ByteArrayOutputStream();
		PrintStream out = new PrintStream(stream);
		for (K key : map.keySet()) {
			out.print(key.toString());
			out.print(": ");
			out.println(map.get(key).toString());
		}
		out.flush();
		return stream.toString();
	}
}
