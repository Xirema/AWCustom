package org.scratch.main.util;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import org.scratch.main.util.functional.MatrixFiller;
import org.scratch.main.util.functional.MatrixForEach;
import org.scratch.main.util.functional.MatrixPredicate;
import org.scratch.main.util.functional.MatrixTransformer;

public class Matrix<T> implements Cloneable, Iterable<T> {
	private T[] contents;
	private int rows, columns;
	@SuppressWarnings("rawtypes")
	public static final MatrixFiller<?> NULL_FILLER = (row, column) -> null;

	public Matrix() {
		this(0, 0);
	}

	@SuppressWarnings("unchecked")
	public Matrix(int rows, int columns) {
		this(rows, columns, (MatrixFiller<T>) NULL_FILLER);
	}

	@SuppressWarnings("unchecked")
	public Matrix(int rows, int columns, boolean doNotFill) {
		this.rows = rows;
		this.columns = columns;
		contents = (T[]) new Object[rows * columns];
	}

	@SuppressWarnings("unchecked")
	public Matrix(int rows, int columns, MatrixFiller<T> filler) {
		this.rows = rows;
		this.columns = columns;
		contents = (T[]) new Object[rows * columns];
		for (int row = 0; row < rows; row++) {
			for (int column = 0; column < columns; column++) {
				contents[flatIndex(row, column)] = filler.fill(row, column);
			}
		}
	}

	public int getRows() {
		return rows;
	}

	public int getColumns() {
		return columns;
	}

	public Pair<Integer, Integer> size() {
		return new Pair<>(rows, columns);
	}

	public int flatSize() {
		return rows * columns;
	}

	public T get(int row, int column) {
		return get(flatIndex(row, column));
	}

	public T get(int flatIndex) {
		return contents[flatIndex];
	}

	public void set(int row, int column, T object) {
		set(flatIndex(row, column), object);
	}

	public void set(int flatIndex, T object) {
		contents[flatIndex] = object;
	}

	public int flatIndex(int row, int column) {
		if (!inBounds(row, column))
			throw new MatrixIndexOutOfBoundsException();
		return flatIndex(row, column, rows, columns);
	}

	private static int flatIndex(int row, int column, int rows, int columns) {
		return row * columns + column;
	}

	public boolean inBounds(int row, int column) {
		return row < rows && row >= 0 && column < columns && column >= 0;
	}

	public static <T> Matrix<T> copyOf(Matrix<T> mat) {
		Matrix<T> newMatrix = new Matrix<>(mat.rows, mat.columns);
		System.arraycopy(mat.contents, 0, newMatrix.contents, 0, mat.flatSize());
		return newMatrix;
	}

	public static class MatrixIndexOutOfBoundsException extends RuntimeException {
		private static final long serialVersionUID = 1L;

		public MatrixIndexOutOfBoundsException() {
			super("Addressed Row or Column was outside the bounds of the Matrix");
		}
	}

	@SuppressWarnings("unchecked")
	public void resize(int newRows, int newColumns) {
		resize(newRows, newColumns, (MatrixFiller<T>) NULL_FILLER);
	}

	public void resize(int newRows, int newColumns, MatrixFiller<T> filler) {
		@SuppressWarnings("unchecked")
		T[] newContents = (T[]) new Object[newRows * newColumns];
		for (int row = 0; row < newRows; row++) {
			for (int column = 0; column < newColumns; column++) {
				if (!inBounds(row, column)) {
					newContents[flatIndex(row, column, newRows, newColumns)] = filler.fill(row, column);
				}
			}
		}
		if (columns == newColumns) {
			System.arraycopy(contents, 0, newContents, 0, Math.min(contents.length, newContents.length));
		} else {
			for (int row = 0; row < Math.min(rows, newRows); row++) {
				int minColumns = Math.min(columns, newColumns);
				int newIndex = flatIndex(row, 0, newRows, newColumns);
				int oldIndex = flatIndex(row, 0, rows, columns);
				System.arraycopy(contents, oldIndex, newContents, newIndex, minColumns);
			}
		}
		contents = newContents;
		rows = newRows;
		columns = newColumns;
	}

	@Override
	public Iterator<T> iterator() {
		return ArrayIterator.of(contents);
	}

	public Collection<T> asCollection() {
		return Arrays.asList(contents);
	}

	public List<T> asList() {
		return Collections.unmodifiableList(Arrays.asList(contents));
	}

	public Matrix<T> transpose() {
		return new Matrix<>(this.columns, this.rows, (row, column) -> get(column, row));
	}

	public <U> Matrix<U> transform(final MatrixTransformer<T, U> transformer) {
		final Matrix<U> matrix = new Matrix<>(rows, columns);
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				matrix.set(row, column, transformer.transform(row, column, get(row, column)));
			}
		});
		return matrix;
	}

	public void fill(final MatrixFiller<T> filler) {
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				set(row, column, filler.fill(row, column));
			}
		});
	}

	public boolean none(final MatrixPredicate<T> tester) {
		final boolean[] ret = new boolean[] { true };
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				if (tester.test(row, column, get(row, column))) {
					ret[0] = false;
					cancel();
				}
			}
		});
		return ret[0];
	}

	public boolean any(final MatrixPredicate<T> tester) {
		final boolean[] ret = new boolean[] { false };
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				if (tester.test(row, column, get(row, column))) {
					ret[0] = true;
					cancel();
				}
			}
		});
		return ret[0];
	}

	public boolean all(final MatrixPredicate<T> tester) {
		final boolean[] ret = new boolean[] { true };
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				if (!tester.test(row, column, get(row, column))) {
					ret[0] = false;
					cancel();
				}
			}
		});
		return ret[0];
	}

	public boolean one(final MatrixPredicate<T> tester) {
		final boolean[] ret = new boolean[] { false };
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				if (tester.test(row, column, get(row, column)) && !ret[0]) {
					ret[0] = true;
				} else if (tester.test(row, column, get(row, column)) && ret[0]) {
					ret[0] = false;
					cancel();
				}
			}
		});
		return ret[0];
	}

	public int count(final MatrixPredicate<T> tester) {
		final int[] ret = new int[] { 0 };
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				if (tester.test(row, column, get(row, column))) {
					ret[0]++;
				}
			}
		});
		return ret[0];
	}

	public void forEach(final MatrixForEach<T> forEach) {
		forEachImpl(new MatrixForEachAccessor() {
			@Override
			public void apply(int row, int column) {
				forEach.apply(row, column, get(row, column));
			}
		});
	}

	private void forEachImpl(MatrixForEachAccessor accessor) {
		for (int row = 0; row < rows && !accessor.isCancelled(); row++) {
			for (int column = 0; column < columns && !accessor.isCancelled(); column++) {
				accessor.apply(row, column);
			}
		}
	}

	private static abstract class MatrixForEachAccessor {
		abstract void apply(int row, int column);

		private boolean cancelled = false;

		void cancel() {
			cancelled = true;
		}

		boolean isCancelled() {
			return cancelled;
		}
	}
}
