package org.scratch.main.util;
/**
 * Shamelessly stolen from https://introcs.cs.princeton.edu/java/92symbolic/BigRational.java.html
 */

//import java.math.BigDecimal;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
//import java.math.RoundingMode;
import java.util.Objects;

public class BigRational implements Comparable<BigRational> {
	public final static BigRational ZERO = new BigRational(0);
	public final static BigRational ONE = new BigRational(1);
	public final static BigRational TWO = new BigRational(2);

	public final BigInteger num; // the numerator
	public final BigInteger den; // the denominator (always a positive integer)

	// create and initialize a new BigRational object
	public BigRational(int numerator, int denominator) {
		this(BigInteger.valueOf(numerator), BigInteger.valueOf(denominator));
	}

	// create and initialize a new BigRational object
	public BigRational(int numerator) {
		this(numerator, 1);
	}

	// create and initialize a new BigRational object from a string, e.g.,
	// "-343/1273"
	public static BigRational from(String s) {
		String[] tokens = s.split("/");
		if (tokens.length == 2)
			return new BigRational(new BigInteger(tokens[0]), new BigInteger(tokens[1]));
		else if (tokens.length == 1)
			return new BigRational(new BigInteger(tokens[0]), BigInteger.ONE);
		else
			throw new IllegalArgumentException("For input string: \"" + s + "\"");

	}

	// create and initialize a new BigRational object
	public BigRational(BigInteger numerator, BigInteger denominator) {

		// deal with x / 0
		if (denominator.equals(BigInteger.ZERO))
			throw new ArithmeticException("Denominator is zero");

		// reduce fraction (if num = 0, will always yield den = 0)
		BigInteger g = numerator.gcd(denominator);
		BigInteger tempnum = numerator.divide(g);
		BigInteger tempden = denominator.divide(g);

		// to ensure invariant that denominator is positive
		if (tempden.compareTo(BigInteger.ZERO) < 0) {
			tempden = tempden.negate();
			tempnum = tempnum.negate();
		}
		den = tempden;
		num = tempnum;
	}
	
	public static BigRational from(double value) {
		boolean wasNegative = value < 0;
		value = Math.abs(value);
		
		long exponent = Math.getExponent(value);
		long mantissa = Double.doubleToRawLongBits(value) & 0x000FFFFFFFFFFFFFL;
		BigInteger numerator;
		if(value < Double.MIN_NORMAL && value >= Double.MIN_VALUE)
			numerator = BigInteger.valueOf(mantissa);
		else
			numerator = BigInteger.valueOf(mantissa | 0x0010_0000_0000_0000L);
		BigInteger denominator = BigInteger.valueOf(2);

		if(value < Double.MIN_NORMAL && value >= Double.MIN_VALUE)
			denominator = denominator.pow((int)-exponent + 51);
		else
			denominator = denominator.pow((int)-exponent + 52);
		if(wasNegative)
			numerator = numerator.negate();
		return new BigRational(numerator, denominator);
	}

	// return string representation of (this)
	@Override
	public String toString() {
		if (den.equals(BigInteger.ONE))
			return num + "";
		else
			return num + "/" + den;
	}

	// return { -1, 0, + 1 } if a < b, a = b, or a > b
	@Override
	public int compareTo(BigRational b) {
		BigRational a = this;
		return a.num.multiply(b.den).compareTo(a.den.multiply(b.num));
	}

	// is this BigRational negative, zero, or positive?
	public boolean isZero() {
		return num.signum() == 0;
	}

	public boolean isPositive() {
		return num.signum() > 0;
	}

	public boolean isNegative() {
		return num.signum() < 0;
	}

	// is this Rational object equal to y?
	@Override
	public boolean equals(Object y) {
		if (y == this)
			return true;
		if (y == null)
			return false;
		if (y.getClass() != this.getClass())
			return false;
		BigRational b = (BigRational) y;
		return compareTo(b) == 0;
	}

	// hashCode consistent with equals() and compareTo()
	@Override
	public int hashCode() {
		return Objects.hash(num, den);
	}

	// return a * b
	public BigRational times(BigRational b) {
		BigRational a = this;
		return new BigRational(a.num.multiply(b.num), a.den.multiply(b.den));
	}

	// return a + b
	public BigRational plus(BigRational b) {
		BigRational a = this;
		BigInteger numerator = a.num.multiply(b.den).add(b.num.multiply(a.den));
		BigInteger denominator = a.den.multiply(b.den);
		return new BigRational(numerator, denominator);
	}

	// return -a
	public BigRational negate() {
		return new BigRational(num.negate(), den);
	}

	// return |a|
	public BigRational abs() {
		if (isNegative())
			return negate();
		else
			return this;
	}

	// return a - b
	public BigRational minus(BigRational b) {
		BigRational a = this;
		return a.plus(b.negate());
	}

	// return 1 / a
	public BigRational reciprocal() {
		return new BigRational(den, num);
	}

	// return a / b
	public BigRational divides(BigRational b) {
		BigRational a = this;
		return a.times(b.reciprocal());
	}

	// return double reprentation (within given precision)
	public double doubleValue() {
//		 int SCALE = Math.max(num.bitLength(), den.bitLength()) * 100 / 332; // number of digits after the decimal place
//		 BigDecimal numerator = new BigDecimal(num);
//		 BigDecimal denominator = new BigDecimal(den);
//		 BigDecimal quotient = numerator.divide(denominator, SCALE,
//		 RoundingMode.HALF_EVEN);
//		 System.out.println(quotient);
//		 return quotient.doubleValue();
//		double numdouble = num.doubleValue(), dendouble = den.doubleValue();
//		System.out.printf("0x%016X-0x%016X\n", Double.doubleToRawLongBits(numdouble), Double.doubleToRawLongBits(dendouble));
//		System.out.printf("%g-%g\n", numdouble, dendouble);
		return num.doubleValue() / den.doubleValue();
	}

	public BigDecimal decimalValue() {
		BigDecimal numerator = new BigDecimal(num);
		BigDecimal denominator = new BigDecimal(den);
		return numerator.divide(denominator);
	}

	public static BigRational valueOf(int i) {
		return new BigRational(i);
	}

	public BigRational divides(int size) {
		return divides(new BigRational(size));
	}
}
