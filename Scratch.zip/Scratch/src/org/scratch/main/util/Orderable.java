package org.scratch.main.util;

public interface Orderable {
	int getOrder();
}
