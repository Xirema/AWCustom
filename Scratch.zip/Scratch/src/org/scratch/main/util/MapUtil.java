package org.scratch.main.util;

import java.util.Map;

public class MapUtil {
	private MapUtil() {
	}

	public static <K> void add(Map<K, Integer> map, K key, int value) {
		Integer ret = map.get(key);
		if (ret == null) {
			ret = 0;
		}
		ret += value;
		map.put(key, ret);
	}

	public static <K> void increment(Map<K, Integer> map, K key) {
		add(map, key, 1);
	}
	// public static<K, V extends Numeric> void add(Map<K, V> map, K key, V
	// number) {
	//
	// }
}
