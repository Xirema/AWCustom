package org.scratch.main.util;

import java.util.Objects;

public class Coordinate {
	public final double x, y;

	public Coordinate() {
		this(0, 0);
	}

	public Coordinate(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public static Coordinate of(double x, double y) {
		return new Coordinate(x, y);
	}

	public static Coordinate copyOf(Coordinate coord) {
		return of(coord.x, coord.y);
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof Coordinate))
			return false;
		Coordinate c = (Coordinate) o;
		return x == c.x && y == c.y;
	}

	@Override
	public int hashCode() {
		return Objects.hash(x, y);
	}
}
