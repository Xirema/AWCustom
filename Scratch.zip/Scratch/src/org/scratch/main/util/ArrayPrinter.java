package org.scratch.main.util;

public class ArrayPrinter {
	public static <T> String toString(T[] array) {
		StringBuilder out = new StringBuilder();
		out.append('[');
		for (T o : array) {
			out.append(o.toString()).append(',');
		}
		if (array.length > 0) {
			out.delete(out.length() - 1, out.length());
		}
		out.append(']');
		return out.toString();
	}

	public static String toString(int[] array) {
		StringBuilder out = new StringBuilder();
		out.append('[');
		for (int o : array) {
			out.append(o).append(',');
		}
		if (array.length > 0) {
			out.delete(out.length() - 1, out.length());
		}
		out.append(']');
		return out.toString();
	}

	public static String toString(byte[] array) {
		StringBuilder out = new StringBuilder();
		out.append('[');
		for (byte o : array) {
			out.append(o).append(',');
		}
		if (array.length > 0) {
			out.delete(out.length() - 1, out.length());
		}
		out.append(']');
		return out.toString();
	}

	public static String toString(char[] array) {
		StringBuilder out = new StringBuilder();
		out.append('[');
		for (char o : array) {
			out.append("\'" + o + "\'").append(',');
		}
		if (array.length > 0) {
			out.delete(out.length() - 1, out.length());
		}
		out.append(']');
		return out.toString();
	}
}
