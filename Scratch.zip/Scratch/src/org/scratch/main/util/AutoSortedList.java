package org.scratch.main.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.RandomAccess;

public class AutoSortedList<E extends Comparable<E>> implements Collection<E>, RandomAccess {
	private ArrayList<E> list;

	@SafeVarargs
	public static <E extends Comparable<E>> AutoSortedList<E> of(E... items) {
		AutoSortedList<E> list = new AutoSortedList<>();
		for (E e : items) {
			list.add(e);
		}
		return list;
	}

	public static <E extends Comparable<E>> AutoSortedList<E> copyOf(AutoSortedList<E> list) {
		AutoSortedList<E> newList = new AutoSortedList<>();
		newList.addAll(list);
		return newList;
	}

	public AutoSortedList(Collection<? extends E> coll) {
		this();
		addAll(coll);
	}

	public AutoSortedList() {
		list = new ArrayList<>();
	}

	public E get(int index) {
		return list.get(index);
	}

	public int indexOf(E e) {
		return list.indexOf(e);
	}

	public E remove(int index) {
		return list.remove(index);
	}

	@Override
	public int size() {
		return list.size();
	}

	@Override
	public boolean isEmpty() {
		return list.isEmpty();
	}

	@Override
	public boolean contains(Object o) {
		return list.contains(o);
	}

	@Override
	public Iterator<E> iterator() {
		return asList().iterator();
	}

	@Override
	public Object[] toArray() {
		return asList().toArray();
	}

	@Override
	public <T> T[] toArray(T[] a) {
		return asList().toArray(a);
	}

	public List<E> asList() {
		return Collections.unmodifiableList(list);
	}

	@Override
	public boolean add(E e) {
		int index = Collections.binarySearch(list, e);
		if (index < 0) {
			index++;
		}
		list.add(Math.abs(index), e);
		return true;
	}

	@Override
	public boolean remove(Object o) {
		return list.remove(o);
	}

	@Override
	public boolean containsAll(Collection<?> c) {
		return list.containsAll(c);
	}

	@Override
	public boolean addAll(Collection<? extends E> c) {
		reserve(size() + c.size());
		for (E o : c) {
			add(o);
		}
		return true;
	}

	@Override
	public boolean removeAll(Collection<?> c) {
		return list.removeAll(c);
	}

	@Override
	public boolean retainAll(Collection<?> c) {
		return list.retainAll(c);
	}

	@Override
	public void clear() {
		list.clear();
	}

	public void reserve(int size) {
		list.ensureCapacity(size);
	}

	@Override
	public String toString() {
		StringBuilder ss = new StringBuilder();
		ss.append('{');
		for (E e : list) {
			ss.append(e.toString());
			ss.append(", ");
		}
		ss.delete(ss.length() - 2, ss.length());
		ss.append('}');
		return ss.toString();
	}
}
