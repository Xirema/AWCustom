package org.scratch.main.util;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;

public class SingletonFunctor<T> {
	private Object monitor = new Object();

	private enum State {
		UNINITIALIZED, RUNNING, COMPLETE
	}

	private State state = State.UNINITIALIZED;
	private Callable<T> functor;
	private T result = null;
	private Exception exception;
	private Thread evaluator;

	public SingletonFunctor(Callable<T> functor) {
		this.functor = functor;
		evaluator = new Thread(() -> {
			try {
				result = SingletonFunctor.this.functor.call();
			} catch (Exception e) {
				exception = e;
			}
			synchronized (monitor) {
				state = State.COMPLETE;
				monitor.notifyAll();
			}
		});
		evaluator.setDaemon(true);
		evaluator.start();
	}

	public T get() throws InterruptedException, ExecutionException {
		synchronized (monitor) {
			if (state != State.COMPLETE) {
				monitor.wait();
			}
		}
		if (result == null) {
			if (exception != null)
				throw new ExecutionException(exception);
		}
		return result;
	}
}
