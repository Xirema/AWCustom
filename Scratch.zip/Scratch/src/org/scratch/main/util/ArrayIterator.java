package org.scratch.main.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ArrayIterator<T> implements Iterator<T> {
	private T[] array;
	private int index;

	public static <T> ArrayIterator<T> of(T[] arr) {
		return new ArrayIterator<>(arr);
	}

	public ArrayIterator(T[] arr) {
		index = 0;
		array = arr;
	}

	@Override
	public boolean hasNext() {
		return index < array.length;
	}

	@Override
	public T next() {
		if (!hasNext())
			throw new NoSuchElementException("Reached the end of the Array");
		return array[index++];
	}

	@Override
	public void remove() {
		throw new UnsupportedOperationException("Cannot remove elements from an array");
	}

}
