package org.scratch.main.ms.main;

import org.scratch.main.ms.controller.MSController;

public class MSMain {
	public static void main(String[] args) throws InterruptedException {
		MSController controller = new MSController();
		controller.mainLoop();
	}
}
