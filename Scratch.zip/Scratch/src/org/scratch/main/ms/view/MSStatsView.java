package org.scratch.main.ms.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.scratch.main.ms.model.MSBoard;
import org.scratch.main.ms.view.organization.MSModelable;

public class MSStatsView extends JPanel implements MSModelable {
	private static final long serialVersionUID = 1L;
	private MSBoard board;
	private GridBagLayout layout;
	private JLabel remainingMinesLabel;
	private JTextField remainingMinesField;

	public MSStatsView() {
		setLayout(layout = new GridBagLayout());
		remainingMinesLabel = new JLabel("Remaining Mines: ");
		remainingMinesField = new JTextField();
		updateFontSize(20.f, remainingMinesLabel);
		updateFontSize(20.f, remainingMinesField);
		remainingMinesField.setBackground(Color.BLACK);
		remainingMinesField.setForeground(Color.WHITE);
		remainingMinesField.setEditable(false);
		layout.columnWeights = new double[] { 0.9 };
		add(remainingMinesLabel, getLabelConstraints());
		add(remainingMinesField, getFieldConstraints());
		remainingMinesField.setColumns(3);
		remainingMinesField.setHorizontalAlignment(SwingConstants.CENTER);
		remainingMinesField.setMargin(new Insets(0, 0, 0, 0));
	}

	private static GridBagConstraints getFieldConstraints() {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = 1;
		constraints.gridy = 0;
		constraints.gridheight = constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.WEST;
		constraints.fill = GridBagConstraints.BOTH;
		return constraints;
	}

	private static GridBagConstraints getLabelConstraints() {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.gridheight = constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.EAST;
		constraints.fill = GridBagConstraints.NONE;
		return constraints;
	}

	@Override
	public void applyModel(MSBoard board) {
		this.board = board;
	}

	private void updateFontSize(float size, JComponent component) {
		Font f = component.getFont();
		f = f.deriveFont(20.f);
		component.setFont(f);
	}

	@Override
	public void refresh() {
		remainingMinesField.setText("" + board.calculateUnrevealedMines());
	}

}
