package org.scratch.main.ms.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;

import org.scratch.main.ms.model.MSBoard;
import org.scratch.main.ms.model.Tile;
import org.scratch.main.ms.view.MSGridView.MSGridListener.ClickType;
import org.scratch.main.ms.view.organization.MSModelable;
import org.scratch.main.util.Matrix;
import org.scratch.main.util.Pair;
import org.scratch.main.util.functional.MatrixForEach;

public class MSGridView extends JPanel implements MSModelable {
	private static final long serialVersionUID = 1L;
	private GridBagLayout layout;
	private Matrix<JLabel> tiles;
	private MSBoard board;
	private MSGridListener gridListener;

	private static final Color[] neighborColors = { Color.BLUE.darker(), Color.RED.darker(), Color.GREEN.darker(),
			Color.YELLOW.darker(), Color.MAGENTA.darker(), Color.CYAN.darker(), Color.GRAY.darker(),
			Color.ORANGE.darker() };
	private static final int BUTTON_DIM_SIZE = 20;
	private static final float FONT_SIZE = 16;
	private static final Dimension BUTTON_SIZE = new Dimension(BUTTON_DIM_SIZE, BUTTON_DIM_SIZE);

	public MSGridView() {
		setLayout(layout = new GridBagLayout());
		tiles = new Matrix<>();
	}

	@Override
	public void applyModel(MSBoard board) {
		this.board = board;
	}

	private void handleNewBoardSize() {
		removeAll();
		Pair<Integer, Integer> size = board.getSize();
		tiles.resize(size.first, size.second);
		layout.rowHeights = getSizes(size.first);
		layout.columnWidths = getSizes(size.second);
		tiles.fill((row, column) -> {
			JLabel jTile = new JLabel();
			jTile.setPreferredSize(BUTTON_SIZE);
			Font f = jTile.getFont();
			f = f.deriveFont(FONT_SIZE);
			jTile.setFont(f);
			jTile.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			jTile.setHorizontalAlignment(SwingConstants.CENTER);
			jTile.addMouseListener(new MSGridListenerImpl(row, column, gridListener));
			jTile.setOpaque(true);
			MSGridView.this.add(jTile, getConstraints(row, column));
			return jTile;
		});
	}

	private GridBagConstraints getConstraints(int row, int column) {
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridx = column;
		constraints.gridy = row;
		constraints.gridheight = constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.CENTER;
		constraints.fill = GridBagConstraints.BOTH;
		return constraints;
	}

	private static int[] getSizes(int num) {
		int[] sizes = new int[num];
		for (int i = 0; i < num; i++) {
			sizes[i] = BUTTON_DIM_SIZE;
		}
		return sizes;
	}

	private void updateTiles() {
		final boolean hasWon = board.isWon();
		final boolean hasLost = board.isLost();
		tiles.forEach((MatrixForEach<JLabel>) (row, column, jTile) -> {
			Tile tile = board.getTile(row, column);
			if (tile.hasMine()) {
				if (hasLost) {
					jTile.setBackground(Color.RED.darker());
				} else if (board.getOptions().enableCheating) {
					jTile.setBackground(Color.MAGENTA.brighter());
				} else if (hasWon) {
					jTile.setBackground(new Color(170, 255, 210));
				} else {
					jTile.setBackground(new Color(210, 240, 255));
				}
			} else if (tile.isExplored()) {
				jTile.setBackground(Color.WHITE);
			} else {
				jTile.setBackground(new Color(210, 240, 255));
			}
			if (tile.isExplored() && !tile.hasMine()) {
				jTile.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
				if (tile.neighborCount != 0) {
					jTile.setText("" + tile.neighborCount);
					jTile.setForeground(neighborColors[tile.neighborCount - 1]);
				} else {
					jTile.setText("");
				}
			} else {
				jTile.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
				jTile.setForeground(new Color(110, 70, 0));
				if (tile.flag == Tile.Flag.MARKED) {
					jTile.setText("F");
				} else if (tile.flag == Tile.Flag.UNSURE) {
					jTile.setText("?");
				} else {
					jTile.setText("");
				}
			}
		});
	}

	@Override
	public void refresh() {
		if (!tiles.size().equals(board.getSize())) {
			handleNewBoardSize();
		}
		updateTiles();
		repaint();
	}

	public void attachListener(final MSGridListener listener) {
		this.gridListener = listener;
		tiles.forEach((MatrixForEach<JLabel>) (row, column, jTile) -> jTile
				.addMouseListener(new MSGridListenerImpl(row, column, listener)));
	}

	public static interface MSGridListener {
		public enum ClickType {
			PRIMARY, SECONDARY, MIDDLE
		}

		void handleButton(ClickType clickType, int row, int column);
	}

	private static class MSGridListenerImpl extends MouseAdapter {
		private static Map<ClickType, Boolean> pressed = new HashMap<>();
		private int row, column;
		private MSGridListener listener;

		public MSGridListenerImpl(int row, int column, MSGridListener listener) {
			this.row = row;
			this.column = column;
			this.listener = listener;
		}

		@Override
		public void mousePressed(MouseEvent e) {
			pressed.put(getClickType(e), true);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			Boolean primary = pressed.get(ClickType.PRIMARY);
			Boolean secondary = pressed.get(ClickType.SECONDARY);
			if (primary != null && primary && secondary != null && secondary) {
				listener.handleButton(ClickType.MIDDLE, row, column);
				pressed.put(ClickType.PRIMARY, false);
				pressed.put(ClickType.SECONDARY, false);
			} else {
				if (pressed.get(getClickType(e))) {
					listener.handleButton(getClickType(e), row, column);
				}
				pressed.put(getClickType(e), false);
			}

		}

		private static MSGridListener.ClickType getClickType(MouseEvent e) {
			if (SwingUtilities.isLeftMouseButton(e))
				return MSGridListener.ClickType.PRIMARY;
			if (SwingUtilities.isRightMouseButton(e))
				return MSGridListener.ClickType.SECONDARY;
			if (SwingUtilities.isMiddleMouseButton(e))
				return MSGridListener.ClickType.MIDDLE;
			return null;
		}

		@Override
		public void mouseExited(MouseEvent e) {
			// pressed = false;
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// pressed = true;
		}
	}
}
