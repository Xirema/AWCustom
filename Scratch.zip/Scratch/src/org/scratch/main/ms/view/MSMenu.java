package org.scratch.main.ms.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

public class MSMenu extends JMenuBar {
	private static final long serialVersionUID = 1L;

	private static final String NEW_GAME_ACTION_COMMAND = "NEW";
	private static final String QUIT_ACTION_COMMAND = "QUIT";
	private static final String ABOUT_ACTION_COMMAND = "ABOUT";

	private JMenu fileMenu;
	private JMenuItem newGameButton;
	private JMenuItem quitButton;

	private JMenu helpMenu;
	private JMenuItem aboutButton;

	public MSMenu() {
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		newGameButton = new JMenuItem("New Game...");
		newGameButton.setMnemonic('N');
		newGameButton.setActionCommand(NEW_GAME_ACTION_COMMAND);
		quitButton = new JMenuItem("Quid");
		quitButton.setMnemonic('Q');
		quitButton.setActionCommand(QUIT_ACTION_COMMAND);
		helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');
		aboutButton = new JMenuItem("About");
		aboutButton.setMnemonic('A');
		aboutButton.setActionCommand(ABOUT_ACTION_COMMAND);

		fileMenu.add(newGameButton);
		fileMenu.add(new JSeparator());
		fileMenu.add(quitButton);
		helpMenu.add(aboutButton);

		add(fileMenu);
		add(helpMenu);
	}

	public void attachMenuListener(MSMenuListener listener) {
		newGameButton.addActionListener(listener);
		quitButton.addActionListener(listener);
		aboutButton.addActionListener(listener);
	}

	public static abstract class MSMenuListener implements ActionListener {
		public abstract void handleNewGameCommand();

		public abstract void handleQuitCommand();

		public abstract void handleAboutCommand();

		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			switch (command) {
			case NEW_GAME_ACTION_COMMAND:
				handleNewGameCommand();
				break;
			case QUIT_ACTION_COMMAND:
				handleQuitCommand();
				break;
			case ABOUT_ACTION_COMMAND:
				handleAboutCommand();
				break;
			}
		}
	}
}
