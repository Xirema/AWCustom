package org.scratch.main.ms.view.organization;

import org.scratch.main.ms.model.MSBoard;

public interface MSModelable {
	void applyModel(MSBoard board);

	void refresh();
}
