package org.scratch.main.ms.view;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import org.scratch.main.ms.model.MSBoard;
import org.scratch.main.ms.view.MSGridView.MSGridListener;
import org.scratch.main.ms.view.MSMenu.MSMenuListener;
import org.scratch.main.ms.view.organization.MSModelable;

public class MSFrame extends JFrame implements MSModelable {
	private static final long serialVersionUID = 1L;

	private MSBoardView boardView;
	private MSMenu menu;
	@SuppressWarnings("unused")
	private MSBoard board;

	public MSFrame() {
		boardView = new MSBoardView();
		setContentPane(boardView);
		setTitle("MS");
		menu = new MSMenu();
		setJMenuBar(menu);
		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		setResizable(false);
	}

	@Override
	public void applyModel(MSBoard board) {
		this.board = board;
		boardView.applyModel(board);
	}

	public void attachMenuListener(MSMenuListener listener) {
		menu.attachMenuListener(listener);
	}

	public void attachGridViewListener(MSGridListener listener) {
		boardView.attachGridViewListener(listener);
	}

	@Override
	public void refresh() {
		boardView.refresh();
		pack();
		// menu.refresh();
	}
}
