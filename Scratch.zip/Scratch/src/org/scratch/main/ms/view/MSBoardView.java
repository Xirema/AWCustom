package org.scratch.main.ms.view;

import java.awt.BorderLayout;

import javax.swing.JPanel;

import org.scratch.main.ms.model.MSBoard;
import org.scratch.main.ms.view.MSGridView.MSGridListener;
import org.scratch.main.ms.view.organization.MSModelable;

public class MSBoardView extends JPanel implements MSModelable {
	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private MSBoard board;
	private BorderLayout layout;
	private MSStatsView statsView;
	private MSGridView gridView;

	public MSBoardView() {
		setLayout(layout = new BorderLayout());
		layout.setVgap(2);
		add(statsView = new MSStatsView(), BorderLayout.NORTH);
		add(gridView = new MSGridView(), BorderLayout.CENTER);
	}

	@Override
	public void applyModel(MSBoard board) {
		statsView.applyModel(board);
		gridView.applyModel(board);
		this.board = board;
	}

	@Override
	public void refresh() {
		statsView.refresh();
		gridView.refresh();
	}

	public void attachGridViewListener(MSGridListener listener) {
		gridView.attachListener(listener);
	}
}
