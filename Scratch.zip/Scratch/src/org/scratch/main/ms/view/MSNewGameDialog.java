package org.scratch.main.ms.view;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.scratch.main.ms.model.MSOptions;
import org.scratch.main.util.Pair;

public class MSNewGameDialog extends JPanel {
	private static final long serialVersionUID = 1L;

	private static final Pair<boolean[], MSOptions> EASY_OPTIONS = Pair
			.of(new boolean[] { false, false, false, false, false }, MSOptions.EASY);
	private static final Pair<boolean[], MSOptions> INTERMEDIATE_OPTIONS = Pair
			.of(new boolean[] { false, false, false, false, false }, MSOptions.INTERMEDIATE);
	private static final Pair<boolean[], MSOptions> ADVANCED_OPTIONS = Pair
			.of(new boolean[] { false, false, false, false, false }, MSOptions.ADVANCED);
	private static final Pair<boolean[], MSOptions> EXPERT_OPTIONS = Pair
			.of(new boolean[] { false, false, false, false, false }, MSOptions.EXPERT);

	private JPanel regularOptions;
	private JPanel extraOptions;
	private GridBagLayout regularLayout;
	private GridBagLayout extraLayout;
	private GridBagLayout layout;

	private JRadioButton easyGameButton;
	private JRadioButton intermediateGameButton;
	private JRadioButton advancedGameButton;
	private JRadioButton expertGameButton;
	private JRadioButton customGameButton;
	private ButtonGroup buttonGroup;

	private JTextField rowsField;
	private JTextField columnsField;
	private JTextField minesField;

	private JCheckBox safeFirstTurnButton;
	private JCheckBox enableCheatingButton;

	private JButton okButton;
	private JButton cancelButton;
	private OptionsListener okButtonListener;
	private JDialog dialog;

	public MSNewGameDialog(JFrame parent, OptionsListener okButtonListener) {
		regularOptions = new JPanel();
		regularLayout = new GridBagLayout();
		regularLayout.columnWeights = new double[] { 0.3, 0.7 };
		regularOptions.setLayout(regularLayout);
		regularOptions.add(new JLabel("Difficulty"), getConstraints(0, 0));
		regularOptions.add(easyGameButton = new JRadioButton("Easy"), getConstraints(1, 0));
		regularOptions.add(intermediateGameButton = new JRadioButton("Intermediate"), getConstraints(2, 0));
		regularOptions.add(advancedGameButton = new JRadioButton("Advanced"), getConstraints(3, 0));
		regularOptions.add(expertGameButton = new JRadioButton("Expert"), getConstraints(4, 0));
		regularOptions.add(customGameButton = new JRadioButton("Custom"), getConstraints(5, 0));
		buttonGroup = new ButtonGroup();
		buttonGroup.add(easyGameButton);
		buttonGroup.add(intermediateGameButton);
		buttonGroup.add(advancedGameButton);
		buttonGroup.add(expertGameButton);
		buttonGroup.add(customGameButton);

		regularOptions.add(new JSeparator(SwingConstants.HORIZONTAL), getConstraints(6, 0, 1, 2));
		regularOptions.add(new JLabel("Rows"), getConstraints(7, 0));
		regularOptions.add(rowsField = new JTextField(""), getConstraints(7, 1));
		rowsField.setColumns(4);
		regularOptions.add(new JLabel("Columns"), getConstraints(8, 0));
		regularOptions.add(columnsField = new JTextField(""), getConstraints(8, 1));
		columnsField.setColumns(4);
		regularOptions.add(new JLabel("Mines"), getConstraints(9, 0));
		regularOptions.add(minesField = new JTextField(""), getConstraints(9, 1));
		minesField.setColumns(4);

		extraOptions = new JPanel();
		extraLayout = new GridBagLayout();
		extraLayout.columnWeights = new double[] { 0.3, 0.7 };
		extraOptions.setLayout(extraLayout);
		extraOptions.add(new JLabel("MISC Options"), getConstraints(0, 0));
		extraOptions.add(safeFirstTurnButton = new JCheckBox("Always Safe First Click"), getConstraints(1, 0));
		extraOptions.add(enableCheatingButton = new JCheckBox("Cheating Enabled"), getConstraints(2, 0));
		layout = new GridBagLayout();
		setLayout(layout);
		add(regularOptions, getConstraints(0, 0));
		add(extraOptions, getConstraints(0, 1));
		add(new JSeparator(SwingConstants.HORIZONTAL), getConstraints(2, 0, 1, 2));
		add(okButton = new JButton("OK"), getConstraints(3, 0));
		add(cancelButton = new JButton("Cancel"), getConstraints(3, 1));
		regularOptions.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));
		extraOptions.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.LOWERED));

		this.okButtonListener = okButtonListener;
		setupBehaviors();
		advancedGameButton.setSelected(true);

		show(parent);
	}

	private GridBagConstraints getConstraints(int row, int column, int rows, int columns) {
		return new GridBagConstraints(column, row, columns, rows, 1.0, 1.0, GridBagConstraints.NORTHWEST,
				GridBagConstraints.NONE, new Insets(2, 2, 2, 2), 0, 0);
	}

	private GridBagConstraints getConstraints(int row, int column) {
		return getConstraints(row, column, 1, 1);
	}

	private JDialog show(JFrame parent) {
		dialog = new JDialog(parent, "New Game", true);
		dialog.setContentPane(this);
		dialog.pack();
		dialog.setLocationRelativeTo(parent);
		dialog.setVisible(true);
		return dialog;
	}

	public MSOptions getOptions() {
		return new MSOptions(Integer.parseInt(rowsField.getText()), Integer.parseInt(columnsField.getText()),
				Integer.parseInt(minesField.getText()), enableCheatingButton.isSelected(),
				safeFirstTurnButton.isSelected());
	}

	private void applyOptions(MSOptions options) {
		rowsField.setText("" + options.rows);
		columnsField.setText("" + options.columns);
		minesField.setText("" + options.mines);
		safeFirstTurnButton.setSelected(options.safeFirstPick);
		enableCheatingButton.setSelected(options.enableCheating);
	}

	private void setFieldsEnabled(boolean[] arr) {
		rowsField.setEnabled(arr[0]);
		columnsField.setEnabled(arr[1]);
		minesField.setEnabled(arr[2]);
		safeFirstTurnButton.setEnabled(arr[3]);
		enableCheatingButton.setEnabled(arr[4]);
	}

	private void setupBehaviors() {
		easyGameButton.addChangeListener(new Listener(EASY_OPTIONS));
		intermediateGameButton.addChangeListener(new Listener(INTERMEDIATE_OPTIONS));
		advancedGameButton.addChangeListener(new Listener(ADVANCED_OPTIONS));
		expertGameButton.addChangeListener(new Listener(EXPERT_OPTIONS));
		customGameButton.addChangeListener(
				new Listener(Pair.of(new boolean[] { true, true, true, true, true }, MSOptions.EXPERT)));
		cancelButton.addActionListener(e -> dialog.dispose());
		okButton.addActionListener(e -> {
			okButtonListener.handleOptions(getOptions());
			dialog.dispose();
		});
	}

	private class Listener implements ChangeListener {
		private Pair<boolean[], MSOptions> settings;

		public Listener(Pair<boolean[], MSOptions> settings) {
			this.settings = settings;
		}

		@Override
		public void stateChanged(ChangeEvent e) {
			if (((JRadioButton) e.getSource()).isSelected()) {
				applyOptions(settings.second);
				setFieldsEnabled(settings.first);
			}
		}
	}

	public static interface OptionsListener {
		void handleOptions(MSOptions options);
	}
}
