package org.scratch.main.ms.model.strategies;

import java.util.Random;

public class DensityStrategy implements BoardGenerationStrategy {
	private final double density;
	private final Random rand;

	public DensityStrategy(double density) {
		this.density = density;
		rand = new Random();
	}

	@Override
	public boolean willPlaceMine(int row, int column) {
		return rand.nextDouble() < density;
	}

	@Override
	public void reset() {
	}

}
