package org.scratch.main.ms.model;

import org.scratch.main.ms.model.strategies.BoardGenerationStrategy;
import org.scratch.main.ms.model.strategies.DistributionStrategy;
import org.scratch.main.util.Pair;

public class MSOptions {
	public final int rows, columns, mines;
	public final boolean enableCheating, safeFirstPick;

	public MSOptions() {
		this(18, 30, 99, false, true);
	}

	public MSOptions(int rows, int columns, int mines, boolean enableCheating, boolean safeFirstPick) {
		this.rows = rows;
		this.columns = columns;
		this.mines = mines;
		this.enableCheating = enableCheating;
		this.safeFirstPick = safeFirstPick;
	}

	public BoardGenerationStrategy getStrategy() {
		return new DistributionStrategy(mines, Pair.of(rows, columns));
	}

	public static final MSOptions EASY = new MSOptions(8, 8, 10, false, true);
	public static final MSOptions INTERMEDIATE = new MSOptions(16, 16, 40, false, true);
	public static final MSOptions ADVANCED = new MSOptions(16, 30, 99, false, true);
	public static final MSOptions EXPERT = new MSOptions(24, 30, 200, false, true);
}
