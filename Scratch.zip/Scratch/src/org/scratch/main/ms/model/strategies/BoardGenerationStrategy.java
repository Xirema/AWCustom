package org.scratch.main.ms.model.strategies;

public interface BoardGenerationStrategy {
	boolean willPlaceMine(int row, int column);

	void reset();
}
