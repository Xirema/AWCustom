package org.scratch.main.ms.model.strategies;

import java.util.Random;

import org.scratch.main.util.Pair;

public class DistributionStrategy implements BoardGenerationStrategy {
	private final int numOfMines;
	private final int numOfSpaces;
	private int numPlaced = 0;
	private int numExamined = 0;
	private final Random rand;

	public DistributionStrategy(int numOfMines, Pair<Integer, Integer> size) {
		this.numOfMines = numOfMines;
		numOfSpaces = size.first * size.second;
		rand = new Random();
	}

	@Override
	public boolean willPlaceMine(int row, int column) {
		if (numPlaced >= numOfMines)
			return false;
		int chance = numOfSpaces - numExamined;
		int canPlace = numOfMines - numPlaced;
		boolean ret = rand.nextInt(chance) < canPlace;
		numExamined++;
		if (ret) {
			numPlaced++;
		}
		return ret;
	}

	@Override
	public void reset() {
		numPlaced = 0;
		numExamined = 0;
	}

}
