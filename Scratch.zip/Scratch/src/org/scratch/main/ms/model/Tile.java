package org.scratch.main.ms.model;

public class Tile {
	public enum Content {
		NOTHING, MINE
	}

	public enum Flag {
		NOTHING, MARKED, UNSURE
	}

	public enum State {
		UNEXPLORED, EXPLORED
	}

	public Content content;
	public int neighborCount;
	public Flag flag;
	public State state;

	public Tile() {
		this(Content.NOTHING);
	}

	public Tile(Content content) {
		this.content = content;
		neighborCount = 0;
		flag = Flag.NOTHING;
		state = State.UNEXPLORED;
	}

	public boolean isExplored() {
		return state == State.EXPLORED;
	}

	public boolean hasMine() {
		return content == Content.MINE;
	}
}
