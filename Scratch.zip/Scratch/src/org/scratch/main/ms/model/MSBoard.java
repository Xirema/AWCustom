package org.scratch.main.ms.model;

import java.util.ArrayList;
import java.util.List;

import org.scratch.main.ms.config.MSConfig;
import org.scratch.main.ms.model.strategies.BoardGenerationStrategy;
import org.scratch.main.util.Matrix;
import org.scratch.main.util.Pair;
import org.scratch.main.util.functional.MatrixForEach;

public class MSBoard {
	private Matrix<Tile> tiles;
	private int numOfTiles;
	private int numOfMines;
	private boolean hasLost = false;
	private MSOptions options;

	public MSBoard(MSOptions options) {
		this.options = options;
		tiles = new Matrix<>(options.rows, options.columns);
		numOfTiles = 0;
		numOfMines = 0;
		buildBoard();
	}

	private void buildBoard() {
		tiles.fill((row, column) -> new Tile());
		numOfTiles = tiles.flatSize();
		final BoardGenerationStrategy strategy = options.getStrategy();
		tiles.forEach((MatrixForEach<Tile>) (row, column, object) -> {
			boolean willPlaceMine = strategy.willPlaceMine(row, column);
			if (willPlaceMine) {
				numOfMines++;
				for (int i = -1; i <= 1; i++) {
					for (int j = -1; j <= 1; j++) {
						if (!tiles.inBounds(row + i, column + j)) {
							continue;
						}
						Tile tile = tiles.get(row + i, column + j);
						if (i == 0 && j == 0) {
							tile.content = Tile.Content.MINE;
						} else {
							tile.neighborCount++;
						}
					}
				}
			}
		});
	}

	public Tile getTile(int row, int column) {
		return tiles.get(row, column);
	}

	public void toggleFlag(int row, int column) {
		Tile tile = getTile(row, column);
		if (tile.isExplored())
			return;
		switch (tile.flag) {
		case NOTHING:
			tile.flag = Tile.Flag.MARKED;
			break;
		case MARKED:
			tile.flag = Tile.Flag.UNSURE;
			break;
		case UNSURE:
			tile.flag = Tile.Flag.NOTHING;
			break;
		}
	}

	public boolean exploreTile(int row, int column) {
		Tile tile = getTile(row, column);
		if (tile.isExplored())
			return false;
		if (tile.flag == Tile.Flag.MARKED)
			return false;
		tile.state = Tile.State.EXPLORED;
		tile.flag = Tile.Flag.NOTHING;
		if (tile.hasMine())
			return true;
		if (tile.neighborCount == 0) {
			List<Pair<Integer, Integer>> neighbors = getNeighbors(row, column);
			boolean failed = false;
			for (Pair<Integer, Integer> neighbor : neighbors) {
				failed = failed || exploreTile(neighbor.first, neighbor.second);
			}
			if (MSConfig.isDebug() && failed)
				throw new RuntimeException("The auto-reveal hit a mine on accident!");
		}
		return false;
	}

	public List<Pair<Integer, Integer>> getNeighbors(int row, int column) {
		List<Pair<Integer, Integer>> pairs = new ArrayList<>();
		for (int i = -1; i <= 1; i++) {
			for (int j = -1; j <= 1; j++) {
				if (i == 0 && j == 0) {
					continue;
				}
				if (!tiles.inBounds(row + i, column + j)) {
					continue;
				}
				pairs.add(Pair.of(row + i, column + j));
			}
		}
		return pairs;
	}

	public int getNumOfTiles() {
		return numOfTiles;
	}

	public int getNumOfMines() {
		return numOfMines;
	}

	public int calculateUnrevealedMines() {
		int num = numOfMines;
		for (Tile tile : tiles) {
			if (tile.flag == Tile.Flag.MARKED) {
				num--;
			}
		}
		return num;
	}

	public Pair<Integer, Integer> getSize() {
		return tiles.size();
	}

	public boolean isLost() {
		return hasLost;
	}

	public void setLost(boolean hasLost) {
		this.hasLost = hasLost;
	}

	public boolean isWon() {
		return tiles.all((row, column, object) -> {
			if (object.hasMine() && !object.isExplored())
				return true;
			if (!object.hasMine() && object.isExplored())
				return true;
			return false;
		});
	}

	public MSOptions getOptions() {
		return options;
	}

	public void setOptions(MSOptions options) {
		this.options = options;
	}
}
