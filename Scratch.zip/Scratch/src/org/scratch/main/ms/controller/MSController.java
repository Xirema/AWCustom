package org.scratch.main.ms.controller;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

import javax.swing.JOptionPane;

import org.scratch.main.ms.model.MSBoard;
import org.scratch.main.ms.model.MSOptions;
import org.scratch.main.ms.model.Tile;
import org.scratch.main.ms.view.MSFrame;
import org.scratch.main.ms.view.MSGridView.MSGridListener;
import org.scratch.main.ms.view.MSGridView.MSGridListener.ClickType;
import org.scratch.main.ms.view.MSMenu.MSMenuListener;
import org.scratch.main.ms.view.MSNewGameDialog;
import org.scratch.main.util.Pair;

public class MSController {
	private MSFrame frame;
	private MSBoard board;
	private MSMenuListener menuListener;
	private MSGridListener gridListener;
	private WindowListener windowListener;
	private AtomicBoolean running;
	private boolean firstPress;

	public MSController() {
		frame = new MSFrame();
		setupMenuListener();
		setupGridListener();
		startNewGame(MSOptions.ADVANCED);
		setupWindowCloseListener();
		frame.setVisible(true);
		frame.pack();
		frame.setLocationRelativeTo(null);
		running = new AtomicBoolean(true);
		firstPress = true;
	}

	public void mainLoop() throws InterruptedException {
		while (running.get()) {
			synchronized (running) {
				running.wait();
			}
		}
	}

	public void startNewGame(MSOptions options) {
		startNewGame(options, true);
	}

	public void startNewGame(MSOptions options, boolean doRefresh) {
		if (options.mines < 0) {
			options = new MSOptions(options.rows, options.columns, 0, options.enableCheating, options.safeFirstPick);
		}
		board = new MSBoard(options);
		frame.applyModel(board);
		if (doRefresh) {
			frame.refresh();
		}
		firstPress = true;
	}

	private void setupMenuListener() {
		if (menuListener == null) {
			menuListener = new MSMenuListener() {
				@Override
				public void handleNewGameCommand() {
					new MSNewGameDialog(frame, options -> startNewGame(options));
				}

				@Override
				public void handleQuitCommand() {
					frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
				}

				@Override
				public void handleAboutCommand() {
					JOptionPane.showMessageDialog(frame, "Created by A. Reece England, for Educational Purposes");
				}
			};
		}
		frame.attachMenuListener(menuListener);
	}

	private void primaryClick(int row, int column) {
		final int r = row, c = column;
		Supplier<Boolean> tester = () -> {
			Tile tile = board.getTile(r, c);
			if (board.getNumOfMines() + 40 < board.getNumOfTiles())
				return tile.hasMine() || tile.neighborCount != 0;
			else
				return tile.hasMine();
		};
		boolean result = board.exploreTile(row, column);
		if (tester.get()) {
			if (firstPress && board.getOptions().safeFirstPick) {
				do {
					startNewGame(board.getOptions(), false);
					result = board.exploreTile(row, column);
				} while (tester.get());
			} else if (result) {
				board.setLost(true);
			}
		}
	}

	private void middleClick(int row, int column) {
		if (board.getTile(row, column).isExplored()) {
			List<Pair<Integer, Integer>> neighbors = board.getNeighbors(row, column);
			int numOfFlagsNeeded = board.getTile(row, column).neighborCount;
			for (Pair<Integer, Integer> neighbor : neighbors) {
				Tile tile = board.getTile(neighbor.first, neighbor.second);
				if (tile.flag == Tile.Flag.MARKED && !tile.isExplored()) {
					numOfFlagsNeeded--;
				}
			}
			if (numOfFlagsNeeded == 0) {
				for (Pair<Integer, Integer> neighbor : neighbors) {
					Tile tile = board.getTile(neighbor.first, neighbor.second);
					if (tile.flag == Tile.Flag.MARKED || tile.isExplored()) {
						continue;
					}
					boolean result = board.exploreTile(neighbor.first, neighbor.second);
					if (result) {
						board.setLost(true);
					}
				}
			}
		}
	}

	private void setupGridListener() {
		if (gridListener == null) {
			gridListener = (clickType, row, column) -> {
				if (board.isLost() || board.isWon())
					return;
				if (clickType == ClickType.PRIMARY) {
					primaryClick(row, column);
				} else if (clickType == ClickType.SECONDARY) {
					board.toggleFlag(row, column);
				} else {
					middleClick(row, column);
				}
				frame.refresh();
				firstPress = false;
			};
		}
		frame.attachGridViewListener(gridListener);
	}

	private void setupWindowCloseListener() {
		if (windowListener == null) {
			windowListener = new WindowAdapter() {
				@Override
				public void windowClosed(WindowEvent e) {
					synchronized (running) {
						running.set(false);
						running.notifyAll();
					}
				}
			};
		}
		frame.addWindowListener(windowListener);
	}
}
