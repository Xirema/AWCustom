package org.scratch.main.ms.config;

public final class MSConfig {
	private MSConfig() {
	}

	private static final boolean DEBUG = false;

	public static boolean isDebug() {
		return DEBUG;
	}
}
