package org.scratch.main.armory.model;

@Deprecated
public enum MagicWeaponProperty {
	Mithril, Adamantine, Silvered, Brutal, Superior, Sharpened, Accurate, Clumsy, Blunt, Exotic;

	public String description() {
		switch (this) {
		case Mithril:
			return "A non-Heavy Weapon becomes Light; a Heavy Weapon loses the Heavy property";
		case Adamantine:
			return "Damage on objects becomes Critical";
		case Silvered:
			return "Damage bypasses non-magical resistances/immunities";
		case Brutal:
			return "On a Critical hit, add an additional weapon die to the damage";
		case Superior:
			return "Critical Hit Range is expanded";
		case Sharpened:
			return "Increased Damage on hit";
		case Accurate:
			return "Increased Attack Roll modifier";
		case Clumsy:
			return "Decreased Attack Roll modifier";
		case Blunt:
			return "Decreased Damage on hit";
		case Exotic:
			return "Increases the Weapon Damage Die Size";
		default:
			throw new RuntimeException("Need to add more descriptions to MagicWeaponProperty!");
		}
	}

	public int value() {
		switch (this) {
		case Mithril:
			return 2;
		case Adamantine:
			return 2;
		case Silvered:
			return 1;
		case Brutal:
			return 2;
		case Superior:
			return 2;
		case Sharpened:
			return 1;
		case Accurate:
			return 1;
		case Clumsy:
			return -1;
		case Blunt:
			return -1;
		case Exotic:
			return 1;
		default:
			throw new RuntimeException("Need to add more values to MagicWeaponProperty!");
		}
	}
}
