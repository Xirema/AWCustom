package org.scratch.main.armory.model;

@Deprecated
public enum ArmorPropertyEnum {
	Heavy, Clunky, Special;

	public String description() {
		switch (this) {
		case Heavy:
			return "Requires minimum Strength score or wearer is encumbered";
		case Clunky:
			return "Disadvantage on Stealth Checks";
		case Special:
			return "Meh.";
		default:
			throw new RuntimeException("Need to add more cases to BasicArmorProperty!");
		}
	}
}
