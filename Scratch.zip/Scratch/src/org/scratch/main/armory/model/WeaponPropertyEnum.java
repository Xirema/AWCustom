package org.scratch.main.armory.model;

@Deprecated
public enum WeaponPropertyEnum {
	Ammunition, Finesse, Heavy, Light, Loading, Range, Reach, Thrown, Two_Handed, Versatile, Special,

	Mithril, Adamantine, Silvered, Brutal, Superior, Sharpened, Accurate, Clumsy, Blunt, Exotic;

	@Override
	public String toString() {
		if (this == Two_Handed)
			return "Two-Handed";
		else
			return super.toString();
	}

	public String description() {
		switch (this) {
		case Ammunition:
			return "Requires Ammunition; requires a free hand to load";
		case Finesse:
			return "May use Strength or Dexterity";
		case Heavy:
			return "Small Creatures have Disadvantage when using";
		case Light:
			return "Eligible for Two-Weapon Fighting";
		case Loading:
			return "May only be used once per attack action";
		case Range:
			return "May be used at range, or at an extended range with Disadvantage";
		case Reach:
			return "Has an extended Melee Range";
		case Thrown:
			return "Melee Weapon that can be used at range";
		case Two_Handed:
			return "Requires use of two hands";
		case Versatile:
			return "May be wielded with two hands to improve damage";
		case Special:
			return "Meh.";
		default:
			throw new RuntimeException("Need to add more cases to BasicWeaponProperty!");
		}
	}
}
