package org.scratch.main.armory.model;

@Deprecated
public enum MagicArmorProperty {
	Mithril, Adamantine;

	public String description() {
		switch (this) {
		case Mithril:
			return "Removes Heavy and Clunky properties";
		case Adamantine:
			return "Critical hits are reduced to normal";
		default:
			throw new RuntimeException("Need to add more cases to MagicArmorProperty!");
		}
	}
}
