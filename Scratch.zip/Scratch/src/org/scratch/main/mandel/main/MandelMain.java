package org.scratch.main.mandel.main;

import java.awt.Color;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.function.Supplier;

import javax.imageio.ImageIO;

import org.lwjgl.glfw.GLFW;
import org.scratch.main.mandel.model.MandelRenderer;
import org.scratch.main.mandel.model.MandelRendererSoftware;
import org.scratch.main.mandel.model.MandelViewer;
import org.scratch.main.mandel.model.MandelViewerGL;
import org.scratch.main.mandel.model.MandelbrotRendererCL;
import org.scratch.main.mandel.model.config.MandelOptions;
import org.scratch.main.mandel.model.config.MandelOptions.Precision;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.Pair;

public class MandelMain {
	static int j = new Random().nextInt(360);
	public static List<Color> getColors() {
		List<Color> baseColors = new ArrayList<>();
		
		List<Color> colors = new ArrayList<>();
		for (int i = 0; i <= 360; i++) {
			colors.add(Color.getHSBColor((i + j) / 360.f, 1, 0.5f));
		}
		j += 90;
		return colors;
	}

	public static void main(String[] args) throws InterruptedException, ExecutionException, IOException {
		try (MandelRenderer renderer = new MandelbrotRendererCL()) {
			GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
			GraphicsDevice[] devices = ge.getScreenDevices();
			List<Future<RenderedImage>> futures = new ArrayList<>();
			long start = System.nanoTime();
			int angle = new Random().nextInt(360);
			MandelOptions options = new MandelOptions()
				.withSupersampleFactor(4)
				.withEscapeThreshold(5000)
				.withRadius(1.f / 2048)
				.withCenter(Pair.of(new BigRational(-189 * 64 + 17, 256 * 64), new BigRational(6 * 256 - 1, 32 * 256)))
				.withPrecision(Precision.FLOAT);
			for(GraphicsDevice device : devices) {
				options = options
					.withWidth(device.getDisplayMode().getWidth())
					.withHeight(device.getDisplayMode().getHeight())
					.withColors(getColors())
					.withRotation(Math.toRadians(angle += 90));
				futures.add(renderer.render(options));
				System.out.println("Render submitted");
			}
			for(Future<RenderedImage> future : futures) {
				long timestamp = System.currentTimeMillis();
				RenderedImage image = future.get();
				File renderDirectory = new File("Renders");
				renderDirectory.mkdirs();
				File file = new File(renderDirectory, String.format("%d", timestamp) + ".png");
				while(file.exists())
					file = new File(renderDirectory, String.format("%d", ++timestamp) + ".png");
				ImageIO.write(image, "png", file);
				System.out.println("Successfully written to \"" + file.getAbsolutePath() + "\"");
			}
			long end = System.nanoTime();
		}
		
//		try(MandelViewer viewer = new MandelViewerGL()) {
//			int angle = new Random().nextInt(360);
//			MandelOptions options = new MandelOptions()
//				.withSupersampleFactor(4)
//				.withEscapeThreshold(5000)
//				.withRadius(1 / 2048.f)
//				.withCenter(Pair.of(new BigRational(-189 * 64 + 17, 256 * 64), new BigRational(6 * 256 - 1, 32 * 256)))
//				.withPrecision(Precision.FLOAT)
//				.withColors(getColors())
//				.withRotation(Math.toRadians(angle += 90));
//			do {
//				viewer.view(options);
//				options = options.withRotation(Math.toRadians((int)GLFW.glfwGetTime()));
//			} while(viewer.handleEvents());
//		}
	}
}
