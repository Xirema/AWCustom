package org.scratch.main.mandel.model.gl;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Consumer;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.lwjgl.opengl.GL43;
import org.lwjgl.system.MemoryStack;

public class GLResourceStack implements AutoCloseable {
	private static class GLResource {
		long ptr;
		Consumer<Long> closure;
		GLResource(long ptr, Consumer<Long> closure) {
			this.ptr = ptr;
			this.closure = closure;
		}
	}
	
	private Deque<GLResource> deque = new ArrayDeque<>();
	public GLResourceStack() {}
	
	public long holdGeneric(long ptr, Consumer<Long> closure) {
		GLResource resource = new GLResource(ptr, closure);
		deque.push(resource);
		return resource.ptr;
	}
	
	public int holdGenericHandle(int handle, Consumer<Integer> closure) {
		GLResource resource = new GLResource(handle, l -> closure.accept(l.intValue()));
		deque.push(resource);
		return handle;
	}
	
	public int holdShader(String code, int stage) {
		int shader = holdGenericHandle(GL43.glCreateShader(stage), GL43::glDeleteShader);
		GL43.glShaderSource(shader, code);
		GL43.glCompileShader(shader);
		int status = GL43.glGetShaderi(shader, GL43.GL_COMPILE_STATUS);
		if(status != GL43.GL_TRUE) {
			String infoLog = GL43.glGetShaderInfoLog(shader);
			String[] lines = code.split("\n");
			for(int i = 0; i < lines.length; i++) {
				lines[i] = String.format("%4d: ", i + 1) + lines[i];
			}
			infoLog += "\n" + Stream.of(lines).reduce("\n", (s1, s2) -> s1 + s2 + '\n');
			throw new RuntimeException("Unable to compile Shader: \n" + infoLog);
		}
		return shader;
	}
	
	public int holdProgram(int... shaders) {
		int program = holdGenericHandle(GL43.glCreateProgram(), GL43::glDeleteProgram);
		for(int shader : shaders) {
			GL43.glAttachShader(program, shader);
		}
		GL43.glLinkProgram(program);
		int status = GL43.glGetProgrami(program, GL43.GL_LINK_STATUS);
		if(status != GL43.GL_TRUE) {
			String infoLog = GL43.glGetProgramInfoLog(program);
			throw new RuntimeException("Unable to Link Program: \n" + infoLog);
		}
		return program;
	}
	
	@Override
	public void close() {
		while(deque.size() > 0) {
			GLResource resource = deque.pop();
			resource.closure.accept(resource.ptr);
		}
	}
}
