package org.scratch.main.mandel.model;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.scratch.main.mandel.model.config.MandelOptions;
import org.scratch.main.mandel.model.config.MandelOptions.Precision;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.Matrix;

public class MandelRendererSoftware implements MandelRenderer {
	//private MandelOptions options;
	private ExecutorService executor;
	private ExecutorService collator;

//	public MandelRendererSoftware() {
//		this(new MandelOptions());
//	}

	public MandelRendererSoftware(/*MandelOptions options*/) {
		//this.setOptions(options);
		executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		collator = Executors.newSingleThreadExecutor();
	}

	private static final float LOG_2 = (float) Math.log(2);

	private static float calculateFloatEscapeThreshold(float x, float y, int limit) {
		float tx = 0, ty = 0;
		int iter = 0;
		int period = 8;
		int check = period;
		float px = 0, py = 0;
		while ((tx * tx + ty * ty) < 65536 && ++iter < limit) {
			float nx = tx * tx - ty * ty + x;
			float ny = 2 * tx * ty + y;
			tx = nx;
			ty = ny;
			if (check == 0) {
				if (px == tx && py == ty) {
					iter = limit;
					break;
				}
				px = tx;
				py = ty;
				period <<= 1;
				check = period;
			}
		}
		float fiter = iter;
		if (iter < limit) {
			float log_zn = (float) (Math.log(tx * tx + ty * ty) / 2);
			float nu = (float) (Math.log(log_zn / LOG_2) / LOG_2);
			fiter = fiter + 1 - nu;
			// fiter = fiter + nu;
			return fiter;
		} else
			return -1;
	}

	private static float calculateDoubleEscapeThreshold(double x, double y, int limit) {
		double tx = 0, ty = 0;
		int iter = 0;
		int period = 8;
		int check = period;
		double px = 0, py = 0;
		while ((tx * tx + ty * ty) < 65536 && ++iter < limit) {
			double nx = tx * tx - ty * ty + x;
			double ny = 2 * tx * ty + y;
			tx = nx;
			ty = ny;
			if (check == 0) {
				if (px == tx && py == ty) {
					iter = limit;
					break;
				}
				px = tx;
				py = ty;
				period <<= 1;
				check = period;
			}
		}
		float fiter = iter;
		if (iter < limit) {
			float log_zn = (float) (Math.log(tx * tx + ty * ty) / 2);
			float nu = (float) (Math.log(log_zn / LOG_2) / LOG_2);
			fiter = fiter + 1 - nu;
			// fiter = fiter + nu;
			return fiter;
		} else
			return -1;
	}

	private static int clamp(int num, int min, int max) {
		if (num < min)
			return min;
		else if (num > max)
			return max;
		else
			return num;
	}

	private static Color blend(Color c1, Color c2, float factor) {
		return new Color(clamp((int) (c1.getRed() + (c2.getRed() - c1.getRed()) * factor), 0, 255),
				clamp((int) (c1.getGreen() + (c2.getGreen() - c1.getGreen()) * factor), 0, 255),
				clamp((int) (c1.getBlue() + (c2.getBlue() - c1.getBlue()) * factor), 0, 255),
				clamp((int) (c1.getAlpha() + (c2.getAlpha() - c1.getAlpha()) * factor), 0, 255));
	}

	private static Color determineColor(float escapeThreshold, List<Color> colors, Color voidColor) {
		if (escapeThreshold < 0)
			return voidColor;

		int index1 = ((int) Math.floor(escapeThreshold)) % colors.size();
		int index2 = ((int) Math.ceil(escapeThreshold)) % colors.size();
		Color color1 = colors.get(index1);
		Color color2 = colors.get(index2);
		return blend(color1, color2, escapeThreshold - index1);
	}

	private static abstract class RowRenderer implements Callable<Integer> {
		protected int row;
		protected Matrix<Color> mat;
		protected MandelOptions options;

		RowRenderer(int row, Matrix<Color> mat, MandelOptions options) {
			this.row = row;
			this.mat = mat;
			this.options = options;
		}

		protected abstract float getEscapeTime(BigRational x, BigRational y);

		@Override
		public Integer call() throws Exception {
			int ssf = options.supersampleFactor;
			int width = options.width / 2;
			int height = options.height / 2;
			int boxSize = Math.min(width, height) * ssf;
			for (int column = 0; column < options.width; column++) {
				float[] color = new float[] { 0, 0, 0, 0 };
				for (int ssrow = 0; ssrow < ssf; ssrow++) {
					for (int sscol = 0; sscol < ssf; sscol++) {
						int x_coord = sscol + (column - width) * ssf;
						int y_coord = -(ssrow + (row - height) * ssf);
						BigRational x = options.center.first
								.plus(new BigRational(x_coord).divides(new BigRational(boxSize)).times(BigRational.from(options.radius)));
						BigRational y = options.center.second
								.plus(new BigRational(y_coord).divides(new BigRational(boxSize)).times(BigRational.from(options.radius)));
						float escapeTime = getEscapeTime(x, y);
						Color localColor = determineColor(escapeTime, options.colors, options.voidColor);
						color[0] += localColor.getRed() / 255.f;
						color[1] += localColor.getGreen() / 255.f;
						color[2] += localColor.getBlue() / 255.f;
						color[3] += localColor.getAlpha() / 255.f;
					}
				}
				color[0] /= ssf * ssf;
				color[1] /= ssf * ssf;
				color[2] /= ssf * ssf;
				color[3] /= ssf * ssf;
				mat.set(row, column, new Color((int) (color[0] * 255), (int) (color[1] * 255), (int) (color[2] * 255),
						(int) (color[3] * 255)));
			}
			return row;
		}
	}

	private static class DoubleRowRenderer extends RowRenderer {
		DoubleRowRenderer(int row, Matrix<Color> mat, MandelOptions options) {
			super(row, mat, options);
		}

		@Override
		protected float getEscapeTime(BigRational x, BigRational y) {
			return calculateDoubleEscapeThreshold(x.doubleValue(), y.doubleValue(), options.escapeThreshold);
		}
	}

	private static class FloatRowRenderer extends RowRenderer {
		FloatRowRenderer(int row, Matrix<Color> mat, MandelOptions options) {
			super(row, mat, options);
		}

		@Override
		protected float getEscapeTime(BigRational x, BigRational y) {
			return calculateFloatEscapeThreshold((float) x.doubleValue(), (float) y.doubleValue(),
					options.escapeThreshold);
		}
	}

	private static class Collator implements Callable<RenderedImage> {
		List<Future<Integer>> futures;
		Matrix<Color> mat;

		Collator(List<Future<Integer>> futures, Matrix<Color> mat) {
			this.futures = futures;
			this.mat = mat;
		}

		@Override
		public RenderedImage call() throws Exception {
			BufferedImage image = new BufferedImage(mat.size().second, mat.size().first, BufferedImage.TYPE_4BYTE_ABGR);
			while(true) {
			boolean allDone = true;
				for (Future<Integer> future : futures) {
					if(future.isDone()) {
						int row = future.get();
						for(int column = 0; column < mat.size().second; column++) {
							image.setRGB(column, row, mat.get(row, column).getRGB());
						}
					} else {
						allDone = false;
					}
				}
				if(allDone)
					break;
			}
			return image;
		}
	}

	@Override
	public Future<RenderedImage> render(MandelOptions options) {
		//MandelOptions options = this.options;
		Matrix<Color> mat = new Matrix<>(options.height, options.width);
		List<Future<Integer>> futures = new ArrayList<>();
		for (int row = 0; row < options.height; row++) {
			if (options.precision == Precision.DOUBLE) {
				futures.add(executor.submit(new DoubleRowRenderer(row, mat, options)));
			} else if (options.precision == Precision.FLOAT) {
				futures.add(executor.submit(new FloatRowRenderer(row, mat, options)));
			} else
				throw new RuntimeException("Precision " + options.precision.toString() + " not supported.");
		}
		return collator.submit(new Collator(futures, mat));
	}

//	public MandelOptions getOptions() {
//		return options;
//	}
//
//	public void setOptions(MandelOptions options) {
//		this.options = options;
//	}

	@Override
	public void close() throws IOException {
		executor.shutdownNow();
		collator.shutdownNow();
	}
}
