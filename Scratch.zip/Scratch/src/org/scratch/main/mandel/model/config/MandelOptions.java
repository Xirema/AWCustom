package org.scratch.main.mandel.model.config;

import java.awt.Color;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

import org.scratch.main.util.BigRational;
import org.scratch.main.util.Pair;

public class MandelOptions {
	public final Pair<BigRational, BigRational> center;
	public final float radius;
	public final int width, height;
	public final int supersampleFactor;
	public final double rotation;
	public final int escapeThreshold;
	public final List<Color> colors;
	public final Color voidColor;
	public final Precision precision;

	public enum Precision {
		FLOAT, DOUBLE, QUAD, FDOUBLE, DQUAD
	}

	public MandelOptions(Pair<BigRational, BigRational> center, float radius, int width, int height,
			int supersampleFactor, double rotation, int escapeThreshold, Precision precision, List<Color> colors,
			Color voidColor) {
		this.center = center;
		this.radius = radius;
		this.width = width;
		this.height = height;
		this.supersampleFactor = supersampleFactor;
		this.rotation = rotation;
		this.escapeThreshold = escapeThreshold;
		this.colors = Collections.unmodifiableList(new ArrayList<>(colors));
		this.voidColor = voidColor;
		this.precision = precision;
	}

	public MandelOptions() {
		this(Pair.of(BigRational.ZERO, BigRational.ZERO), 2, 1920, 1080, 4, 0, 2500, Precision.FLOAT,
				getDefaultColors(), Color.BLACK);
	}

	public static List<Color> getDefaultColors() {
		List<Color> colors = new ArrayList<>();
		for (int i = 0; i <= 360; i++) {
			colors.add(Color.getHSBColor(i / 360.f, 1, 0.5f));
		}
		return colors;
	}

	public MandelOptions withCenter(Pair<BigRational, BigRational> center) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withRadius(float radius) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withWidth(int width) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withHeight(int height) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withSupersampleFactor(int supersampleFactor) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withRotation(double rotation) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withEscapeThreshold(int escapeThreshold) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withPrecision(Precision precision) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withColors(List<Color> colors) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}

	public MandelOptions withVoidColor(Color voidColor) {
		return new MandelOptions(center, radius, width, height, supersampleFactor, rotation, escapeThreshold, precision,
				colors, voidColor);
	}
	
	public boolean equals(Object o) {
		if(this == o)
			return true;
		if(o == null)
			return false;
		if(getClass().equals(o.getClass())) {
			Field[] fields = getClass().getDeclaredFields();
			for(Field field : fields) {
				try {
					if(!Objects.equals(field.get(this), field.get(o))) {
						return false;
					}
				} catch (IllegalArgumentException | IllegalAccessException e) {
					return false;
				}
			}
			return true;
		} else
			return false;
	}
}
