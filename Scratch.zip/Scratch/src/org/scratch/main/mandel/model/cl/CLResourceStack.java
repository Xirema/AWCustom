package org.scratch.main.mandel.model.cl;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.function.Consumer;

public class CLResourceStack implements AutoCloseable {
	private Deque<CLResource> resources;
	
	public CLResourceStack() {
		resources = new ArrayDeque<>();
	}
	
	public CLResource holdResource(long ptr, Consumer<Long> closure) {
		CLResource resource = new CLResource(ptr, closure);
		resources.push(resource);
		return resource;
	}
	
	public CLResource holdProgram(long contextPtr, long devicePtr, String kernelSource) {
		Program program = new Program(contextPtr, devicePtr, kernelSource);
		resources.push(program);
		return program;
	}
	
	public CLResource holdContext(long devicePtr) {
		Context context = new Context(devicePtr);
		resources.push(context);
		return context;
	}
	
	public CLResource holdQueue(long contextPtr, long devicePtr) {
		Queue queue = new Queue(contextPtr, devicePtr);
		resources.push(queue);
		return queue;
	}
	@Override
	public void close() {
		while(resources.size() > 0) {
			CLResource resource = resources.pop();
			resource.close();
		}
	}

}
