package org.scratch.main.mandel.model.cl;

import java.nio.IntBuffer;
import java.nio.LongBuffer;

import org.lwjgl.opencl.CL21;
import org.lwjgl.system.MemoryStack;

public class Queue extends CLResource implements AutoCloseable {
	Queue(long contextPtr, long devicePtr) {
		super(getQueue(contextPtr, devicePtr), CL21::clReleaseCommandQueue);
	}

	private static long getQueue(long contextPtr, long devicePtr) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			LongBuffer queueProperties = stack.callocLong(1);
			//LongBuffer queueProperties = stack.callocLong(3);
			//queueProperties.put(0, CL21.CL_QUEUE_PROPERTIES);
			//queueProperties.put(1, CL21.CL_QUEUE_PROFILING_ENABLE);
			
			IntBuffer ret = stack.callocInt(1);
			
			long ptr = CL21.clCreateCommandQueueWithProperties(contextPtr, devicePtr, queueProperties, ret);
			if(ret.get(0) != CL21.CL_SUCCESS)
				throw new RuntimeException("Unable to create Command Queue: " + ret.get(0));
			return ptr;
		}
	}
}
