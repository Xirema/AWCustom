package org.scratch.main.mandel.model;

import java.awt.image.RenderedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import org.lwjgl.PointerBuffer;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.util.shaderc.Shaderc;
import org.lwjgl.util.shaderc.ShadercIncludeResolve;
import org.lwjgl.util.shaderc.ShadercIncludeResult;
import org.lwjgl.util.shaderc.ShadercIncludeResultRelease;
import org.lwjgl.vulkan.VK11;
import org.lwjgl.vulkan.VkApplicationInfo;
import org.lwjgl.vulkan.VkBufferCreateInfo;
import org.lwjgl.vulkan.VkDescriptorBufferInfo;
import org.lwjgl.vulkan.VkDescriptorPoolCreateInfo;
import org.lwjgl.vulkan.VkDescriptorPoolSize;
import org.lwjgl.vulkan.VkDescriptorSetAllocateInfo;
import org.lwjgl.vulkan.VkDescriptorSetLayoutBinding;
import org.lwjgl.vulkan.VkDescriptorSetLayoutCreateInfo;
import org.lwjgl.vulkan.VkDevice;
import org.lwjgl.vulkan.VkDeviceCreateInfo;
import org.lwjgl.vulkan.VkDeviceQueueCreateInfo;
import org.lwjgl.vulkan.VkInstance;
import org.lwjgl.vulkan.VkInstanceCreateInfo;
import org.lwjgl.vulkan.VkMemoryAllocateInfo;
import org.lwjgl.vulkan.VkMemoryRequirements;
import org.lwjgl.vulkan.VkPhysicalDevice;
import org.lwjgl.vulkan.VkPhysicalDeviceFeatures;
import org.lwjgl.vulkan.VkPhysicalDeviceMemoryProperties;
import org.lwjgl.vulkan.VkPhysicalDeviceProperties;
import org.lwjgl.vulkan.VkQueue;
import org.lwjgl.vulkan.VkQueueFamilyProperties;
import org.lwjgl.vulkan.VkShaderModuleCreateInfo;
import org.lwjgl.vulkan.VkWriteDescriptorSet;
import org.scratch.main.mandel.model.config.MandelOptions;
import org.scratch.main.util.Pair;

public class MandelbrotRendererVK implements MandelRenderer {
	
	private VkInstance instance;
	private VkDevice device;
	private VkQueue queue;
	
	public MandelbrotRendererVK() {
		instance = getInstance();
		List<VkPhysicalDevice> physicalDevices = getPhysicalDevices(instance);
		Pair<VkPhysicalDevice, Integer> physicalDevice = selectPhysicalDevice(physicalDevices);
		device = createDevice(physicalDevice.first, physicalDevice.second);
		queue = getQueue(device, physicalDevice.second);
	}
	
	

	@Override
	public void close() throws IOException {
		VK11.vkDeviceWaitIdle(device);
		VK11.vkDestroyDevice(device, null);
		VK11.vkDestroyInstance(instance, null);
	}

	@Override
	public Future<RenderedImage> render(MandelOptions options) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private VkInstance getInstance() {
		try(MemoryStack memStack = MemoryStack.stackPush()) {
			VkApplicationInfo appInfo = VkApplicationInfo.callocStack(memStack)
				.sType(VK11.VK_STRUCTURE_TYPE_APPLICATION_INFO)
				.apiVersion(VK11.VK_API_VERSION_1_1)
				.applicationVersion(VK11.VK_MAKE_VERSION(0, 1, 0))
				.pApplicationName(MemoryStack.stackUTF8Safe("Mandelbrot Renderer Vk"))
				.engineVersion(VK11.VK_MAKE_VERSION(0, 1, 0))
				.pEngineName(MemoryStack.stackUTF8Safe("MANDELVK"));
			VkInstanceCreateInfo createInfo = VkInstanceCreateInfo.callocStack(memStack)
				.sType(VK11.VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO)
				.pApplicationInfo(appInfo);
			PointerBuffer buffer = memStack.callocPointer(1);
			if(VK11.vkCreateInstance(createInfo, null, buffer) != VK11.VK_SUCCESS)
				throw new RuntimeException("Unable to create Vulkan Instance");
			return new VkInstance(buffer.get(), createInfo);
		}
	}
	
	private List<VkPhysicalDevice> getPhysicalDevices(VkInstance instance) {
		try(MemoryStack memStack = MemoryStack.stackPush()) {
			int[] numOfDevices = {0};
			VK11.vkEnumeratePhysicalDevices(instance, numOfDevices, null);
			if(numOfDevices[0] == 0)
				throw new RuntimeException("No Physical Devices found");
			PointerBuffer devices = memStack.callocPointer(numOfDevices[0]);
			VK11.vkEnumeratePhysicalDevices(instance, numOfDevices, devices);
			List<VkPhysicalDevice> ret = new ArrayList<>();
			for(int i = 0; i < numOfDevices[0]; i++) {
				ret.add(new VkPhysicalDevice(devices.get(i), instance));
			}
			return ret;
		}
	}
	
	private Pair<Boolean, Integer> checkPhysicalDevice(VkPhysicalDevice device) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceProperties properties = VkPhysicalDeviceProperties.callocStack(stack);
			VkPhysicalDeviceFeatures features = VkPhysicalDeviceFeatures.callocStack(stack);
			int[] queuePropertiesCount = {0};
			VK11.vkGetPhysicalDeviceProperties(device, properties);
			VK11.vkGetPhysicalDeviceFeatures(device, features);
			VK11.vkGetPhysicalDeviceQueueFamilyProperties(device, queuePropertiesCount, null);
			VkQueueFamilyProperties.Buffer queueProperties = VkQueueFamilyProperties.callocStack(queuePropertiesCount[0], stack);
			VK11.vkGetPhysicalDeviceQueueFamilyProperties(device, queuePropertiesCount, queueProperties);
			for(int i = 0; i < queuePropertiesCount[0]; i++) {
				VkQueueFamilyProperties queueProp = queueProperties.get(i);
				if(queueProp.queueCount() > 0 && (queueProp.queueFlags() & VK11.VK_QUEUE_COMPUTE_BIT) != 0)
					return Pair.of(true, i);
			}
			return Pair.of(false, 0);
		}
	}
	
	private Pair<VkPhysicalDevice, Integer> selectPhysicalDevice(List<VkPhysicalDevice> devices) {
		for(VkPhysicalDevice device : devices) {
			Pair<Boolean, Integer> check = checkPhysicalDevice(device);
			if(check.first) {
				return Pair.of(device, check.second);
			}
		}
		throw new RuntimeException("Unable to find Physical Device that has a Compute Queue! That's pretty weird considering that that's a required feature, but whatever!");
	}
	
	private VkDevice createDevice(VkPhysicalDevice device, int queueFamilyIndex) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			FloatBuffer queuePriorities = stack.floats(1.f);
			VkDeviceQueueCreateInfo.Buffer queueInfoBuffer = VkDeviceQueueCreateInfo.callocStack(1, stack);
			VkDeviceQueueCreateInfo queueInfo = queueInfoBuffer.get(0).sType(VK11.VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO)
				.queueFamilyIndex(queueFamilyIndex)
				.pQueuePriorities(queuePriorities);
			queueInfoBuffer.put(0, queueInfo);
			VkDeviceCreateInfo createInfo = VkDeviceCreateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO)
				.pQueueCreateInfos(queueInfoBuffer);
			
			PointerBuffer buffer = stack.callocPointer(1);
			if(VK11.vkCreateDevice(device, createInfo, null, buffer) != VK11.VK_SUCCESS)
				throw new RuntimeException("Unable to create Logical Device from Physical Device");
			return new VkDevice(buffer.get(), device, createInfo);
		}
	}
	
	private VkQueue getQueue(VkDevice device, int queueFamilyIndex) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			PointerBuffer buffer = stack.callocPointer(1);
			VK11.vkGetDeviceQueue(device, queueFamilyIndex, 0, buffer);
			return new VkQueue(buffer.get(), device);
		}
	}
	
	private int findMemoryType(VkPhysicalDevice device, int memoryTypeBits, int flags) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkPhysicalDeviceMemoryProperties properties = VkPhysicalDeviceMemoryProperties.callocStack(stack);
			VK11.vkGetPhysicalDeviceMemoryProperties(device, properties);
			for(int i = 0; i < properties.memoryTypeCount(); i++) {
				if((memoryTypeBits & (1 << i)) != 0 &&
					(properties.memoryTypes(i).propertyFlags() & flags) == flags) {
					return i;
				}
			}
			throw new RuntimeException("Unable to Find appropriate Memory Type");
		}
	}
	
	private Pair<Long, Long> createBuffer(VkDevice device, long size) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkBufferCreateInfo bufferCreateInfo = VkBufferCreateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO)
				.size(size)
				.usage(VK11.VK_BUFFER_USAGE_STORAGE_BUFFER_BIT)
				.sharingMode(VK11.VK_SHARING_MODE_EXCLUSIVE);
			long[] vkBufferPtr = {0};
			if(VK11.vkCreateBuffer(device, bufferCreateInfo, null, vkBufferPtr) != VK11.VK_SUCCESS)
				throw new RuntimeException("Unable to Create Buffer");
			long vkBuffer = vkBufferPtr[0];
			
			VkMemoryRequirements memoryRequirements = VkMemoryRequirements.callocStack(stack);
			VK11.vkGetBufferMemoryRequirements(device, vkBuffer, memoryRequirements);
			VkMemoryAllocateInfo allocateInfo = VkMemoryAllocateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO)
				.allocationSize(memoryRequirements.size())
				.memoryTypeIndex(findMemoryType(device.getPhysicalDevice(), memoryRequirements.memoryTypeBits(), VK11.VK_MEMORY_PROPERTY_HOST_COHERENT_BIT | VK11.VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT));
			long[] vkMemoryPtr = {0};
			if(VK11.vkAllocateMemory(device, allocateInfo, null, vkMemoryPtr) != VK11.VK_SUCCESS) {
				throw new RuntimeException("Unable to allocate Buffer Memory");
			}
			long vkBufferMemory = vkMemoryPtr[0];
			if(VK11.vkBindBufferMemory(device, vkBuffer, vkBufferMemory, 0) != VK11.VK_SUCCESS) {
				throw new RuntimeException("Unable to bind Memory to Buffer");
			}
			return Pair.of(vkBuffer, vkBufferMemory);
		}
	}
	
	private long createDescriptorSetLayout(VkDevice device) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkDescriptorSetLayoutBinding.Buffer bindings = VkDescriptorSetLayoutBinding.callocStack(3, stack);
			//Output Image
			bindings.get(0)
				.binding(0)
				.descriptorType(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1)
				.stageFlags(VK11.VK_SHADER_STAGE_COMPUTE_BIT);
			
			//Output Partial
			bindings.get(1)
				.binding(1)
				.descriptorType(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1)
				.stageFlags(VK11.VK_SHADER_STAGE_COMPUTE_BIT);
			
			//Input Parameters
			bindings.get(2)
				.binding(2)
				.descriptorType(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1)
				.stageFlags(VK11.VK_SHADER_STAGE_COMPUTE_BIT);
			
			VkDescriptorSetLayoutCreateInfo descriptorSetLayoutCreateInfo = VkDescriptorSetLayoutCreateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO)
				.pBindings(bindings);
			long[] layoutPtr = {0};
			if(VK11.vkCreateDescriptorSetLayout(device, descriptorSetLayoutCreateInfo, null, layoutPtr) != VK11.VK_SUCCESS)
				throw new RuntimeException("Unable to create Descriptor Set Layout");
			return layoutPtr[0];
		}
	}
	
	private long createDescriptorSet(VkDevice device, long descriptorSetLayout) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkDescriptorPoolSize.Buffer sizeBuffer = VkDescriptorPoolSize.callocStack(3, stack);
			sizeBuffer.get(0)
				.type(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1);
			sizeBuffer.get(1)
				.type(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1);
			sizeBuffer.get(2)
				.type(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
				.descriptorCount(1);
			VkDescriptorPoolCreateInfo poolCreateInfo = VkDescriptorPoolCreateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO)
				.pPoolSizes(sizeBuffer)
				.maxSets(1)
			;
			long[] descriptorPoolPtr = {0};
			if(VK11.vkCreateDescriptorPool(device, poolCreateInfo, null, descriptorPoolPtr) != VK11.VK_SUCCESS) {
				throw new RuntimeException("Failed to create Descriptor Pool");
			}
			
			LongBuffer descriptorSetLayoutBuffer = stack.longs(descriptorSetLayout);
			
			VkDescriptorSetAllocateInfo setAllocateInfo = VkDescriptorSetAllocateInfo.callocStack(stack)
				.sType(VK11.VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO)
				.descriptorPool(descriptorPoolPtr[0])
				.pSetLayouts(descriptorSetLayoutBuffer)
			;
			
			long[] descriptorSetPtr = {0};
			if(VK11.vkAllocateDescriptorSets(device, setAllocateInfo, descriptorSetPtr) != VK11.VK_SUCCESS) {
				throw new RuntimeException("Failed to allocate Descriptor Set");
			}
			
			return descriptorSetPtr[0];
		}
	}
	
	private void bindBuffersToDescriptorSet(VkDevice device, long descriptorSet, List<Pair<Long, Long>> buffersAndSizes) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			VkDescriptorBufferInfo.Buffer bufferInfos = VkDescriptorBufferInfo.callocStack(buffersAndSizes.size(), stack);
			for(int i = 0; i < buffersAndSizes.size(); i++) {
				bufferInfos.get(i)
					.buffer(buffersAndSizes.get(i).first)
					.offset(0)
					.range(buffersAndSizes.get(i).second)
				;
			}
			
			VkWriteDescriptorSet.Buffer writeDescriptorSet = VkWriteDescriptorSet.callocStack(buffersAndSizes.size(), stack);
			
			for(int i = 0; i < buffersAndSizes.size(); i++) {
				writeDescriptorSet.get(i)
					.sType(VK11.VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET)
					.dstSet(descriptorSet)
					.descriptorCount(1)
					.descriptorType(VK11.VK_DESCRIPTOR_TYPE_STORAGE_BUFFER)
					.dstBinding(i)
					.pBufferInfo(bufferInfos.slice(i, 1))
				;
			}

			VK11.vkUpdateDescriptorSets(device, writeDescriptorSet, null);
		}
	}
	
	private long createShaderModule(VkDevice device, String glslCode, String name) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			long compiler = Shaderc.shaderc_compiler_initialize();
	        long options = Shaderc.shaderc_compile_options_initialize();
	        ShadercIncludeResolve resolver;
	        ShadercIncludeResultRelease releaser;
	        Shaderc.shaderc_compile_options_set_optimization_level(options, Shaderc.shaderc_optimization_level_performance);
	        Shaderc.shaderc_compile_options_set_include_callbacks(options, resolver = new ShadercIncludeResolve() {
	            public long invoke(long user_data, long requested_source, int type, long requesting_source, long include_depth) {
	                ShadercIncludeResult res = ShadercIncludeResult.callocStack(stack);
                    res.content(stack.UTF8(glslCode));
                    res.source_name(stack.UTF8(name));
                    return res.address(); 
	            }
	        }, releaser = new ShadercIncludeResultRelease() {public void invoke(long user_data, long include_result) {}}, 0L);
	        long res;
            res = Shaderc.shaderc_compile_into_spv(compiler, stack.UTF8(glslCode), Shaderc.shaderc_glsl_compute_shader,
                            stack.UTF8(name), stack.UTF8("main"), options);
            if (res == 0L)
                throw new AssertionError("Internal error during compilation!");
	        if (Shaderc.shaderc_result_get_compilation_status(res) != Shaderc.shaderc_compilation_status_success) {
	            throw new AssertionError("Shader compilation failed: " + Shaderc.shaderc_result_get_error_message(res));
	        }
	        int size = (int) Shaderc.shaderc_result_get_length(res);
	        ByteBuffer resultBytes = stack.calloc(size);
	        resultBytes.put(Shaderc.shaderc_result_get_bytes(res));
	        resultBytes.flip();
	        Shaderc.shaderc_compiler_release(res);
	        Shaderc.shaderc_compiler_release(compiler);
	        releaser.free();
	        resolver.free();
	        
	        VkShaderModuleCreateInfo shaderModuleCreateInfo = VkShaderModuleCreateInfo.callocStack(stack)
	        	.sType(VK11.VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO)
	        	.pCode(resultBytes)
	        ;
	        
	        long[] shaderModulePtr = {0};
	        if(VK11.vkCreateShaderModule(device, shaderModuleCreateInfo, null, shaderModulePtr) != VK11.VK_SUCCESS) {
	        	throw new RuntimeException("Unable to create Shader Module");
	        }
	        return shaderModulePtr[0];
		}
	}

}
