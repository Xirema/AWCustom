package org.scratch.main.mandel.model;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL43;
import org.lwjgl.opengl.GLCapabilities;
import org.lwjgl.system.MemoryStack;
import org.scratch.main.mandel.model.config.MandelOptions;
import org.scratch.main.mandel.model.gl.GLResourceStack;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.IOUtil;

public class MandelViewerGL implements MandelViewer {
	private GLResourceStack resourceStack;
	private long window;
	
	private int floatProgram, doubleProgram, fdoubleProgram, dquadProgram;
	private MandelOptions lastOptions;
	private int vertexArray;
	private int colorBuffer;
	private int renderTexture;
	private int renderFramebuffer;
	private int framebufferWidth, framebufferHeight;
	private double lastDraw;
	private double frametime = 0;
	
	GLCapabilities capabilities;
	public MandelViewerGL() {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			GLFW.glfwInit();
			resourceStack = new GLResourceStack();
			resourceStack.holdGeneric(0, l -> GLFW.glfwTerminate());
			
			window = resourceStack.holdGeneric(GLFW.glfwCreateWindow(800, 450, stack.UTF8("Mandelbrot Viewer"), 0, 0), GLFW::glfwDestroyWindow);
			GLFW.glfwMakeContextCurrent(window);
			capabilities = GL.createCapabilities();
			buildPrograms();
			buildBuffersAndVertexArrays();
			lastDraw = GLFW.glfwGetTime();
		}
	}
	private void buildBuffersAndVertexArrays() {
		vertexArray = resourceStack.holdGenericHandle(GL43.glGenVertexArrays(), GL43::glDeleteVertexArrays);
		colorBuffer = resourceStack.holdGenericHandle(GL43.glGenBuffers(), GL43::glDeleteBuffers);
		GL43.glBindVertexArray(vertexArray);
		GL43.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, colorBuffer);
		GL43.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, colorBuffer);
		renderTexture = resourceStack.holdGenericHandle(GL43.glGenTextures(), GL43::glDeleteTextures);
		GL43.glBindTexture(GL43.GL_TEXTURE_2D, renderTexture);
		GL43.glTexParameteri(GL43.GL_TEXTURE_2D, GL43.GL_TEXTURE_MIN_FILTER, GL43.GL_NEAREST);
		GL43.glTexParameteri(GL43.GL_TEXTURE_2D, GL43.GL_TEXTURE_MAG_FILTER, GL43.GL_NEAREST);
		renderFramebuffer = resourceStack.holdGenericHandle(GL43.glGenFramebuffers(), GL43::glDeleteFramebuffers);
		GL43.glBindFramebuffer(GL43.GL_FRAMEBUFFER, renderFramebuffer);
		GL43.glFramebufferTexture2D(GL43.GL_FRAMEBUFFER, GL43.GL_COLOR_ATTACHMENT0, GL43.GL_TEXTURE_2D, renderTexture, 0);
	}
	private void buildPrograms() {
		try(MemoryStack stack = MemoryStack.stackPush();
			GLResourceStack localResourceStack = new GLResourceStack()) {
			int vertexShader = localResourceStack.holdShader(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/00 EscapeAndRender.vert"), GL43.GL_VERTEX_SHADER);
			
			List<String> sources = new ArrayList<>();
			sources.add(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/01 GLSL Defines.frag"));
			sources.add(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/02 Float32 Defines.frag"));
			sources.add(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/03 FloatDoubleScalarMath.frag"));
			sources.add(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/04 ComplexMath.frag"));
			sources.add(IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/05 EscapeAndRender.frag"));
			
			int fragmentShader = localResourceStack.holdShader(sources.stream().reduce("", (s1, s2) -> s1 + s2), GL43.GL_FRAGMENT_SHADER);
			floatProgram = resourceStack.holdProgram(vertexShader, fragmentShader);
			
			sources.set(1, IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/02 Float64 Defines.frag"));
			fragmentShader = localResourceStack.holdShader(sources.stream().reduce("", (s1, s2) -> s1 + s2), GL43.GL_FRAGMENT_SHADER);
			doubleProgram = resourceStack.holdProgram(vertexShader, fragmentShader);
			
			sources.set(1, IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/02 DF64 Defines.frag"));
			sources.set(2, IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/03 FDoubleDQuadScalarMath.frag"));
			fragmentShader = localResourceStack.holdShader(sources.stream().reduce("", (s1, s2) -> s1 + s2), GL43.GL_FRAGMENT_SHADER);
			fdoubleProgram = resourceStack.holdProgram(vertexShader, fragmentShader);
			
			sources.set(1, IOUtil.getFileFromClassPath(MandelViewerGL.class, "gl/02 QD128 Defines.frag"));
			fragmentShader = localResourceStack.holdShader(sources.stream().reduce("", (s1, s2) -> s1 + s2), GL43.GL_FRAGMENT_SHADER);
			dquadProgram = resourceStack.holdProgram(vertexShader, fragmentShader);
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage(), e);
		}
	}
	@Override
	public void view(MandelOptions options) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			int[] width = {0}, height = {0};
			GLFW.glfwGetFramebufferSize(window, width, height);
			options = options.withWidth(Math.max(width[0], 1)).withHeight(Math.max(height[0], 1));
			options = options.withSupersampleFactor(1);
			if(!options.equals(lastOptions)) {
				int program = setProgram(options);
				
				GL43.glUseProgram(program);
				if(
					lastOptions == null ||
					options.width != lastOptions.width ||
					options.height != lastOptions.height
				) {
					updateTextureAndFramebuffer(options);
				}
				GL43.glBindFramebuffer(GL43.GL_FRAMEBUFFER, renderFramebuffer);
				GL43.glViewport(0, 0, framebufferWidth, framebufferHeight);
				GL43.glClearColor(1, 0.5f, 1, 1);
				GL43.glClear(GL43.GL_COLOR_BUFFER_BIT);
				
				Matrix4f mvp = new Matrix4f();
				mvp = mvp.rotation((float)options.rotation, new Vector3f(0, 0, 1));
				if(options.width > options.height)
					mvp = mvp.ortho(-(float)options.height / options.width, (float)options.height / options.width, -1, 1, -1, 1);
				else
					mvp = mvp.ortho(-1, 1, -(float)options.width / options.height, (float)options.width / options.height, -1, 1);
				FloatBuffer mvpData = stack.callocFloat(16);
				mvp.get(mvpData);
				GL43.glUniformMatrix4fv(GL43.glGetUniformLocation(program, "mvp"), false, mvpData);
				if(
					lastOptions == null ||
					!options.colors.equals(lastOptions.colors) || 
					!options.voidColor.equals(lastOptions.voidColor)
				) {
					updateColors(options);
				}
				
				GL43.glUniform1f(GL43.glGetUniformLocation(program, "radius"), options.radius);
				GL43.glUniform1i(GL43.glGetUniformLocation(program, "limit"), options.escapeThreshold);
				
				assignCenter(options, program);
				
				GL43.glDrawArrays(GL43.GL_QUADS, 0, 4);
			}
			
			GL43.glBindFramebuffer(GL43.GL_DRAW_FRAMEBUFFER, 0);
			GL43.glBindFramebuffer(GL43.GL_READ_FRAMEBUFFER, renderFramebuffer);
			
			GL43.glViewport(0, 0, options.width, options.height);
			GL43.glClearColor(1, 0, 0, 1);
			GL43.glClear(GL43.GL_COLOR_BUFFER_BIT);
			
			GL43.glBlitFramebuffer(
				0, 0, framebufferWidth, framebufferHeight, 
				0, 0, options.width, options.height,
				GL43.GL_COLOR_BUFFER_BIT,
				GL43.GL_NEAREST
			);
			double done = GLFW.glfwGetTime();
			frametime = frametime * .99 + (done - lastDraw) * 0.01;
			lastDraw = done;
			lastOptions = options;
		}
	}
	private int setProgram(MandelOptions options) {
		switch(options.precision) {
		case FLOAT: return floatProgram;
		case DOUBLE: return doubleProgram;
		case FDOUBLE: return fdoubleProgram;
		case DQUAD: return dquadProgram;
		default:
			throw new RuntimeException("Unsupported Precision: " + options.precision);
		}
	}
	private void assignCenter(MandelOptions options, int program) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			int location = GL43.glGetUniformLocation(program, "center");
			switch(options.precision) {
			case FLOAT:
				GL43.glUniform2f(location, (float)options.center.first.doubleValue(), (float)options.center.second.doubleValue());
				break;
			case DOUBLE: 
				GL43.glUniform2d(location, options.center.first.doubleValue(), options.center.second.doubleValue());
				break;
			case FDOUBLE: {
				float[] data = {
					(float)options.center.first.doubleValue(),
					0,
					(float)options.center.second.doubleValue(),
					0
				};
				data[1] = (float)(options.center.first.doubleValue() - data[0]);
				data[3] = (float)(options.center.second.doubleValue() - data[2]);
				GL43.glUniform4fv(location, data);
				break;
			}
			case DQUAD: {
				double[] data = {
					options.center.first.doubleValue(),
					0,
					options.center.second.doubleValue(),
					0
				};
				data[1] = options.center.first.minus(BigRational.from(data[0])).doubleValue();
				data[3] = options.center.second.minus(BigRational.from(data[2])).doubleValue();
				GL43.glUniform4dv(location, data);
				break;
			}
			default:
				throw new RuntimeException("Precision Unsupported: " + options.precision);
			}
		}
	}
	private void updateColors(MandelOptions options) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			GL43.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, colorBuffer);
			ByteBuffer data = stack.calloc((options.colors.size() + 1) * 16);
			FloatBuffer view = data.asFloatBuffer();
			for(int i = 0; i < options.colors.size(); i++) {
				float[] components = options.colors.get(i).getComponents(null);
				for(int j = 0; j < components.length; j++) {
					view.put(i * 4 + j, components[j]);
				}
			}
			GL43.glBufferData(GL43.GL_SHADER_STORAGE_BUFFER, data, GL43.GL_STATIC_DRAW);
		}
	}
	private void updateTextureAndFramebuffer(MandelOptions options) {
		int downScaleFactor;
		switch(options.precision) {
		case FLOAT:
			downScaleFactor = 1;
			break;
		case FDOUBLE:
		case DOUBLE:
			downScaleFactor = 2;
			break;
		case DQUAD:
			downScaleFactor = 4;
			break;
		default:
			throw new RuntimeException("Precision not supported: " + options.precision);
		}
		framebufferWidth = options.width / downScaleFactor;
		framebufferHeight = options.height / downScaleFactor;
		GL43.glBindFramebuffer(GL43.GL_FRAMEBUFFER, renderFramebuffer);
		GL43.glBindTexture(GL43.GL_TEXTURE_2D, renderTexture);
		GL43.glTexImage2D(GL43.GL_TEXTURE_2D, 0, GL43.GL_RGBA, framebufferWidth, framebufferHeight, 0, GL43.GL_RGBA, GL43.GL_UNSIGNED_BYTE, (ByteBuffer)null);
	}
	@Override
	public void close() {
		resourceStack.close();
	}
	
	@Override
	public boolean handleEvents() {
		GLFW.glfwSwapBuffers(window);
		GLFW.glfwPollEvents();
		GLFW.glfwSetWindowTitle(window, "Mandelbrot Viewer: " + String.format("%5.2f FPS", 1 / frametime));
		return !GLFW.glfwWindowShouldClose(window);
	}
}
