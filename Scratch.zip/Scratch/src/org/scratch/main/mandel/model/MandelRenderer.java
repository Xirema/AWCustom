package org.scratch.main.mandel.model;

import java.awt.image.RenderedImage;
import java.io.Closeable;
import java.util.concurrent.Future;

import org.scratch.main.mandel.model.config.MandelOptions;

public interface MandelRenderer extends Closeable, AutoCloseable{
	Future<RenderedImage> render(MandelOptions options);
}
