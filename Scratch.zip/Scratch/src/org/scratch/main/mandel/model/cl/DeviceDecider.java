package org.scratch.main.mandel.model.cl;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

import org.lwjgl.PointerBuffer;
import org.lwjgl.opencl.CL21;
import org.lwjgl.system.MemoryStack;

public class DeviceDecider {
	public static class DeciderOptions {
		public enum TypePreference {
			ANY, GPU, CPU
		}
		
		public TypePreference typePreference = TypePreference.GPU;
	}
	
	public static long chooseDevice(DeciderOptions options) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			int[] numOfPlatforms = {0};
			List<Long> devices = new ArrayList<>();
			CL21.clGetPlatformIDs(null, numOfPlatforms);
			PointerBuffer platforms = stack.callocPointer(numOfPlatforms[0]);
			CL21.clGetPlatformIDs(platforms, numOfPlatforms);
			for(int i = 0; i < numOfPlatforms[0]; i++) {
				long platformID = platforms.get(i);
				int[] numOfDevices = {0};
				CL21.clGetDeviceIDs(platformID, CL21.CL_DEVICE_TYPE_ALL, null, numOfDevices);
				PointerBuffer devicesBuffer = stack.callocPointer(numOfDevices[0]);
				CL21.clGetDeviceIDs(platformID, CL21.CL_DEVICE_TYPE_ALL, devicesBuffer, numOfDevices);
				for(int j = 0; j < numOfDevices[0]; j++) {
					devices.add(devicesBuffer.get(j));
				}
			}
			if(devices.size() == 0)
				throw new RuntimeException("No Devices found!");
			
			Function<Long, Integer> calcScore = (device) -> {
				int score = 0;
				if(options.typePreference == DeciderOptions.TypePreference.GPU) {
					score += (getDeviceType(device) == CL21.CL_DEVICE_TYPE_GPU ? 1000000 : 0);
				} else if(options.typePreference == DeciderOptions.TypePreference.CPU) {
					score += (getDeviceType(device) == CL21.CL_DEVICE_TYPE_CPU ? 1000000 : 0);
				}
				score += getDeviceCLVersion(device);
				score += getDeviceComputeUnits(device);
				return score;
			};
			
			Comparator<Long> func = (device1, device2) -> {
				return calcScore.apply(device1) - calcScore.apply(device2);
			};
			
			Collections.sort(devices, func);
			
			for(long deviceId : devices) {
				PointerBuffer deviceNameSize = stack.callocPointer(1);
				CL21.clGetDeviceInfo(deviceId, CL21.CL_DEVICE_NAME, (ByteBuffer)null, deviceNameSize);
				ByteBuffer deviceName = stack.calloc((int)deviceNameSize.get(0));
				CL21.clGetDeviceInfo(deviceId, CL21.CL_DEVICE_NAME, deviceName, deviceNameSize);
				byte[] nameBytes = new byte[(int)deviceNameSize.get(0)];
				deviceName.get(nameBytes);
				System.out.println("Device: \"" + new String(nameBytes) + "\": " + calcScore.apply(deviceId));
			}
			
			return devices.get(devices.size() - 1);
		}
	}
		
		private static int getDeviceType(long device) {
			try(MemoryStack stack = MemoryStack.stackPush()) {
				IntBuffer typeBuffer = stack.callocInt(1);
				PointerBuffer retSize = stack.callocPointer(1);
				CL21.clGetDeviceInfo(device, CL21.CL_DEVICE_TYPE, typeBuffer, retSize);
				return typeBuffer.get(0);
			}
		}
		
		private static int getDeviceCLVersion(long device) {
			try(MemoryStack stack = MemoryStack.stackPush()) {
				PointerBuffer retSize = stack.callocPointer(1);
				CL21.clGetDeviceInfo(device, CL21.CL_DEVICE_VERSION, (ByteBuffer)null, retSize);
				ByteBuffer versionBuffer = stack.calloc((int)retSize.get(0));
				retSize.clear();
				CL21.clGetDeviceInfo(device, CL21.CL_DEVICE_VERSION, versionBuffer, retSize);
				int major = ((char)versionBuffer.get(7)) - '0'; 
				int minor = ((char)versionBuffer.get(9)) - '0';
				return major * 10000 + minor * 1000;
			}
		}
		
		private static int getDeviceComputeUnits(long device) {
			try(MemoryStack stack = MemoryStack.stackPush()) {
				IntBuffer unitsBuffer = stack.callocInt(1);
				PointerBuffer retSize = stack.callocPointer(1);
				CL21.clGetDeviceInfo(device, CL21.CL_DEVICE_MAX_COMPUTE_UNITS, unitsBuffer, retSize);
				return unitsBuffer.get(0);
			}
		}
}
