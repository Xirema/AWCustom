package org.scratch.main.mandel.model;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.RenderedImage;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.lwjgl.PointerBuffer;
import org.lwjgl.opencl.CL21;
import org.lwjgl.opencl.CL22;
import org.lwjgl.opencl.CLImageDesc;
import org.lwjgl.opencl.CLImageFormat;
import org.lwjgl.system.MemoryStack;
import org.scratch.main.mandel.model.cl.CLResource;
import org.scratch.main.mandel.model.cl.CLResourceStack;
import org.scratch.main.mandel.model.cl.DeviceDecider;
import org.scratch.main.mandel.model.cl.DeviceDecider.DeciderOptions;
import org.scratch.main.mandel.model.config.MandelOptions;
import org.scratch.main.util.BigRational;
import org.scratch.main.util.IOUtil;

public class MandelbrotRendererCL implements MandelRenderer {
	
	private long devicePtr;
	private CLResource context;
	private CLResource queue;
	private CLResourceStack resourceStack;
	
	private long floatEscapeProgram, floatEscapeKernel,
				doubleEscapeProgram, doubleEscapeKernel,
				fdoubleEscapeProgram, fdoubleEscapeKernel,
				dquadEscapeProgram, dquadEscapeKernel;
	
	private long renderProgram, renderKernel;
	
	public MandelbrotRendererCL() {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			resourceStack = new CLResourceStack();
			devicePtr = DeviceDecider.chooseDevice(new DeciderOptions());
			
			context = resourceStack.holdContext(devicePtr);
			
			queue = resourceStack.holdQueue(context.getPtr(), devicePtr);
			
			buildProgramsAndKernels();
		}
	}

	@Override
	public void close() throws IOException {
		resourceStack.close();
	}

	@Override
	public Future<RenderedImage> render(MandelOptions options) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			CLResourceStack resourceStack = new CLResourceStack();
			int escapeWidth = options.width * options.supersampleFactor;
			int escapeHeight = options.height * options.supersampleFactor;
			
			int[] ret = {0};
			CLImageFormat imageFormat = CLImageFormat.callocStack(stack)
					.image_channel_data_type(CL21.CL_FLOAT)
					.image_channel_order(CL21.CL_R);
			CLImageDesc imageDesc = CLImageDesc.callocStack(stack)
					.image_type(CL21.CL_MEM_OBJECT_IMAGE2D)
					.image_width(escapeWidth)
					.image_height(escapeHeight)
			;
					
			long escapeImageMemory = CL21.clCreateImage(
				context.getPtr(), 
				CL21.CL_MEM_READ_WRITE | CL21.CL_MEM_HOST_NO_ACCESS, 
				imageFormat, 
				imageDesc, (ByteBuffer)null, ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				if(ret[0] == CL21.CL_IMAGE_FORMAT_NOT_SUPPORTED) {
					IntBuffer numFormats = stack.callocInt(1);
					CL21.clGetSupportedImageFormats(context.getPtr(), CL21.CL_MEM_READ_WRITE, CL21.CL_MEM_OBJECT_IMAGE2D, null, numFormats);
					CLImageFormat.Buffer formats = CLImageFormat.callocStack(numFormats.get(0), stack);
					CL21.clGetSupportedImageFormats(context.getPtr(), CL21.CL_MEM_READ_WRITE, CL21.CL_MEM_OBJECT_IMAGE2D, formats, numFormats);
					Map<Integer, String> names = getImageFormatCodes();
					for(CLImageFormat format : formats) {
						System.err.println("Data Type: " + names.get(format.image_channel_data_type()) + " Channel Order: " + names.get(format.image_channel_order()));
					}
				}
				throw new RuntimeException("Unable to allocate Escape Image: " + ret[0]);
			}
			resourceStack.holdResource(escapeImageMemory, CL21::clReleaseMemObject);
			imageFormat.image_channel_order(CL21.CL_RGBA)
				.image_channel_data_type(CL21.CL_UNSIGNED_INT8);
			imageDesc.image_width(options.width)
				.image_height(options.height);
			long renderImageMemory = CL21.clCreateImage(
					context.getPtr(),
					CL21.CL_MEM_WRITE_ONLY | CL21.CL_MEM_HOST_READ_ONLY, 
					imageFormat, imageDesc, 
					(ByteBuffer)null, ret);
	
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to allocate Render Image: " + ret[0]);
			}
			resourceStack.holdResource(renderImageMemory, CL21::clReleaseMemObject);
			
			System.out.println("Images Created.");
			
			ByteBuffer centerBuffer;
			long escapeKernel;
			switch(options.precision) {
			case FLOAT: {
				centerBuffer = stack.calloc(8);
				FloatBuffer view = centerBuffer.asFloatBuffer();
				view.put(0, (float)options.center.first.doubleValue());
				view.put(1, (float)options.center.second.doubleValue());
				escapeKernel = floatEscapeKernel;
				break;
			}
			case DOUBLE: {
				centerBuffer = stack.calloc(16);
				DoubleBuffer view = centerBuffer.asDoubleBuffer();
				view.put(0, options.center.first.doubleValue());
				view.put(1, options.center.second.doubleValue());
				escapeKernel = doubleEscapeKernel;
				break;
			}
			case FDOUBLE: {
				float x1, x2, y1, y2;
				x1 = (float)options.center.first.doubleValue();
				x2 = (float)(options.center.first.doubleValue() - x1);
				y1 = (float)options.center.second.doubleValue();
				y2 = (float)(options.center.second.doubleValue() - y1);
				centerBuffer = stack.calloc(16);
				FloatBuffer view = centerBuffer.asFloatBuffer();
				view.put(0, x1);
				view.put(1, x2);
				view.put(2, y1);
				view.put(3, y2);
				escapeKernel = fdoubleEscapeKernel;
				break;
			}
			case DQUAD: {
				double x1, x2, y1, y2;
				x1 = options.center.first.doubleValue();
				BigRational remainder = options.center.first.minus(BigRational.from(x1));
				x2 = remainder.doubleValue();
				y1 = options.center.second.doubleValue();
				remainder = options.center.second.minus(BigRational.from(y1));
				y2 = remainder.doubleValue();
				centerBuffer = stack.calloc(32);
				DoubleBuffer view = centerBuffer.asDoubleBuffer();
				view.put(0, x1);
				view.put(1, x2);
				view.put(2, y1);
				view.put(3, y2);
				escapeKernel = dquadEscapeKernel;
				break;
			}
			default:
				throw new RuntimeException("Precision not supported: " + options.precision);
			}
			
			System.out.println("Center Calculated.");
				
			CL21.clSetKernelArg(escapeKernel, 0, centerBuffer);
			CL21.clSetKernelArg(escapeKernel, 1, new float[]{options.radius});
			float[] rotationData = {(float)Math.cos(options.rotation), -(float)Math.sin(options.rotation), (float)Math.sin(options.rotation), (float)Math.cos(options.rotation)};
			CL21.clSetKernelArg(escapeKernel, 2, rotationData);
			CL21.clSetKernelArg(escapeKernel, 3, new int[]{options.escapeThreshold});
			CL21.clSetKernelArg(escapeKernel, 4, stack.pointers(escapeImageMemory));
			
			CL21.clSetKernelArg(renderKernel, 0, stack.pointers(escapeImageMemory));
			CL21.clSetKernelArg(renderKernel, 1, stack.pointers(renderImageMemory));
			FloatBuffer colorData = stack.callocFloat((options.colors.size() + 1) * 4);
			int index = 0;
			for(Color c : options.colors) {
				float[] floats = c.getComponents(null);
				for(float f : floats) {
					colorData.put(index++, f);
				}
			}
			float[] floats = options.voidColor.getComponents(null);
			for(float f : floats) {
				colorData.put(index++, f);
			}
			IntBuffer colorBufferRet = stack.callocInt(1);
			long colorArrayBuffer = CL21.clCreateBuffer(
				context.getPtr(), 
				CL21.CL_MEM_READ_ONLY | CL21.CL_MEM_COPY_HOST_PTR, 
				colorData, 
				colorBufferRet
			);
			if(colorBufferRet.get(0) != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to allocate Color Buffer: " + colorBufferRet.get(0));
			}
			resourceStack.holdResource(colorArrayBuffer, CL21::clReleaseMemObject);
			CL21.clSetKernelArg(renderKernel, 2, stack.pointers(colorArrayBuffer));
			CL21.clSetKernelArg(renderKernel, 3, new int[]{options.colors.size() + 1});
			CL21.clSetKernelArg(renderKernel, 4, new int[]{options.escapeThreshold});
			
			System.out.println("Kernel Arguments Assigned.");
			
			PointerBuffer escapeEvent = stack.callocPointer(1);
			CL21.clEnqueueNDRangeKernel(
				queue.getPtr(), 
				escapeKernel, 
				/*work_dim*/2, 
				/*global_work_offset*/stack.pointers(0,0), 
				stack.pointers(escapeWidth, escapeHeight), 
				/*local_work_size*/null, 
				null, 
				escapeEvent
			);
			resourceStack.holdResource(escapeEvent.get(0), CL21::clReleaseEvent);
			
			System.out.println("Escape Kernel Submitted.");
			
			PointerBuffer renderEvent = stack.callocPointer(1);
			
			CL21.clEnqueueNDRangeKernel(
				queue.getPtr(), 
				renderKernel, 
				/*work_dim*/2, 
				/*global_work_offset*/stack.pointers(0,0), 
				stack.pointers(options.width, options.height), 
				/*local_work_size*/null, 
				escapeEvent, 
				renderEvent
			);
			resourceStack.holdResource(renderEvent.get(0), CL21::clReleaseEvent);
			
			System.out.println("Render Kernel Submitted.");
			long renderEventPtr = renderEvent.get(0);
			return CompletableFuture.supplyAsync(() -> completeRender(options, renderEventPtr, renderImageMemory, resourceStack));
		}
	}
	
	private Map<Integer, String> getImageFormatCodes() {
		Map<Integer, String> ret = new HashMap<>();
		ret.put(CL21.CL_R, "CL_R");
		ret.put(CL21.CL_A, "CL_A");
//		ret.put(CL22.CL_DEPTH, "CL_DEPTH");
		ret.put(CL21.CL_LUMINANCE, "CL_LUMINANCE");
		ret.put(CL21.CL_INTENSITY, "CL_INTENSITY");
		ret.put(CL21.CL_RG, "CL_RG");
		ret.put(CL21.CL_RA, "CL_RA");
		ret.put(CL21.CL_Rx, "CL_Rx");
		ret.put(CL21.CL_RGB, "CL_RGB");
		ret.put(CL21.CL_RGx, "CL_RGx");
		ret.put(CL21.CL_RGBA, "CL_RGBA");
		ret.put(CL21.CL_ARGB, "CL_ARGB");
		ret.put(CL21.CL_BGRA, "CL_BGRA");
		ret.put(CL21.CL_ABGR, "CL_ABGR");
		ret.put(CL21.CL_RGBx, "CL_RGBx");
		ret.put(CL21.CL_sRGB, "CL_sRGB");
		ret.put(CL21.CL_sRGBA, "CL_sRGBA");
		ret.put(CL21.CL_sBGRA, "CL_sBGRA");
		ret.put(CL21.CL_sRGBx, "CL_sRGBx");
		ret.put(CL21.CL_SNORM_INT8, "CL_SNORM_INT8");
		ret.put(CL21.CL_SNORM_INT16, "CL_SNORM_INT16");
		ret.put(CL21.CL_UNORM_INT8, "CL_UNORM_INT8");
		ret.put(CL21.CL_UNORM_INT16, "CL_UNORM_INT16");
		ret.put(CL21.CL_UNORM_SHORT_565, "CL_UNORM_​SHORT_​565");
		ret.put(CL21.CL_UNORM_SHORT_555, "CL_UNORM_SHORT_555");
		ret.put(CL21.CL_UNORM_INT_101010, "CL_UNORM_INT_101010");
		ret.put(CL21.CL_UNORM_INT_101010_2, "CL_UNORM_INT_101010_2");
		ret.put(CL21.CL_SIGNED_INT8, "CL_SIGNED_INT8");
		ret.put(CL21.CL_SIGNED_INT16, "CL_SIGNED_INT16");
		ret.put(CL21.CL_SIGNED_INT32, "CL_SIGNED_INT32");
		ret.put(CL21.CL_HALF_FLOAT, "CL_HALF_FLOAT");
		ret.put(CL21.CL_FLOAT, "CL_FLOAT");
		return ret;
	}

	private RenderedImage completeRender(MandelOptions options, long renderEvent, long renderImageMemory, CLResourceStack resourceStack) {
		try(MemoryStack stack = MemoryStack.stackPush();
			CLResourceStack closure = resourceStack) {
	        BufferedImage out = new BufferedImage(options.width, options.height, BufferedImage.TYPE_INT_ARGB);
			int[] backingImageData = ((DataBufferInt)out.getRaster().getDataBuffer()).getData();
			int[] ret = {0};
			
			System.out.println("Waiting for Render Event.");
			
			int success = CL21.clWaitForEvents(renderEvent);
			if(success != CL21.CL_SUCCESS) {
				throw new RuntimeException("Rendering Failed: " + success);
			}
			
			System.out.println("Rendering Complete...?");
			
			ByteBuffer imageData = CL21.clEnqueueMapImage(
				queue.getPtr(), 
				renderImageMemory, 
				true, 
				CL21.CL_MAP_READ, 
				stack.pointers(0, 0, 0), 
				stack.pointers(options.width, options.height, 1), 
				/*image_row_pitch*/stack.pointers(0), 
				/*image_slice_pitch*/stack.pointers(0), 
				/*event_wait_list*/null, 
				/*event*/null, 
				ret,
				null
			);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to Map Image into Host Memory: " + ret[0]);
			}
			imageData
				.asIntBuffer()
				.get(backingImageData);
			CL21.clEnqueueUnmapMemObject(queue.getPtr(), renderImageMemory, imageData, null, null);
			
			return out;
		}
	}
	
	private void buildProgramsAndKernels() {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			List<String> sources = new ArrayList<>();
			Class<MandelbrotRendererCL> clazz = MandelbrotRendererCL.class;
			int[] ret = {0};
			
			sources.add(IOUtil.getFileFromClassPath(clazz, "cl/02 Float32 Defines.cl"));
			sources.add(IOUtil.getFileFromClassPath(clazz, "cl/03 FloatDoubleScalarMath.cl"));
			sources.add(IOUtil.getFileFromClassPath(clazz, "cl/04 ComplexMath.cl"));
			sources.add(IOUtil.getFileFromClassPath(clazz, "cl/05 CreateEscapeTime.cl"));
			floatEscapeProgram = resourceStack.holdProgram(context.getPtr(), devicePtr, sources.stream().reduce("", (s1, s2) -> s1 + s2)).getPtr();
			floatEscapeKernel = CL21.clCreateKernel(floatEscapeProgram, stack.UTF8("escapeTime"), ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to find Escape Kernel: " + ret[0]);
			}
			resourceStack.holdResource(floatEscapeKernel, CL21::clReleaseKernel);
			
			sources.set(0, IOUtil.getFileFromClassPath(clazz, "cl/02 Float64 Defines.cl"));
			doubleEscapeProgram = resourceStack.holdProgram(context.getPtr(), devicePtr, sources.stream().reduce("", (s1, s2) -> s1 + s2)).getPtr();
			doubleEscapeKernel = CL21.clCreateKernel(doubleEscapeProgram, stack.UTF8("escapeTime"), ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to find Escape Kernel: " + ret[0]);
			}
			resourceStack.holdResource(doubleEscapeKernel, CL21::clReleaseKernel);
			
			sources.set(0, IOUtil.getFileFromClassPath(clazz, "cl/02 DF64 Defines.cl"));
			sources.set(1, IOUtil.getFileFromClassPath(clazz, "cl/03 FDoubleDQuadScalarMath.cl"));
			fdoubleEscapeProgram = resourceStack.holdProgram(context.getPtr(), devicePtr, sources.stream().reduce("", (s1, s2) -> s1 + s2)).getPtr();
			fdoubleEscapeKernel = CL21.clCreateKernel(fdoubleEscapeProgram, stack.UTF8("escapeTime"), ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to find Escape Kernel: " + ret[0]);
			}
			resourceStack.holdResource(fdoubleEscapeKernel, CL21::clReleaseKernel);
			
			sources.set(0, IOUtil.getFileFromClassPath(clazz, "cl/02 QD128 Defines.cl"));
			dquadEscapeProgram = resourceStack.holdProgram(context.getPtr(), devicePtr, sources.stream().reduce("", (s1, s2) -> s1 + s2)).getPtr();
			dquadEscapeKernel = CL21.clCreateKernel(dquadEscapeProgram, stack.UTF8("escapeTime"), ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to find Escape Kernel: " + ret[0]);
			}
			resourceStack.holdResource(dquadEscapeKernel, CL21::clReleaseKernel);
			
			renderProgram = resourceStack.holdProgram(context.getPtr(), devicePtr, IOUtil.getFileFromClassPath(clazz, "cl/06 ColorAndReduce.cl")).getPtr();
			renderKernel = CL21.clCreateKernel(renderProgram, stack.UTF8("colorAndReduce"), ret);
			if(ret[0] != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to find Render Kernel: " + ret[0]);
			}
			resourceStack.holdResource(renderKernel, CL21::clReleaseKernel);
		} catch(IOException e) {
			throw new RuntimeException("Unable to find Kernel Code Paths", e);
		}
	}
	
	

}
