/**
 * 
 */
/**
 * @author Z244969
 *
 */
package org.scratch.main.mandel.model.gl;