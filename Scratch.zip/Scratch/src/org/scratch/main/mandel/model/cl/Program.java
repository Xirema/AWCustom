package org.scratch.main.mandel.model.cl;



import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import org.lwjgl.PointerBuffer;
import org.lwjgl.opencl.CL21;
import org.lwjgl.system.MemoryStack;

public class Program extends CLResource implements AutoCloseable {
	Program(long contextPtr, long devicePtr, String kernelSource) {
		super(getProgram(contextPtr, devicePtr, kernelSource), CL21::clReleaseProgram);
	}
	
	private static long getProgram(long contextPtr, long devicePtr, String kernelSource) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			IntBuffer ret = stack.callocInt(1);
			long program = CL21.clCreateProgramWithSource(contextPtr, new String[]{kernelSource}, ret);
			if(ret.get(0) != CL21.CL_SUCCESS) {
				throw new RuntimeException("Problem creating Program");
			}
			if(CL21.clBuildProgram(program, devicePtr, "", null, 0) != CL21.CL_SUCCESS) {
				PointerBuffer logSize = stack.callocPointer(1);
				int success = CL21.clGetProgramBuildInfo(program, devicePtr, CL21.CL_PROGRAM_BUILD_LOG, (ByteBuffer)null, logSize);
				if(success != CL21.CL_SUCCESS) {
					throw new RuntimeException("There was a problem retrieving the Build Log: " + success);
				}
				int length = (int)logSize.get(0);
				ByteBuffer errorLog = stack.calloc(length);
				CL21.clGetProgramBuildInfo(program, devicePtr, CL21.CL_PROGRAM_BUILD_LOG, errorLog, logSize);
				byte[] bytes = new byte[length];
				errorLog.get(bytes, 0, length);
				String errorMessage = new String(bytes);
				throw new RuntimeException("Unable to Compile Program:\n" + errorMessage);
			}
			return program;
		}
	}
}
