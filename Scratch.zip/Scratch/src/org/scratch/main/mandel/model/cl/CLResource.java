package org.scratch.main.mandel.model.cl;

import java.util.function.Consumer;

public class CLResource {
	private Consumer<Long> closeure;
	private long ptr;
	CLResource(long ptr, Consumer<Long> closeure) {
		this.closeure = closeure;
		this.ptr = ptr;
	}
	
	public long getPtr() {
		return ptr;
	}
	public void close() {
		closeure.accept(ptr);
	}

}
