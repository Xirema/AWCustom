package org.scratch.main.mandel.model.cl;

import java.nio.IntBuffer;

import org.lwjgl.opencl.CL21;
import org.lwjgl.system.MemoryStack;

public class Context extends CLResource implements AutoCloseable {
	Context(long devicePtr) {
		super(getContext(devicePtr), CL21::clReleaseContext);
	}
	
	private static long getContext(long devicePtr) {
		try(MemoryStack stack = MemoryStack.stackPush()) {
			IntBuffer ret = stack.callocInt(1);
			long ptr = CL21.clCreateContext(null, devicePtr, null, 0, ret);
			if(ret.get(0) != CL21.CL_SUCCESS) {
				throw new RuntimeException("Unable to create Context: " + ret.get(0));
			}
			return ptr;
		}
	}
}
