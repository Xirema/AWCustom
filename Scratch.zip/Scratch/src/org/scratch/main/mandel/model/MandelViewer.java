package org.scratch.main.mandel.model;

import org.scratch.main.mandel.model.config.MandelOptions;

public interface MandelViewer extends AutoCloseable {
	void view(MandelOptions options);
	boolean handleEvents();
	void close();
}
